// The wallpaper picker (Super+W): the screen fills with the wallpaper you
// are pointing at, your wallpapers in a row (or a column) to choose from.
// Three looks, chosen in Settings › Appearance › Wallpaper:
//
//   - carousel: the one chosen big in the middle, its neighbours behind it;
//   - strip:    a row of slanted cards along the bottom, the chosen one wide;
//   - stack:    a column of cards down the right-hand side.
//
// Arrows, the scroll wheel or a click move through them; Enter (or a click
// on the chosen one) sets it; Escape or a click outside goes back unchanged.
#pragma once

#include <map>
#include <memory>
#include <string>
#include <vector>

#include "server.hpp"

namespace arqen {

class WallpaperPicker {
public:
	explicit WallpaperPicker(Server *server);
	~WallpaperPicker();
	WallpaperPicker(const WallpaperPicker &) = delete;
	WallpaperPicker &operator=(const WallpaperPicker &) = delete;

	bool active() const { return open_; }
	void open(Output *output);
	void close(bool apply = false);
	void toggle(Output *output);
	void output_gone(Output *output);

	// While it's open it gets all pointer and key input.
	void motion(double lx, double ly);
	void button(double lx, double ly, uint32_t button, bool pressed);
	void scroll(double delta);
	bool key(xkb_keysym_t sym, uint32_t modifiers);

private:
	struct Item {
		std::string path;   // "" = Arqen's own drawn wallpaper
		std::string name;
	};
	struct Card {
		int index;
		double x[4], y[4];  // the corners (clockwise from top-left), output coords
	};

	void find_items();
	void select(int index);
	void step_by(int delta);
	bool tick(double dt);
	void want_pictures();
	void draw_background();
	void draw_cards();
	void draw_picture(cairo_t *cr, int index, double w, double h, bool big);
	cairo_surface_t *picture(int index, bool big);
	int card_at(double lx, double ly) const;
	void apply_selected();

	Server *server_;
	wlr_scene_tree *tree_;
	wlr_scene_buffer *bg_[2];       // the preview behind (cross-faded)
	wlr_scene_rect *shade_;         // a touch darker, so the cards stand out
	wlr_scene_buffer *cards_;
	int front_ = 0;
	double bg_fade_ = 1;            // 0 -> 1 as the new preview comes in
	int bg_shown_ = -2;             // which item the front preview shows

	bool open_ = false;
	Output *output_ = nullptr;
	std::string style_;
	std::vector<Item> items_;
	int selected_ = 0;
	int started_ = 0;               // the one set when it opened
	double pos_ = 0;                // where the row is (glides to selected_)
	double alpha_ = 0;              // the whole picker, fading in and out
	bool closing_ = false;
	uint64_t ticker_ = 0;
	double scroll_acc_ = 0;
	std::vector<Card> cards_drawn_;
	wlr_box band_{};                // where the cards buffer is (output coords)

	std::map<std::string, cairo_surface_t *> thumbs_;   // small pictures (nullptr while reading)
	std::map<std::string, cairo_surface_t *> bigs_;     // screen-sized, for the preview
	std::vector<std::string> big_order_;
	std::shared_ptr<bool> alive_ = std::make_shared<bool>(true);
};

} // namespace arqen
