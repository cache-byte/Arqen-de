// System sounds (Settings > Sounds): a freedesktop sound theme (from
// ~/.local/share/sounds or /usr/share/sounds), played with pw-play for
// things that happen on the desktop: a notification, the volume changing,
// a screenshot, the charger, a device connecting... Each one can be turned
// off, or given another sound from the theme or a file of your own.
#pragma once

#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <vector>

struct wl_event_source;

namespace arqen {

class Server;

struct SoundEvent {
	const char *id;                    // the setting is sound_<id>
	const char *label;
	std::vector<const char *> names;   // what it's called in a sound theme, best first
	bool on;                           // on unless you turn it off
};
const std::vector<SoundEvent> &sound_events();

// The default theme, when it's installed.
constexpr const char *kDefaultSoundTheme = "modern-minimal-ui-sounds-v1";

class Sounds {
public:
	explicit Sounds(Server *server);
	~Sounds();
	Sounds(const Sounds &) = delete;
	Sounds &operator=(const Sounds &) = delete;
	// Plays what's set for the event (nothing if it's off, or sounds are off).
	void play(const std::string &event);
	// A sound by its theme name, or a file (a notification's own sound).
	void play_named(const std::string &name_or_file);
	// The status changed: the charger, the battery, devices coming and going.
	void status_changed();
	void config_changed();   // the theme may be another one

private:
	std::string resolve(const std::string &event);
	std::string find(const std::string &name);
	void run(const std::string &file);

	Server *server_;
	std::string theme_;                          // the theme the cache is for
	std::map<std::string, std::string> cache_;   // name -> file ("" = none)
	std::map<std::string, uint64_t> last_;       // event -> when it last played (ms)
	// What the status was, to hear what changed (unknown until the first look).
	::wl_event_source *login_timer_ = nullptr;
	double started_ = 0;
	bool known_ = false;
	bool plugged_ = false, full_ = false;
	std::set<std::string> devices_;
};

} // namespace arqen
