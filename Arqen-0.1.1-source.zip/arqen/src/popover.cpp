#include "popover.hpp"

#include "lyrics.hpp"
#include "mediaview.hpp"
#include "ccentre.hpp"
#include "recorder.hpp"

#include <algorithm>
#include <cmath>
#include <ctime>
#include <linux/input-event-codes.h>

#include "draw.hpp"
#include "glyphs.hpp"
#include "system.hpp"
#include "config.hpp"
#include "imageload.hpp"
#include "wallpaper.hpp"
#include <filesystem>
#include <sstream>

namespace arqen {

namespace {

bool inside(const wlr_box &b, double x, double y) {
	return x >= b.x && y >= b.y && x < b.x + b.width && y < b.y + b.height;
}

[[maybe_unused]] std::string mmss(double seconds) {
	const int s = std::max(0, static_cast<int>(seconds));
	char buf[16];
	std::snprintf(buf, sizeof buf, "%d:%02d", s / 60, s % 60);
	return buf;
}

} // namespace

// ============================================================================
// Popover
// ============================================================================

Popover::Popover(Server *server, int width, int height)
		: server_(server), w_(width), h_(height), layer_(server->layer_menu, &tag),
		fx_(server->anim.get(), [this] { redraw(); }), hl_(layer_, server->anim.get()) {
	layer_.set_enabled(false);
}

Popover::~Popover() {
	server_->anim->cancel(anim_);
}

void Popover::resize(int width, int height) {
	w_ = width;
	h_ = height;
}

void Popover::open(Output *output, wlr_box anchor, const std::string &edge) {
	if (!output) {
		return;
	}
	output_ = output;
	anchor_ = anchor;
	edge_ = edge;
	open_ = true;
	hover_.clear();
	on_open();
	redraw();
	layer_.set_enabled(true);
	layer_.raise();
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(t_, 1.0, c.animate(c.anim_menu) ? c.ms(240) : 0,
		[this] { place(); }, [this] { anim_ = 0; });
	server_->redraw_panels();
}

void Popover::close() {
	if (!open_) {
		return;
	}
	open_ = false;
	dragging_.clear();
	on_close();
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(t_, 0.0, c.animate(c.anim_menu) ? c.ms(170) : 0,
		[this] { place(); },
		[this] {
			anim_ = 0;
			if (!open_) {
				if (busy_) busy_->hide();
				layer_.set_enabled(false);
			}
		});
	server_->redraw_panels();
}

void Popover::output_gone(Output *output) {
	if (output_ == output) {
		open_ = false;
		server_->anim->cancel(anim_);
		anim_ = 0;
		t_ = 0;
		if (busy_) busy_->hide();
		layer_.set_enabled(false);
		output_ = nullptr;
	}
}

void Popover::refresh() {
	if (open_ || t_ > 0) {
		redraw();
	}
}

// Beside the button, on the side away from its panel's edge; it zooms out
// of the corner nearest the button.
void Popover::place() {
	if (!output_) {
		return;
	}
	const wlr_box u = output_->usable();
	const int gap = 10;
	int x, y;
	if (edge_ == "below") {
		// Under the anchor (a title bar button), or above it if there's no room.
		x = anchor_.x + anchor_.width / 2 - w_ / 2;
		y = anchor_.y + anchor_.height + 6;
		if (y + h_ > u.y + u.height - gap) y = anchor_.y - h_ - 6;
	} else if (edge_ == "point") {
		// At the pointer, flipped to stay on screen.
		x = anchor_.x + 2;
		y = anchor_.y + 2;
		if (x + w_ > u.x + u.width - gap) x = anchor_.x - w_ - 2;
		if (y + h_ > u.y + u.height - gap) y = anchor_.y - h_ - 2;
	} else if (anchor_.width <= 0) {
		x = u.x + (u.width - w_) / 2;
		y = u.y + (u.height - h_) / 2;
	} else if (edge_ == "top" || edge_ == "bottom") {
		x = anchor_.x + anchor_.width / 2 - w_ / 2;
		y = edge_ == "top" ? u.y + gap : u.y + u.height - h_ - gap;
	} else {
		y = anchor_.y + anchor_.height / 2 - h_ / 2;
		x = edge_ == "left" ? u.x + gap : u.x + u.width - w_ - gap;
	}
	x += offset_x_;
	y += offset_y_;
	x = std::clamp(x, u.x + gap, std::max(u.x + gap, u.x + u.width - w_ - gap));
	y = std::clamp(y, u.y + gap, std::max(u.y + gap, u.y + u.height - h_ - gap));
	box_ = wlr_box{x, y, w_, h_};
	if (anchor_.width > 0 || edge_ == "point" || edge_ == "below") {
		origin_x_ = std::clamp<double>(anchor_.x + anchor_.width / 2.0 - x, 0, w_);
		origin_y_ = std::clamp<double>(anchor_.y + anchor_.height / 2.0 - y, 0, h_);
	} else {
		origin_x_ = w_ / 2.0;
		origin_y_ = h_ / 2.0;
	}
	const double t = std::clamp(t_, 0.0, 1.1);
	// A gentle grow out of what opened it (4%), mostly a fade.
	layer_.show(x, y, std::min(1.0, t * 1.25), 0.96 + 0.04 * t, origin_x_, origin_y_);
}

void Popover::busy_at(double x, double y, double w, double h) {
	busy_box_ = wlr_box{static_cast<int>(std::lround(x)), static_cast<int>(std::lround(y)),
		static_cast<int>(std::lround(w)), std::max(1, static_cast<int>(std::lround(h)))};
}

bool Popover::contains(double lx, double ly) const {
	return open_ && inside(box_, lx, ly);
}

void Popover::redraw() {
	if (!output_ || drawing_) {
		return;
	}
	drawing_ = true;
	const float scale = output_->output->scale;
	Canvas canvas(w_, h_, scale);
	cairo_t *cr = canvas.cr();
	hots_.clear();
	busy_box_ = wlr_box{};
	ui_card(cr, 0, 0, w_, h_, theme::ui_radius, theme::menu_bg);
	draw(cr, scale);
	layer_.present(canvas, wlr_box{0, 0, w_, h_}, theme::ui_radius);
	if (busy_box_.width > 0 && open_) {
		if (!busy_) busy_ = std::make_unique<BusyBar>(server_->anim.get(), &layer_);
		busy_->show(busy_box_.x, busy_box_.y, busy_box_.width, busy_box_.height);
	} else if (busy_) {
		busy_->hide();
	}
	drawing_ = false;
	place();
	update_highlight();
}

void Popover::add_hot(const std::string &id, double x, double y, double w, double h,
		double radius) {
	hots_.push_back(Hot{id, wlr_box{static_cast<int>(x), static_cast<int>(y), static_cast<int>(w),
		static_cast<int>(h)}, radius});
}

double Popover::hover(const std::string &) {
	return 0.0;
}

void Popover::update_highlight() {
	for (const Hot &h : hots_) {
		if (h.id == hover_ && h.radius >= 0) {
			hl_.show(h.box, h.radius, with_alpha(theme::text, theme::dark ? 0.10 : 0.07));
			return;
		}
	}
	hl_.hide();
}

std::string Popover::hot_at(double px, double py) const {
	for (auto it = hots_.rbegin(); it != hots_.rend(); ++it) {
		if (inside(it->box, px, py)) {
			return it->id;
		}
	}
	return "";
}

void Popover::motion(double lx, double ly) {
	const double px = lx - box_.x, py = ly - box_.y;
	if (!dragging_.empty()) {
		on_drag(dragging_, px, py);
		return;
	}
	const std::string now = hot_at(px, py);
	if (now != hover_) {
		hover_ = now;
		update_highlight();
		on_hover();
	}
}

void Popover::leave() {
	if (!hover_.empty() && dragging_.empty()) {
		hover_.clear();
		update_highlight();
		on_hover();
	}
}

void Popover::press(double lx, double ly, uint32_t button) {
	const double px = lx - box_.x, py = ly - box_.y;
	const std::string id = hot_at(px, py);
	if (button == BTN_LEFT && draggable(id)) {
		dragging_ = id;
		server_->popover_grab = this;
		on_drag(id, px, py);
		return;
	}
	if (!id.empty()) {
		hl_.flash();
		activate(id, button, px, py);
	}
}

void Popover::release() {
	if (!dragging_.empty()) {
		const std::string id = dragging_;
		dragging_.clear();
		activate(id, BTN_LEFT, -1, -1);   // "let go"
	}
	server_->popover_grab = nullptr;
}

void Popover::scroll(double, double, double delta) {
	on_scroll(delta);
}

// ============================================================================
// Calendar
// ============================================================================

Calendar::Calendar(Server *server) : Popover(server, 336, 356) {}

void Calendar::on_open() {
	std::time_t now = std::time(nullptr);
	std::tm local{};
	localtime_r(&now, &local);
	year_ = local.tm_year + 1900;
	month_ = local.tm_mon;
	slide_ = 0;
}

void Calendar::change_month(int delta) {
	month_ += delta;
	while (month_ < 0) { month_ += 12; year_--; }
	while (month_ > 11) { month_ -= 12; year_++; }
	// The new month slides in from the side it came from.
	const Config &c = server_->config;
	server_->anim->cancel(slide_anim_);
	slide_ = delta > 0 ? 1.0 : -1.0;
	slide_anim_ = server_->anim->tween(slide_, 0.0, c.animate(c.anim_menu) ? c.ms(220) : 0,
		[this] { redraw(); }, [this] { slide_anim_ = 0; });
	redraw();
}

void Calendar::on_scroll(double delta) {
	if (std::fabs(delta) >= 1) {
		change_month(delta > 0 ? 1 : -1);
	}
}

void Calendar::activate(const std::string &id, uint32_t button, double, double) {
	if (button != BTN_LEFT) {
		return;
	}
	if (id == "prev") change_month(-1);
	else if (id == "next") change_month(1);
	else if (id == "today") {
		std::time_t now = std::time(nullptr);
		std::tm local{};
		localtime_r(&now, &local);
		const int delta = (local.tm_year + 1900 - year_) * 12 + (local.tm_mon - month_);
		if (delta != 0) change_month(delta);
	}
}

void Calendar::draw(cairo_t *cr, float scale) {
	const int pad = 18;
	const double r = theme::ui_radius;
	const bool monday = server_->config.week_monday;

	// A soft accent glow at the top, with a small bar on the edge.
	{
		cairo_save(cr);
		rounded_rect(cr, 2, 2, w_ - 4, h_ - 4, inner_radius(r, 2));
		cairo_clip(cr);
		cairo_pattern_t *glow = cairo_pattern_create_radial(w_ / 2.0, -20, 0, w_ / 2.0, -20, w_ * 0.55);
		const Color &a = theme::accent;
		cairo_pattern_add_color_stop_rgba(glow, 0, a.r, a.g, a.b, theme::dark ? 0.38 : 0.22);
		cairo_pattern_add_color_stop_rgba(glow, 1, a.r, a.g, a.b, 0);
		cairo_set_source(cr, glow);
		cairo_paint(cr);
		cairo_pattern_destroy(glow);
		fill_rounded(cr, w_ / 2.0 - 36, 2, 72, 4, 2, theme::accent);
		cairo_restore(cr);
	}

	// Header: arrows and the month.
	std::tm first{};
	first.tm_year = year_ - 1900;
	first.tm_mon = month_;
	first.tm_mday = 1;
	first.tm_hour = 12;
	std::mktime(&first);
	char title[64];
	std::strftime(title, sizeof title, "%B %Y", &first);
	const int bs = 36;
	for (const auto &[id, x] : {std::pair<std::string, int>{"prev", pad},
			std::pair<std::string, int>{"next", w_ - pad - bs}}) {
		const double h = hover(id);
		cairo_new_path(cr);
		cairo_arc(cr, x + bs / 2.0, pad + bs / 2.0, bs / 2.0 - 0.5, 0, 2 * M_PI);
		set_color(cr, with_alpha(theme::text, 0.05 + 0.10 * h));
		cairo_fill_preserve(cr);
		set_color(cr, with_alpha(theme::text, 0.12));
		cairo_set_line_width(cr, 1);
		cairo_stroke(cr);
		draw_named_icon(cr, server_->icons, id == "prev" ? "chevron-left" : "chevron-right",
			x + bs / 2.0 - 8, pad + bs / 2.0 - 8, 16, theme::text, scale);
		add_hot(id, x, pad, bs, bs, bs / 2.0);
	}
	{
		const double h = hover("today");
		const int tw = text_width(title, theme::font_large) + 24;
		if (h > 0.01) {
			fill_rounded(cr, (w_ - tw) / 2.0, pad + 2, tw, bs - 4, (bs - 4) / 2.0,
				with_alpha(theme::text, 0.08 * h));
		}
		draw_text(cr, title, pad + bs, pad, w_ - 2 * (pad + bs), bs, theme::font_large, theme::text,
			Align::Center);
		add_hot("today", (w_ - tw) / 2.0, pad + 2, tw, bs - 4, (bs - 4) / 2.0);
	}

	// Weekday names.
	const int grid_x = pad - 2, grid_w = w_ - 2 * grid_x;
	const double cw = grid_w / 7.0;
	const int names_y = pad + bs + 12;
	static const char *kMon[] = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"};
	static const char *kSun[] = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
	for (int i = 0; i < 7; i++) {
		draw_text(cr, monday ? kMon[i] : kSun[i], grid_x + i * cw, names_y, cw, 20, theme::font_small,
			theme::text_dim, Align::Center);
	}

	// Days. Leading/trailing days of the neighbouring months are faint.
	const int first_wday = first.tm_wday;   // 0 = Sunday
	const int lead = monday ? (first_wday + 6) % 7 : first_wday;
	auto days_in = [](int y, int m) {
		static const int d[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		const bool leap = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
		return m == 1 && leap ? 29 : d[m];
	};
	const int n = days_in(year_, month_);
	const int prev_n = days_in(month_ == 0 ? year_ - 1 : year_, (month_ + 11) % 12);
	std::time_t now = std::time(nullptr);
	std::tm today{};
	localtime_r(&now, &today);
	const bool this_month = today.tm_year + 1900 == year_ && today.tm_mon == month_;

	const int rows_y = names_y + 26;
	const double rh = (h_ - rows_y - pad + 4) / 6.0;
	const double shift = slide_ * 40;
	const double fade = 1.0 - std::min(1.0, std::fabs(slide_));
	cairo_save(cr);
	cairo_rectangle(cr, 4, rows_y - 4, w_ - 8, h_ - rows_y);
	cairo_clip(cr);
	for (int cell = 0; cell < 42; cell++) {
		const int day = cell - lead + 1;
		const bool other = day < 1 || day > n;
		const int shown = day < 1 ? prev_n + day : day > n ? day - n : day;
		if (other && cell >= 35 && lead + n <= 35) {
			continue;   // a sixth row of only next month: leave it out
		}
		const double cx = grid_x + (cell % 7) * cw + cw / 2 + shift;
		const double cy = rows_y + (cell / 7) * rh + rh / 2;
		const bool is_today = this_month && !other && day == today.tm_mday;
		if (is_today) {
			// The accent dot with a soft glow, like light on a screen.
			cairo_pattern_t *g = cairo_pattern_create_radial(cx, cy + 2, 8, cx, cy + 2, 28);
			const Color &a = theme::accent;
			cairo_pattern_add_color_stop_rgba(g, 0, a.r, a.g, a.b, 0.45 * fade);
			cairo_pattern_add_color_stop_rgba(g, 1, a.r, a.g, a.b, 0);
			cairo_set_source(cr, g);
			cairo_arc(cr, cx, cy + 2, 28, 0, 2 * M_PI);
			cairo_fill(cr);
			cairo_pattern_destroy(g);
			cairo_new_path(cr);
			cairo_arc(cr, cx, cy, std::min(cw, rh) / 2 - 2, 0, 2 * M_PI);
			set_color(cr, with_alpha(theme::accent, fade));
			cairo_fill(cr);
		}
		Color c = is_today ? theme::on_accent : other ? with_alpha(theme::text_dim, 0.45) : theme::text;
		c.a *= fade;
		draw_text(cr, std::to_string(shown), cx - cw / 2, cy - rh / 2, cw, rh, theme::font_large, c,
			Align::Center);
	}
	cairo_restore(cr);
}

// ============================================================================
// Media card
// ============================================================================

namespace {
constexpr int kMediaW = 380, kMediaH = 216, kLyricsH = 206;
}

MediaCard::MediaCard(Server *server) : Popover(server, kMediaW, kMediaH) {
	timer_ = wl_event_loop_add_timer(server->loop, &MediaCard::handle_timer, this);
	view_ = std::make_unique<MediaView>(server);
}

MediaCard::~MediaCard() {
	wl_event_source_remove(timer_);
	if (refit_) wl_event_source_remove(refit_);
	if (ticker_) {
		server_->anim->remove_ticker(ticker_);
	}
	view_.reset();
}

int MediaCard::handle_timer(void *data) {
	auto *self = static_cast<MediaCard *>(data);
	if (!self->open_) {
		return 0;
	}
	self->server_->status->refresh_media();
	wl_event_source_timer_update(self->timer_, 1000);
	return 0;
}

void MediaCard::on_open() {
	// Opens as the card alone. (The lists used to be shut on close without
	// the card shrinking back, so it reopened tall with an empty space.)
	outputs_open_ = false;
	sources_open_ = false;
	fit();
	server_->status->refresh_media();
	wl_event_source_timer_update(timer_, 1000);
	view_->set_shown(true);
	// The wave, the title and the time move while it's open.
	if (!ticker_) {
		ticker_ = server_->anim->add_ticker([this](double dt) {
			if (!open_) {
				view_->set_shown(false);
				ticker_ = 0;
				return false;
			}
			view_->step(dt);
			since_draw_ += dt;
			if (since_draw_ >= 33) {
				since_draw_ = 0;
				redraw();
			}
			return true;
		});
	}
}

void MediaCard::on_close() {
	// (The lists stay as they are while it fades out; on_open shuts them.)
	wl_event_source_timer_update(timer_, 0);
	view_->set_shown(false);
}

void MediaCard::handle_refit(void *data) {
	auto *self = static_cast<MediaCard *>(data);
	self->refit_ = nullptr;
	if (!self->open_) return;
	self->fit();
	self->redraw();
}

int MediaCard::source_rows() const {
	const SystemStatus &st = *server_->status;
	return static_cast<int>(st.player_list().size()) + (st.media_player.empty() ? 0 : 1);
}

void MediaCard::on_drag(const std::string &, double px, double) {
	view_->drag(px);
	redraw();
}

void MediaCard::activate(const std::string &id, uint32_t button, double px, double py) {
	SystemStatus &st = *server_->status;
	Lyrics *ly = server_->lyrics.get();
	if (id == "mp:seek") {
		view_->end_drag();
		return;
	}
	if (button != BTN_LEFT) {
		return;
	}
	if (id == "mp:output") {
		outputs_open_ = !outputs_open_;
		if (outputs_open_) {
			lyrics_open_ = false;
			sources_open_ = false;
			load_outputs();
		}
		fit();
	} else if (id == "mp:source") {
		sources_open_ = !sources_open_;
		if (sources_open_) {
			lyrics_open_ = false;
			outputs_open_ = false;
		}
		fit();
	} else if (id == "src:open") {
		open_player_window(server_);   // (closes the card when it finds the window)
		return;
	} else if (id.rfind("src:", 0) == 0) {
		const auto players = st.player_list();
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 4));
		if (i < players.size()) st.pick_player(players[i].first);
	} else if (id.rfind("out:", 0) == 0) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 4));
		const std::string helper = server_->helper_path("arqen-audio-outputs");
		if (i < outs_.size() && !helper.empty()) {
			const Out &o = outs_[i];
			const std::string args = o.kind == "PORT" ? "--port " + shell_quote(o.name) + " " + shell_quote(o.profile)
				: "--sink " + shell_quote(o.name);
			for (Out &x : outs_) x.current = &x == &o;
			server_->run_capture(shell_quote(helper) + " " + args + " >/dev/null 2>&1", [this](const std::string &) {
				server_->status->refresh();
				if (outputs_open_) load_outputs();
			});
		}
	} else if (id == "mp:lyrics") {
		lyrics_open_ = !lyrics_open_;
		if (lyrics_open_) {
			outputs_open_ = false;
			sources_open_ = false;
		}
		fit();
	} else if (id == "ly:show") {
		server_->write_setting("lyrics_show", server_->config.lyrics_show ? "false" : "true");
	} else if (ly && id == "ly:earlier") {
		ly->nudge_delay(-250);
	} else if (ly && id == "ly:later") {
		ly->nudge_delay(250);
	} else if (ly && id == "ly:slower") {
		ly->nudge_speed(-1);
	} else if (ly && id == "ly:faster") {
		ly->nudge_speed(1);
	} else if (ly && id == "ly:reset") {
		ly->reset_song_timing();
	} else if (ly && id == "ly:refresh") {
		ly->retry(false);
	} else if (ly && id == "ly:retry") {
		ly->retry(false);
	} else if (ly && id == "ly:listen") {
		ly->retry(true);
	} else if (id == "mp:card") {
		return;
	} else if (id.rfind("mp:", 0) == 0) {
		st.media(id.substr(3).c_str());
	}
	redraw();
}

void MediaCard::draw(cairo_t *cr, float scale) {
	const int inset = theme::ui_line == 2 ? 2 : theme::ui_line == 1 ? 1 : 0;
	const double r = inner_radius(theme::ui_radius, inset);
	std::vector<MediaHot> hots;
	// With the lyrics open the card keeps its square bottom corners on the panel under it.
	view_->draw(cr, inset, inset, w_ - 2 * inset, kMediaH - inset - (lyrics_open_ || outputs_open_ || sources_open_ ? 0 : inset), r, scale,
		MediaView::Look::Samsung, &hots);
	for (const MediaHot &h : hots) {
		add_hot(h.id, h.box.x, h.box.y, h.box.width, h.box.height, h.radius);
	}
	if (lyrics_open_) {
		draw_lyrics(cr, kMediaH, kLyricsH, scale);
	}
	if (outputs_open_) {
		draw_outputs(cr, kMediaH, h_ - kMediaH, scale);
	}
	if (sources_open_) {
		draw_sources(cr, kMediaH, h_ - kMediaH, scale);
		// A player started or stopped since it was sized: size it again
		// once this drawing is done.
		if (source_rows() != fitted_rows_ && !refit_) {
			refit_ = wl_event_loop_add_idle(server_->loop, &MediaCard::handle_refit, this);
		}
	}
}

void MediaCard::fit() {
	int extra = 0;
	if (lyrics_open_) extra = kLyricsH;
	else if (outputs_open_) extra = 16 + std::max<int>(1, static_cast<int>(outs_.size())) * 58 + 8;
	else if (sources_open_) {
		fitted_rows_ = source_rows();
		extra = 16 + std::max(1, fitted_rows_) * 58 + 8;
	}
	resize(kMediaW, kMediaH + extra);
	place();
}

void MediaCard::load_outputs() {
	const std::string helper = server_->helper_path("arqen-audio-outputs");
	if (helper.empty() || outs_busy_) return;
	outs_busy_ = true;
	server_->run_capture(shell_quote(helper) + " 2>/dev/null", [this](const std::string &text) {
		outs_busy_ = false;
		outs_.clear();
		std::istringstream in(text);
		std::string line;
		while (std::getline(in, line)) {
			std::vector<std::string> f;
			size_t at = 0, tab;
			while ((tab = line.find('\t', at)) != std::string::npos) {
				f.push_back(line.substr(at, tab - at));
				at = tab + 1;
			}
			f.push_back(line.substr(at));
			if (f.size() >= 4 && f[0] == "SINK") outs_.push_back({"SINK", f[1], "", f[3], f[2] == "1"});
			else if (f.size() >= 4 && f[0] == "PORT") outs_.push_back({"PORT", f[1], f[2], f[3], false});
		}
		// The one playing first, like a phone's list.
		std::stable_sort(outs_.begin(), outs_.end(), [](const Out &a, const Out &b) { return a.current && !b.current; });
		if (open_ && outputs_open_) fit();
		redraw();
	});
}

// Where the sound goes: each output, the one in use ticked.
void MediaCard::draw_outputs(cairo_t *cr, double y, double h, float scale) {
	const double pad = 12;
	const double w = w_ - 2 * pad;
	fill_rounded(cr, pad, y + 8, w, h - 16, std::max(8.0, theme::ui_radius - 4.0), with_alpha(theme::text, 0.05));
	if (outs_.empty()) {
		draw_text(cr, outs_busy_ ? "Looking…" : "No sound outputs found", pad, y + 8, w, 58, theme::font_small,
			theme::text_dim, Align::Center);
		return;
	}
	double ry = y + 14;
	for (size_t i = 0; i < outs_.size(); i++) {
		const Out &o = outs_[i];
		const auto [title, sub] = friendly_device(o.label, o.name, false);
		const std::string id = "out:" + std::to_string(i);
		const double rx = pad + 6, rw = w - 12, rh = 52;
		if (o.current) fill_rounded(cr, rx, ry, rw, rh, std::max(8.0, theme::ui_radius - 6.0), with_alpha(theme::media_accent(), 0.18));
		draw_named_icon(cr, server_->icons, device_icon(title, o.name, false), rx + 14, ry + rh / 2 - 10, 20,
			o.current ? theme::media_accent() : theme::text, scale);
		draw_text(cr, title, rx + 48, ry + 7, rw - 90, 20, theme::font_bold, o.current ? theme::media_accent() : theme::text);
		draw_text(cr, o.kind == "PORT" ? (sub.empty() ? std::string("Off · click to use") : sub + " · off") : sub,
			rx + 48, ry + 27, rw - 90, 18, theme::font_small, theme::text_dim);
		if (o.current) draw_named_icon(cr, server_->icons, "check", rx + rw - 30, ry + rh / 2 - 9, 18, theme::media_accent(), scale);
		add_hot(id, rx, ry, rw, rh, std::max(8.0, theme::ui_radius - 6.0));
		ry += rh + 6;
	}
}

// Which player the card follows: each one with its app's icon and what it's
// playing, the one followed ticked (like the outputs), and opening its window.
void MediaCard::draw_sources(cairo_t *cr, double y, double h, float scale) {
	const SystemStatus &st = *server_->status;
	const double pad = 12;
	const double w = w_ - 2 * pad;
	const double rr = std::max(8.0, theme::ui_radius - 6.0);
	fill_rounded(cr, pad, y + 8, w, h - 16, std::max(8.0, theme::ui_radius - 4.0), with_alpha(theme::text, 0.05));
	const auto players = st.player_list();
	if (players.empty()) {
		draw_text(cr, "Nothing is playing", pad, y + 8, w, 58, theme::font_small, theme::text_dim, Align::Center);
		return;
	}
	const Color acc = theme::media_accent();
	double ry = y + 14;
	const double rx = pad + 6, rw = w - 12, rh = 52;
	for (size_t i = 0; i < players.size(); i++) {
		const auto &[name, title] = players[i];
		const bool current = name == st.media_player;
		if (current) fill_rounded(cr, rx, ry, rw, rh, rr, with_alpha(acc, 0.18));
		const std::string label = player_label(name);
		const std::string base = name.substr(0, name.find('.'));
		const std::string icon = base.empty() ? "" : server_->apps.icon_for(base);
		if (!icon.empty()) draw_icon(cr, server_->icons, icon, label, rx + 12, ry + rh / 2 - 12, 24, scale);
		else draw_named_icon(cr, server_->icons, "audio-lines", rx + 14, ry + rh / 2 - 10, 20, current ? acc : theme::text, scale);
		draw_text(cr, label, rx + 48, ry + 7, rw - 90, 20, theme::font_bold, current ? acc : theme::text);
		draw_text(cr, title.empty() ? std::string("Paused") : title, rx + 48, ry + 27, rw - 90, 18, theme::font_small,
			theme::text_dim);
		if (current) draw_named_icon(cr, server_->icons, "check", rx + rw - 30, ry + rh / 2 - 9, 18, acc, scale);
		add_hot("src:" + std::to_string(i), rx, ry, rw, rh, rr);
		ry += rh + 6;
	}
	if (!st.media_player.empty()) {
		// Its window, as a row of the list.
		const std::string label = "Open " + player_label(st.media_player);
		draw_named_icon(cr, server_->icons, "external-link", rx + 14, ry + rh / 2 - 10, 20, theme::text, scale);
		draw_text(cr, label, rx + 48, ry, rw - 60, rh, theme::font_bold, theme::text);
		add_hot("src:open", rx, ry, rw, rh, rr);
	}
}

namespace {
struct B2 {
	const char *id, *label, *icon;
};
} // namespace

// Under the card: the lines around now, and the timing for this song.
void MediaCard::draw_lyrics(cairo_t *cr, double y, double h, float scale) {
	Lyrics *ly = server_->lyrics.get();
	const double pad = 16;
	const double w = w_ - 2 * pad;
	if (!ly || !ly->available()) {
		const bool off = !server_->config.lyrics;
		const std::string msg = off ? "Lyrics are off (Settings › Media & lyrics)"
			: ly && ly->searching() ? "Looking for lyrics…" : "No synced lyrics for this song yet";
		draw_text(cr, msg, pad, y + 14, w, 24, theme::font, theme::text, Align::Center);
		if (ly && !off && ly->searching()) busy_at(pad + w * 0.3, y + 40, w * 0.4);
		// Why: what the search said last (not on lrclib.net, SongRec missing…).
		if (ly && !off && !ly->status().empty()) {
			PangoLayout *pl = pango_cairo_create_layout(cr);
			PangoFontDescription *fd = pango_font_description_from_string(theme::font_small);
			pango_layout_set_font_description(pl, fd);
			pango_font_description_free(fd);
			pango_layout_set_text(pl, ly->status().c_str(), -1);
			pango_layout_set_width(pl, static_cast<int>(w * PANGO_SCALE));
			pango_layout_set_wrap(pl, PANGO_WRAP_WORD_CHAR);
			pango_layout_set_alignment(pl, PANGO_ALIGN_CENTER);
			pango_layout_set_height(pl, -3);
			pango_layout_set_ellipsize(pl, PANGO_ELLIPSIZE_END);
			cairo_set_source_rgba(cr, theme::text_dim.r, theme::text_dim.g, theme::text_dim.b, theme::text_dim.a);
			cairo_move_to(cr, pad, y + 44);
			pango_cairo_show_layout(cr, pl);
			g_object_unref(pl);
		}
		if (ly && !off && !ly->searching()) {
			const B2 buttons[] = {{"ly:retry", "Search again", "search"}, {"ly:listen", "Listen for it", "mic-vocal"}};
			const double gap = 8, bw = (w - gap) / 2, by = y + h - 50;
			for (int k = 0; k < 2; k++) {
				const double bx = pad + k * (bw + gap);
				fill_rounded(cr, bx, by, bw, 32, 16, k == 0 ? theme::accent : theme::tile_off);
				const Color fg = k == 0 ? theme::on_accent : theme::text;
				const double tw = text_width(buttons[k].label, theme::font_small);
				draw_named_icon(cr, server_->icons, buttons[k].icon, bx + (bw - tw) / 2 - 22, by + 8, 16, fg, scale);
				draw_text(cr, buttons[k].label, bx + (bw - tw) / 2, by, tw + 4, 32, theme::font_small, fg);
				add_hot(buttons[k].id, bx, by, bw, 32, 16);
			}
		}
		return;
	}
	// The lyrics as on the screen: in their style, colour and translation, on
	// a dark backdrop (their white letters read on it in light mode too).
	{
		const Color c = ly->colour();
		fill_rounded(cr, pad - 6, y + 4, w + 12, 104, 12, mix(rgb(0x111114), c, 0.10));
		ly->draw_in(cr, pad - 2, y + 6, w + 4, 100, scale);
	}
	// Timing: earlier / later, slower / faster, for this song.
	char info[96];
	std::snprintf(info, sizeof info, "This song: %+.2f s · %d%% speed", ly->song_delay() / 1000.0, ly->song_speed());
	draw_text(cr, info, pad, y + 112, w, 18, theme::font_small, theme::text_dim, Align::Center);
	// Refresh: wrong song, or badly timed? Look for the lyrics again.
	{
		const double bx = pad + w - 26, byy = y + 108;
		fill_rounded(cr, bx, byy, 26, 26, 13, theme::tile_off);
		draw_named_icon(cr, server_->icons, "refresh", bx + 6, byy + 6, 14, theme::text, scale);
		add_hot("ly:refresh", bx, byy, 26, 26, 13);
	}
	struct B {
		const char *id, *label;
	};
	const B buttons[] = {{"ly:earlier", "Earlier"}, {"ly:later", "Later"}, {"ly:slower", "Slower"},
		{"ly:faster", "Faster"}, {"ly:reset", "Reset"}};
	const double gap = 6, bw = (w - 4 * gap) / 5, by = y + 134;
	for (int k = 0; k < 5; k++) {
		const double bx = pad + k * (bw + gap);
		fill_rounded(cr, bx, by, bw, 28, 14, theme::tile_off);
		draw_text(cr, buttons[k].label, bx, by, bw, 28, theme::font_small, theme::text, Align::Center);
		add_hot(buttons[k].id, bx, by, bw, 28, 14);
	}
	const bool on = server_->config.lyrics_show;
	const std::string show = on ? "Showing on the screen" : "Show on the screen";
	const double sw = text_width(show, theme::font_small) + 40;
	fill_rounded(cr, (w_ - sw) / 2, by + 36, sw, 26, 13, on ? theme::accent : theme::tile_off);
	draw_named_icon(cr, server_->icons, "mic-vocal", (w_ - sw) / 2 + 10, by + 42, 14,
		on ? theme::on_accent : theme::text, scale);
	draw_text(cr, show, (w_ - sw) / 2 + 28, by + 36, sw - 34, 26, theme::font_small,
		on ? theme::on_accent : theme::text);
	add_hot("ly:show", (w_ - sw) / 2, by + 36, sw, 26, 13);
}

} // namespace arqen

namespace arqen {

// ============================================================================
// Right-click menu
// ============================================================================

namespace {
constexpr int kMenuPad = 6;
constexpr int kRowH = 32;
constexpr int kHeaderH = 26;
constexpr int kSepH = 9;

int row_height(const MenuItem &m) {
	switch (m.kind) {
	case MenuItem::Kind::Separator: return kSepH;
	case MenuItem::Kind::Header: return kHeaderH;
	default: return kRowH;
	}
}
} // namespace

ContextMenu::ContextMenu(Server *server) : Popover(server, 220, 100) {}

void ContextMenu::show(Output *output, wlr_box anchor, const std::string &edge,
		std::vector<MenuItem> items) {
	// The control centre shows its menus as pages of its own.
	if (server_->control_centre && server_->control_centre->take_menu(output, items)) return;
	items_ = std::move(items);
	bool marks = false, icons = false;
	int text = 0, h = 2 * kMenuPad;
	for (const MenuItem &m : items_) {
		h += row_height(m);
		marks = marks || m.kind == MenuItem::Kind::Check || m.kind == MenuItem::Kind::Radio;
		icons = icons || !m.icon.empty();
		text = std::max(text, text_width(m.label, m.kind == MenuItem::Kind::Header
			? theme::font_small : theme::font));
	}
	const int lead = (marks || icons) ? 30 : 0;
	const int w = std::clamp(text + lead + 2 * kMenuPad + 28, 180, 340);
	resize(w, h);
	if (is_open()) {
		redraw();
	}
	open(output, anchor, edge);
}

void ContextMenu::draw(cairo_t *cr, float scale) {
	bool lead = false;
	for (const MenuItem &m : items_) {
		lead = lead || !m.icon.empty() || m.kind == MenuItem::Kind::Check ||
			m.kind == MenuItem::Kind::Radio;
	}
	const double r = inner_radius(theme::ui_radius, kMenuPad);
	int y = kMenuPad;
	for (size_t i = 0; i < items_.size(); i++) {
		const MenuItem &m = items_[i];
		const int rh = row_height(m);
		if (m.kind == MenuItem::Kind::Separator) {
			cairo_set_source_rgba(cr, theme::text.r, theme::text.g, theme::text.b, 0.10);
			cairo_rectangle(cr, kMenuPad + 8, y + kSepH / 2.0 - 0.5, w_ - 2 * kMenuPad - 16, 1);
			cairo_fill(cr);
		} else if (m.kind == MenuItem::Kind::Header) {
			draw_text(cr, m.label, kMenuPad + 12, y + 4, w_ - 2 * kMenuPad - 24, rh - 4,
				theme::font_small, theme::text_dim);
		} else {
			const Color fg = !m.enabled ? with_alpha(theme::text, 0.35)
				: m.danger ? theme::danger : theme::text;
			double tx = kMenuPad + 12;
			if (lead) {
				const double cx = kMenuPad + 12 + 9, cy = y + rh / 2.0;
				if ((m.kind == MenuItem::Kind::Check || m.kind == MenuItem::Kind::Radio) && m.on) {
					if (m.kind == MenuItem::Kind::Radio) {
						cairo_set_source_rgba(cr, theme::accent.r, theme::accent.g, theme::accent.b, 1);
						cairo_new_path(cr);
						cairo_arc(cr, cx, cy, 4, 0, 2 * M_PI);
						cairo_fill(cr);
					} else {
						draw_glyph(cr, "check", cx, cy, 16, theme::accent);
					}
				} else if (m.kind == MenuItem::Kind::Radio) {
					cairo_set_source_rgba(cr, theme::text.r, theme::text.g, theme::text.b, 0.25);
					cairo_set_line_width(cr, 1.2);
					cairo_new_path(cr);   // or the ring joins up with the last thing drawn
					cairo_arc(cr, cx, cy, 4.5, 0, 2 * M_PI);
					cairo_stroke(cr);
				} else if (!m.icon.empty()) {
					draw_named_icon(cr, server_->icons, m.icon, cx - 8, cy - 8, 16, fg, scale);
				}
				tx += 28;
			}
			draw_text(cr, m.label, tx, y, w_ - tx - kMenuPad - 10, rh, theme::font, fg);
			if (m.enabled) {
				add_hot("item:" + std::to_string(i), kMenuPad, y, w_ - 2 * kMenuPad, rh, r);
			}
		}
		y += rh;
	}
}

void ContextMenu::activate(const std::string &id, uint32_t, double, double) {
	if (id.rfind("item:", 0) != 0) {
		return;
	}
	const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 5));
	if (i >= items_.size()) {
		return;
	}
	// Copy first: running it can rebuild panels, or open another menu.
	std::function<void()> run = items_[i].run;
	close();
	if (run) {
		run();
	}
}

} // namespace arqen

namespace arqen {

// ============================================================================
// Snap layouts
// ============================================================================

namespace {
constexpr int kThumbW = 84, kThumbH = 52, kThumbGap = 10, kSnapPad = 12;
}

SnapLayouts::SnapLayouts(Server *server) : Popover(server, 200, 80) {}

void SnapLayouts::fit_size() {
	const int n = std::max<int>(1, static_cast<int>(server_->config.snap_layouts.size()));
	// One row of up to 6; more wrap.
	const int per_row = std::min(n, 6);
	const int rows = (n + per_row - 1) / per_row;
	resize(2 * kSnapPad + per_row * kThumbW + (per_row - 1) * kThumbGap,
		2 * kSnapPad + rows * kThumbH + (rows - 1) * kThumbGap);
}

void SnapLayouts::draw(cairo_t *cr, float) {
	const auto &layouts = server_->config.snap_layouts;
	const int per_row = std::min<int>(std::max<int>(1, static_cast<int>(layouts.size())), 6);
	const double r = inner_radius(theme::ui_radius, kSnapPad);
	for (size_t li = 0; li < layouts.size(); li++) {
		const int col = static_cast<int>(li) % per_row, row = static_cast<int>(li) / per_row;
		const double tx = kSnapPad + col * (kThumbW + kThumbGap);
		const double ty = kSnapPad + row * (kThumbH + kThumbGap);
		// The little screen.
		rounded_rect(cr, tx, ty, kThumbW, kThumbH, std::min(r, 9.0));
		set_color(cr, with_alpha(theme::text, 0.06));
		cairo_fill(cr);
		for (size_t zi = 0; zi < layouts[li].size(); zi++) {
			const auto &z = layouts[li][zi];
			const double zx = tx + 3 + z[0] * (kThumbW - 6), zy = ty + 3 + z[1] * (kThumbH - 6);
			const double zw = z[2] * (kThumbW - 6) - 3, zh = z[3] * (kThumbH - 6) - 3;
			const std::string id = "z:" + std::to_string(li) + ":" + std::to_string(zi);
			const bool lit = hover_ == id;
			rounded_rect(cr, zx + 1.5, zy + 1.5, zw, zh, 4.5);
			set_color(cr, lit ? theme::accent : with_alpha(theme::text, theme::dark ? 0.20 : 0.16));
			cairo_fill(cr);
			add_hot(id, zx, zy, zw + 3, zh + 3, -1);
		}
	}
}

bool SnapLayouts::zone_of(const std::string &id, View::Zone *zone) const {
	if (id.rfind("z:", 0) != 0) {
		return false;
	}
	const size_t colon = id.find(':', 2);
	const size_t li = static_cast<size_t>(std::atoi(id.c_str() + 2));
	const size_t zi = static_cast<size_t>(std::atoi(id.c_str() + colon + 1));
	const auto &layouts = server_->config.snap_layouts;
	if (li >= layouts.size() || zi >= layouts[li].size()) {
		return false;
	}
	const auto &z = layouts[li][zi];
	*zone = View::Zone{z[0], z[1], z[2], z[3]};
	return true;
}

bool SnapLayouts::drag_motion(View *view, Output *output, double lx, double ly, View::Zone *zone) {
	if (!output || !server_->config.snap_bar || server_->config.snap_layouts.empty()) {
		drag_end();
		return false;
	}
	const wlr_box u = output->usable();
	const bool inside = is_open() && output_ == output && contains(lx, ly);
	// Appears when the window is brought to the top of the screen in the
	// middle (about where the bar shows), not anywhere along the top: the
	// rest of the top edge maximises, its corners tile to a quarter.
	const double reach = std::max(160.0, std::min(u.width * 0.18, 320.0));
	const bool near_top = ly < u.y + 60 && std::abs(lx - (u.x + u.width / 2.0)) < reach;
	if (!inside && !near_top) {
		drag_end();
		return false;
	}
	if (!is_open() || output_ != output || menu_mode_) {
		menu_mode_ = false;
		view_ = view;
		fit_size();
		open(output, wlr_box{u.x + u.width / 2, u.y, 1, 1}, "top");
	}
	// Which zone is under the pointer (Popover::motion finds it and
	// redraws through on_hover).
	motion(lx, ly);
	return zone_of(hover_, zone);
}

void SnapLayouts::drag_end() {
	if (is_open() && !menu_mode_) {
		close();
	}
}

void SnapLayouts::open_for(View *view, Output *output, wlr_box anchor) {
	if (!view || !output || server_->config.snap_layouts.empty()) {
		return;
	}
	menu_mode_ = true;
	view_ = view;
	fit_size();
	if (is_open()) {
		redraw();
	}
	open(output, anchor, "below");
}

void SnapLayouts::on_hover() {
	redraw();   // the hovered zone lights up in the accent colour
	if (!menu_mode_ || !view_) {
		return;
	}
	View::Zone z;
	if (zone_of(hover_, &z) && output_) {
		server_->show_snap_preview(view_->zone_frame(z, output_), view_);
	} else {
		server_->hide_snap_preview();
	}
}

void SnapLayouts::activate(const std::string &id, uint32_t, double, double) {
	View::Zone z;
	if (!menu_mode_ || !view_ || !zone_of(id, &z)) {
		return;
	}
	View *v = view_;
	Output *out = output_;
	close();
	v->tile_to(z, out);
	server_->focus(v);
}

void SnapLayouts::on_close() {
	if (menu_mode_) {
		server_->hide_snap_preview();
	}
}

void SnapLayouts::view_gone(View *view) {
	if (view_ == view) {
		view_ = nullptr;
		if (is_open()) close();
	}
}



// ---- The recording bar ------------------------------------------------------------------------

RecordBar::RecordBar(Server *server) : Popover(server, 360, 48) {}

void RecordBar::show_for(Output *output, wlr_box area) {
	if (!output) return;
	const Config &c = server_->config;
	// As wide as what it says.
	const std::string res = std::to_string(area.width) + "×" + std::to_string(area.height) + " · " +
		std::to_string(c.record_fps) + " fps";
	int w = 16 + 14 + 56 + text_width(res, theme::font_small) + 20;
	if (c.record_audio != "none") w += 34;
	w += 92 + 10;
	resize(w, 48);
	// Outside the area (else it would be in the video): under it, or over it.
	const wlr_box u = output->usable();
	const bool below = area.y + area.height + 10 + h_ <= u.y + u.height - 6;
	const bool above = area.y - 10 - h_ >= u.y + 6;
	if (!below && !above) return;
	open(output, below ? area : wlr_box{area.x, area.y - h_ - 14, area.width, 1}, "below");
}

void RecordBar::draw(cairo_t *cr, float scale) {
	Recorder *rec = server_->recorder.get();
	if (!rec) return;
	const Config &c = server_->config;
	double x = 16;
	const double cy = h_ / 2.0;
	// The red dot.
	cairo_new_path(cr);
	cairo_arc(cr, x + 5, cy, 5.5, 0, 2 * M_PI);
	set_color(cr, with_alpha(theme::danger, rec->starting() ? 0.5 : 1.0));
	cairo_fill(cr);
	x += 16;
	draw_text(cr, rec->starting() ? "Starting…" : rec->elapsed_text(), x, 0, 56, h_, theme::font_bold, theme::text);
	x += 58;
	const wlr_box a = rec->area();
	const std::string res = std::to_string(a.width) + "×" + std::to_string(a.height) + " · " +
		std::to_string(c.record_fps) + " fps";
	const int rw = text_width(res, theme::font_small);
	draw_text(cr, res, x, 0, rw + 4, h_, theme::font_small, theme::text_dim);
	x += rw + 14;
	if (c.record_audio != "none") {
		cairo_rectangle(cr, x - 6, cy - 10, 1, 20);
		set_color(cr, theme::divider);
		cairo_fill(cr);
		draw_named_icon(cr, server_->icons, c.record_audio == "mic" ? "mic" : "volume-2", x + 4, cy - 8, 16,
			theme::text, scale);
		x += 34;
	}
	// Stop.
	const double bw = 88, bh = 32, bx = w_ - 8 - bw, by = cy - bh / 2;
	fill_rounded(cr, bx, by, bw, bh, bh / 2, theme::danger);
	if (const double h = hover("stop"); h > 0.01) fill_rounded(cr, bx, by, bw, bh, bh / 2, rgb(0x000000, 0.12 * h));
	fill_rounded(cr, bx + 18, cy - 5, 10, 10, 2.5, rgb(0xffffff));
	draw_text(cr, "Stop", bx + 34, by, bw - 40, bh, theme::font_bold, rgb(0xffffff));
	add_hot("stop", bx, by, bw, bh, bh / 2);
}

void RecordBar::activate(const std::string &id, uint32_t button, double, double) {
	if (button != BTN_LEFT) return;
	if (id == "stop" && server_->recorder) {
		server_->recorder->stop();
		close();
	}
}

// ---- Personalise ------------------------------------------------------------------------------

namespace {
constexpr int kPW = 520, kPH = 312;
constexpr int kPicW = 112, kPicH = 70;
const char *const kAccents[] = {"#e8459a", "#8a63d2", "#4d8df6", "#2aa198", "#3d8f5a", "#d6a21e", "#f27a1a",
	"#c8102e"};
} // namespace

Personalize::Personalize(Server *server) : Popover(server, kPW, kPH) {}

Personalize::~Personalize() {
	*alive_token_ = false;
	for (auto &[path, surface] : thumbs_) {
		if (surface) cairo_surface_destroy(surface);
	}
}

// Pictures come only from your Wallpapers folder (~/Pictures/Wallpapers);
// Arqen's own drawn wallpapers are offered separately.
void Personalize::find_pictures() {
	pictures_.clear();
	const char *h = std::getenv("HOME");
	const std::string home = h ? h : "";
	std::vector<std::pair<std::filesystem::file_time_type, std::string>> found;
	for (const std::string &dir : {home + "/Pictures/Wallpapers"}) {
		std::error_code ec;
		std::filesystem::recursive_directory_iterator it(dir, std::filesystem::directory_options::skip_permission_denied, ec);
		for (int seen = 0; !ec && it != std::filesystem::recursive_directory_iterator() && seen < 400; it.increment(ec), seen++) {
			if (it.depth() > 2) it.disable_recursion_pending();
			if (!it->is_regular_file(ec)) continue;
			std::string ext = it->path().extension().string();
			std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
			if (ext != ".png" && ext != ".jpg" && ext != ".jpeg" && ext != ".webp") continue;
			if (std::filesystem::file_size(it->path(), ec) < 60000) continue;   // icons and the like
			found.push_back({it->last_write_time(ec), it->path().string()});
		}
		if (found.size() >= 6) break;
	}
	std::sort(found.begin(), found.end(), [](const auto &a, const auto &b) { return a.first > b.first; });
	const std::string &now = server_->config.wallpaper;
	if (!now.empty() && server_->config.wallpaper_type == "image") pictures_.push_back(now);
	for (const auto &[when, path] : found) {
		if (pictures_.size() >= 6) break;
		if (std::find(pictures_.begin(), pictures_.end(), path) != pictures_.end()) continue;
		pictures_.push_back(path);
	}
}

void Personalize::on_open() {
	find_pictures();
	for (const std::string &path : pictures_) {
		if (thumbs_.count(path)) continue;
		thumbs_[path] = nullptr;
		std::weak_ptr<bool> alive = alive_token_;
		server_->images->request(path, kPicW * 2, kPicH * 2, [this, alive, path](cairo_surface_t *s) {
			auto token = alive.lock();
			if (!token || !*token) {
				if (s) cairo_surface_destroy(s);
				return;
			}
			if (thumbs_[path]) cairo_surface_destroy(thumbs_[path]);
			thumbs_[path] = s;
			refresh();
		});
	}
}

void Personalize::draw(cairo_t *cr, float scale) {
	const Config &c = server_->config;
	const int pad = 18;
	// The tabs, and Settings on the right.
	struct Tab {
		const char *label, *icon;
	};
	const Tab tabs[] = {{"Wallpaper", "image"}, {"Colours", "palette"}};
	int x = pad;
	for (int i = 0; i < 2; i++) {
		const int tw = text_width(tabs[i].label, theme::font_bold) + 46, th = 34;
		if (i == tab_) fill_rounded(cr, x, pad, tw, th, th / 2.0, theme::field_bg);
		draw_named_icon(cr, server_->icons, tabs[i].icon, x + 14, pad + th / 2.0 - 8, 16,
			i == tab_ ? theme::accent : theme::text_dim, scale);
		draw_text(cr, tabs[i].label, x + 36, pad, tw - 40, th, theme::font_bold, i == tab_ ? theme::text : theme::text_dim);
		add_hot("tab:" + std::to_string(i), x, pad, tw, th, th / 2.0);
		x += tw + 6;
	}
	{
		const int bs = 34, bx = w_ - pad - bs;
		draw_named_icon(cr, server_->icons, "gear", bx + bs / 2.0 - 9, pad + bs / 2.0 - 9, 18, theme::text_dim, scale);
		add_hot("settings", bx, pad, bs, bs, bs / 2.0);
	}
	const int top = pad + 34 + 16;
	if (tab_ == 0) {
		// Four to a row: Arqen's own, your pictures, and "Browse".
		const int gap = (w_ - 2 * pad - 4 * kPicW) / 3;
		auto cell = [&](int k) {
			return wlr_box{pad + (k % 4) * (kPicW + gap), top + (k / 4) * (kPicH + 44), kPicW, kPicH};
		};
		int k = 0;
		auto frame = [&](const wlr_box &b, bool chosen) {
			if (!chosen) return;
			rounded_rect(cr, b.x - 3, b.y - 3, b.width + 6, b.height + 6, 15);
			set_color(cr, theme::accent);
			cairo_set_line_width(cr, 2.5);
			cairo_stroke(cr);
		};
		{
			const wlr_box b = cell(k++);
			cairo_save(cr);
			rounded_rect(cr, b.x, b.y, b.width, b.height, 12);
			cairo_clip(cr);
			cairo_translate(cr, b.x, b.y);
			draw_arqen_wallpaper(cr, c, b.width, b.height);
			cairo_restore(cr);
			frame(b, c.wallpaper_type == "arqen");
			draw_text(cr, "Arqen", b.x, b.y + b.height + 6, b.width, 18, theme::font_small, theme::text, Align::Center);
			add_hot("wall:arqen", b.x, b.y, b.width, b.height, 12);
		}
		for (size_t i = 0; i < pictures_.size() && k < 7; i++, k++) {
			const wlr_box b = cell(k);
			cairo_save(cr);
			rounded_rect(cr, b.x, b.y, b.width, b.height, 12);
			cairo_clip(cr);
			auto it = thumbs_.find(pictures_[i]);
			if (it != thumbs_.end() && it->second) {
				cairo_surface_t *img = it->second;
				const double iw = cairo_image_surface_get_width(img), ih = cairo_image_surface_get_height(img);
				const double k2 = std::max(b.width / iw, b.height / ih);
				cairo_translate(cr, b.x + (b.width - iw * k2) / 2, b.y + (b.height - ih * k2) / 2);
				cairo_scale(cr, k2, k2);
				cairo_set_source_surface(cr, img, 0, 0);
				cairo_pattern_set_filter(cairo_get_source(cr), CAIRO_FILTER_GOOD);
				cairo_paint(cr);
			} else {
				set_color(cr, theme::field_bg);
				cairo_paint(cr);
			}
			cairo_restore(cr);
			frame(b, c.wallpaper_type == "image" && c.wallpaper == pictures_[i]);
			const std::filesystem::path pp(pictures_[i]);
			std::string name = pp.stem().string();
			if (name.find_first_not_of("0123456789x") == std::string::npos) {
				name = pp.parent_path().filename().string();
				if (name == "default" || name == "images" || name == "contents") name = pp.parent_path().parent_path().filename().string();
			}
			draw_text(cr, name, b.x, b.y + b.height + 6, b.width, 18, theme::font_small, theme::text_dim, Align::Center);
			add_hot("wall:" + std::to_string(i), b.x, b.y, b.width, b.height, 12);
		}
		const wlr_box b = cell(k);
		fill_rounded(cr, b.x, b.y, b.width, b.height, 12, theme::field_bg);
		draw_named_icon(cr, server_->icons, "image", b.x + b.width / 2.0 - 11, b.y + b.height / 2.0 - 16, 22, theme::text,
			scale);
		draw_text(cr, "Browse…", b.x, b.y + b.height / 2.0 + 8, b.width, 18, theme::font_small, theme::text, Align::Center);
		add_hot("browse", b.x, b.y, b.width, b.height, 12);
		return;
	}
	// Colours: light or dark, then the accent.
	draw_text(cr, "Mode", pad + 2, top, 200, 20, theme::font_title, theme::text_dim);
	const int mw = (w_ - 2 * pad - 12) / 2, mh = 64;
	for (int i = 0; i < 2; i++) {
		const bool dark = i == 1;
		const int mx = pad + i * (mw + 12), my = top + 28;
		const double hue = theme::accent_hue(), tint = theme::accent_tint();
		fill_rounded(cr, mx, my, mw, mh, 16, dark ? theme::hsl(hue, 0.20 * tint, 0.145) : theme::hsl(hue, 0.45 * tint, 0.97));
		fill_rounded(cr, mx + 14, my + 14, 36, 36, 18, theme::accent);
		draw_text(cr, dark ? "Dark" : "Light", mx + 62, my, mw - 70, mh, theme::font_bold,
			dark ? rgb(0xffffff) : theme::hsl(hue, 0.19 * tint, 0.15));
		if (c.dark == dark) {
			rounded_rect(cr, mx - 2, my - 2, mw + 4, mh + 4, 18);
			set_color(cr, theme::accent);
			cairo_set_line_width(cr, 2.5);
			cairo_stroke(cr);
		}
		add_hot(dark ? "mode:dark" : "mode:light", mx, my, mw, mh, 16);
	}
	const int ay = top + 28 + mh + 22;
	draw_text(cr, "Accent", pad + 2, ay, 200, 20, theme::font_title, theme::text_dim);
	const int n = static_cast<int>(std::size(kAccents));
	const int ds = 30, dgap = (w_ - 2 * pad - n * ds) / std::max(1, n - 1);
	for (int i = 0; i < n; i++) {
		const double cx = pad + ds / 2.0 + i * (ds + dgap), cy = ay + 28 + ds / 2.0;
		Color col;
		parse_color(kAccents[i], col);
		cairo_new_path(cr);
		cairo_arc(cr, cx, cy, ds / 2.0, 0, 2 * M_PI);
		set_color(cr, col);
		cairo_fill(cr);
		const bool chosen = !c.accent_auto && std::fabs(col.r - c.accent.r) < 0.01 && std::fabs(col.g - c.accent.g) < 0.01 &&
			std::fabs(col.b - c.accent.b) < 0.01;
		if (chosen) {
			cairo_new_path(cr);
			cairo_arc(cr, cx, cy, ds / 2.0 + 4, 0, 2 * M_PI);
			set_color(cr, col);
			cairo_set_line_width(cr, 2);
			cairo_stroke(cr);
			draw_named_icon(cr, server_->icons, "check", cx - 8, cy - 8, 16, rgb(0xffffff), scale);
		}
		add_hot(std::string("accent:") + kAccents[i], cx - ds / 2.0, cy - ds / 2.0, ds, ds, ds / 2.0);
	}
	// Or the wallpaper's own colour (follows it when the wallpaper changes).
	{
		const int ry = ay + 28 + ds + 12, rh = 40, rw = w_ - 2 * pad;
		fill_rounded(cr, pad, ry, rw, rh, rh / 2.0, theme::tile_off);
		// A little rainbow dot, then the words, then the switch.
		for (int seg = 0; seg < 12; seg++) {
			cairo_new_path(cr);
			cairo_arc(cr, pad + 22, ry + rh / 2.0, 7, seg * M_PI / 6, (seg + 1) * M_PI / 6);
			const double hue = seg / 12.0;
			cairo_set_source_rgb(cr, 0.5 + 0.5 * std::cos(2 * M_PI * hue), 0.5 + 0.5 * std::cos(2 * M_PI * (hue - 1 / 3.0)),
				0.5 + 0.5 * std::cos(2 * M_PI * (hue - 2 / 3.0)));
			cairo_set_line_width(cr, 4);
			cairo_stroke(cr);
		}
		draw_text(cr, "Use the wallpaper's colour", pad + 40, ry, rw - 110, rh, theme::font_bold, theme::text);
		const int sw = 40, sh = 22, sx = pad + rw - sw - 12, sy = ry + (rh - sh) / 2;
		fill_rounded(cr, sx, sy, sw, sh, sh / 2.0, c.accent_auto ? theme::accent : with_alpha(theme::text, 0.22));
		const double kx = c.accent_auto ? sx + sw - sh / 2.0 : sx + sh / 2.0;
		cairo_new_path(cr);
		cairo_arc(cr, kx, sy + sh / 2.0, sh / 2.0 - 3, 0, 2 * M_PI);
		set_color(cr, rgb(0xffffff));
		cairo_fill(cr);
		add_hot("accent:auto", pad, ry, rw, rh, rh / 2.0);
	}
}

void Personalize::activate(const std::string &id, uint32_t button, double, double) {
	if (button != BTN_LEFT) return;
	if (id.rfind("tab:", 0) == 0) {
		tab_ = std::atoi(id.c_str() + 4);
	} else if (id == "settings" || id == "browse") {
		close();
		server_->open_settings("appearance");
		return;
	} else if (id == "wall:arqen") {
		server_->write_setting("wallpaper_type", "arqen");
	} else if (id.rfind("wall:", 0) == 0) {
		const size_t i = std::stoul(id.substr(5));
		if (i < pictures_.size()) {
			server_->write_setting("wallpaper", pictures_[i]);
			server_->write_setting("wallpaper_type", "image");
		}
	} else if (id == "mode:dark" || id == "mode:light") {
		server_->write_setting("theme", id.substr(5));
	} else if (id == "accent:auto") {
		server_->write_setting("accent_auto", server_->config.accent_auto ? "false" : "true");
	} else if (id.rfind("accent:", 0) == 0) {
		server_->write_setting("accent_auto", "false");
		server_->write_setting("accent", id.substr(7));
	}
	redraw();
}

} // namespace arqen
