#include "alerts.hpp"

#include <algorithm>
#include <vector>

#include "anim.hpp"
#include "notify.hpp"
#include "panel.hpp"
#include "server.hpp"
#include "system.hpp"

namespace arqen {

namespace {

constexpr double kStartQuiet = 8000;   // the status fills in bit by bit after starting
constexpr double kLeaveWait = 4000;    // gone for this long before it's said

std::string icon_for(const std::string &kind, const std::string &via) {
	if (kind == "mouse") return "input-mouse-symbolic";
	if (kind == "keyboard") return "input-keyboard-symbolic";
	if (kind == "headphones") return "audio-headphones-symbolic";
	if (kind == "speaker" || kind == "audio") return "audio-speakers-symbolic";
	if (kind == "gamepad") return "input-gaming-symbolic";
	if (kind == "phone") return "phone-symbolic";
	if (kind == "tablet") return "input-tablet-symbolic";
	if (kind == "computer") return "computer-symbolic";
	if (kind == "drive") return "drive-removable-media-symbolic";
	if (kind == "camera") return "camera-web-symbolic";
	if (kind == "input") return "input-keyboard-symbolic";
	if (via == "Bluetooth") return "bluetooth-active-symbolic";
	return "drive-removable-media-symbolic";
}

// What a USB device is, from its interface classes (":080650:030102:").
std::string usb_kind(const std::string &interfaces) {
	auto has = [&](const char *cls) { return interfaces.find(std::string(":") + cls) != std::string::npos; };
	if (has("08")) return "drive";
	if (has("06")) return "phone";    // MTP / PTP: a phone or a camera sharing its files
	if (has("0e")) return "camera";
	if (has("01")) return "audio";
	if (has("03")) return "input";
	return "other";
}

} // namespace

Alerts::Alerts(Server *server) : server_(server), started_(now_ms()) {
	timer_ = wl_event_loop_add_timer(server_->loop, &Alerts::handle_timer, this);
}

Alerts::~Alerts() {
	if (timer_) wl_event_source_remove(timer_);
}

void Alerts::quiet_for(double ms) {
	// (Set, not stretched: waking ends the long quiet that going to sleep began.)
	quiet_until_ = now_ms() + ms;
}

bool Alerts::quiet() const {
	const double now = now_ms();
	return now - started_ < kStartQuiet || now < quiet_until_;
}

void Alerts::status_changed() {
	const SystemStatus *st = server_->status.get();
	if (!st) return;
	const Config &c = server_->config;

	// ---- The charger ----
	// Only on a computer with a battery (a desktop is always "plugged in").
	// The charger's own word first ("online"); a worn battery can say
	// "Discharging" with the charger in.
	if (st->has_battery) {
		const int plugged = st->on_mains >= 0 ? st->on_mains : (st->charging ? 1 : 0);
		if (plugged_ >= 0 && plugged != plugged_) {
			if (plugged) {
				for (Output *o : server_->outputs) {
					for (auto &p : o->panels) p->charge_animation();
				}
			}
			if (c.charger_notifications && server_->notifications && now_ms() - started_ >= kStartQuiet) {
				const int level = std::clamp(st->battery, 0, 100);
				const int tens = std::clamp((level + 5) / 10 * 10, 0, 100);
				const std::string icon = "battery-level-" + std::to_string(tens) +
					(plugged ? (tens == 100 ? "-charged-symbolic" : "-charging-symbolic") : "-symbolic");
				std::string body;
				if (plugged) {
					body = std::to_string(level) + "%" +
						(st->battery_state == "Not charging" ? " · held, not charging (protecting the battery)"
							: level >= 100 ? " · full" : " · charging");
				} else {
					body = std::to_string(level) + "% left";
				}
				power_note_ = server_->notifications->post(plugged ? "Charger connected" : "Charger disconnected", body,
					icon, 0, power_note_);
			}
		}
		plugged_ = plugged;
	}

	// ---- Devices: Bluetooth and phones through KDE Connect ----
	// (2.4 GHz receivers' devices are left out: they come and go from the
	// list as they doze. The receiver itself is a USB device.)
	std::map<std::string, Dev> now;
	for (const LinkedDevice &d : st->devices) {
		if (d.via != "Bluetooth") continue;
		now["bt:" + (d.id.empty() ? d.name : d.id)] = Dev{d.name, d.kind, d.via, d.battery};
	}
	for (const LinkedDevice &d : st->phones) {
		now["kdc:" + (d.id.empty() ? d.name : d.id)] = Dev{d.name, d.kind, "KDE Connect", d.battery};
	}
	if (known_) {
		for (const auto &[key, d] : now) {
			if (!devices_.count(key)) arrived(key, d);
		}
		for (const auto &[key, d] : devices_) {
			if (!now.count(key)) left(key, d);
		}
	}
	known_ = true;
	devices_ = std::move(now);
}

void Alerts::usb_event(bool added, const std::string &interfaces, const std::string &name) {
	if (name.empty()) return;
	// Hubs (class 09) are the plumbing, not something you plugged in.
	if (interfaces.rfind(":09", 0) == 0) return;
	const std::string key = "usb:" + name;
	Dev d{name, usb_kind(interfaces), "USB", -1};
	if (added) {
		// (Two of the same: said once.)
		if (usb_.count(key)) return;
		usb_[key] = d;
		arrived(key, d);
	} else {
		auto it = usb_.find(key);
		if (it != usb_.end()) {
			d = it->second;
			usb_.erase(it);
		}
		left(key, d);
	}
}

void Alerts::arrived(const std::string &key, const Dev &d) {
	// Back before its leaving was said: as if it never went.
	if (leaving_.erase(key)) return;
	if (quiet()) return;
	say(key, d, true);
}

void Alerts::left(const std::string &key, const Dev &d) {
	if (quiet()) {
		leaving_.erase(key);
		return;
	}
	leaving_[key] = Leaving{d, now_ms()};
	wl_event_source_timer_update(timer_, static_cast<int>(kLeaveWait) + 50);
}

int Alerts::handle_timer(void *data) {
	static_cast<Alerts *>(data)->flush_leaving();
	return 0;
}

void Alerts::flush_leaving() {
	const double now = now_ms();
	double next = 0;
	for (auto it = leaving_.begin(); it != leaving_.end();) {
		if (now - it->second.at >= kLeaveWait) {
			if (!quiet()) say(it->first, it->second.dev, false);
			it = leaving_.erase(it);
		} else {
			const double wait = kLeaveWait - (now - it->second.at);
			next = next > 0 ? std::min(next, wait) : wait;
			++it;
		}
	}
	if (next > 0) wl_event_source_timer_update(timer_, static_cast<int>(next) + 50);
}

void Alerts::say(const std::string &key, const Dev &d, bool connected) {
	if (!server_->config.device_notifications || !server_->notifications) return;
	const std::string name = d.name.empty() ? std::string("A device") : d.name;
	std::string body = d.via;
	if (connected && d.battery >= 0 && d.battery <= 100) body += " · battery " + std::to_string(d.battery) + "%";
	uint32_t &note = notes_[key];
	note = server_->notifications->post(name + (connected ? " connected" : " disconnected"), body,
		icon_for(d.kind, d.via), 0, note);
}

} // namespace arqen
