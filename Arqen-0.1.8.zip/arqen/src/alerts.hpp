// Notifications for things plugged in and taken out: the charger, and
// devices connecting and disconnecting (Bluetooth, phones through KDE
// Connect, USB). The charger going in also plays the battery's charging
// animation on every panel.
#pragma once

#include <cstdint>
#include <map>
#include <string>

struct wl_event_source;

namespace arqen {

class Server;

class Alerts {
public:
	explicit Alerts(Server *server);
	~Alerts();
	Alerts(const Alerts &) = delete;
	Alerts &operator=(const Alerts &) = delete;

	// The status changed (SystemStatus::changed): the charger, the devices.
	void status_changed();
	// A USB device came or went (from udev, as it happens). `interfaces` is
	// udev's ID_USB_INTERFACES (":080650:" for a USB stick...).
	void usb_event(bool added, const std::string &interfaces, const std::string &name);
	// Going to sleep or waking up: devices drop off and come back by
	// themselves, so nothing is said about them for a while.
	void quiet_for(double ms);

private:
	struct Dev {
		std::string name, kind, via;
		int battery = -1;
	};
	void arrived(const std::string &key, const Dev &d);
	void left(const std::string &key, const Dev &d);
	void say(const std::string &key, const Dev &d, bool connected);
	bool quiet() const;
	static int handle_timer(void *data);
	void flush_leaving();

	Server *server_;
	double started_ = 0;
	double quiet_until_ = 0;
	bool known_ = false;
	int plugged_ = -1;              // the charger: 1 in, 0 out, -1 not known yet
	uint32_t power_note_ = 0;       // the charger's notification (each one replaces the last)
	std::map<std::string, Dev> devices_;   // connected now (Bluetooth, KDE Connect)
	std::map<std::string, Dev> usb_;       // plugged in now (USB), by name
	// Gone, but not said yet: a device that drops off for a moment and comes
	// straight back (a phone's Wi-Fi napping, headphones reconnecting) isn't
	// news. Said after a few seconds if it's still gone.
	struct Leaving {
		Dev dev;
		double at = 0;
	};
	std::map<std::string, Leaving> leaving_;
	std::map<std::string, uint32_t> notes_;   // device -> its notification (replaced, not stacked)
	wl_event_source *timer_ = nullptr;
};

} // namespace arqen
