#include "overview.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <linux/input-event-codes.h>

#include "apps.hpp"
#include "draw.hpp"
#include "glyphs.hpp"

namespace arqen {

namespace {

constexpr int kCardRadius = 18;
constexpr int kGap = 16;          // between windows in a desktop's row
constexpr int kBadge = 18;        // app icon beside each window's name
constexpr int kSearchW = 380, kSearchH = 40;
constexpr int kAppCell = 96, kAppsH = 104;

bool no_input(wlr_scene_buffer *, double *, double *) {
	return false;
}

std::string lower(std::string s) {
	for (char &c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
	return s;
}

int ri(double v) {
	return static_cast<int>(std::lround(v));
}

bool inside(const wlr_box &b, double x, double y) {
	return b.width > 0 && x >= b.x && y >= b.y && x < b.x + b.width && y < b.y + b.height;
}

bool inside(const GhostRect &r, double x, double y) {
	return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h;
}

void set_rect_color(wlr_scene_rect *rect, const Color &c) {
	// Scene colours are premultiplied.
	const float f[4] = {static_cast<float>(c.r * c.a), static_cast<float>(c.g * c.a), static_cast<float>(c.b * c.a),
		static_cast<float>(c.a)};
	wlr_scene_rect_set_color(rect, f);
}

// Dark like GNOME's in the dark theme; a pale frosted version in the light one.
Color kText() { return theme::dark ? rgb(0xffffff) : rgb(0x1c1c21); }
Color kTextDim() { return theme::dark ? rgb(0xffffff, 0.62) : rgb(0x1c1c21, 0.62); }
Color kField() { return theme::dark ? rgb(0xffffff, 0.11) : rgb(0x000000, 0.07); }
Color kDim() { return theme::dark ? rgb(0x161619) : rgb(0xeeeef2); }

} // namespace

Overview::Overview(Server *server) : server_(server) {}

Overview::~Overview() {
	if (rebuild_) wl_event_source_remove(rebuild_);
	server_->anim->cancel(anim_);
	server_->anim->cancel(glide_anim_);
	windows_.clear();
	if (drag_layer_) {
		wlr_scene_node_destroy(&drag_layer_->node);
		drag_layer_ = nullptr;
	}
	for (auto &s : screens_) {
		s->thumbs.clear();
		wlr_scene_node_destroy(&s->tree->node);
	}
	screens_.clear();
}

Overview::Screen *Overview::screen_for(Output *output) {
	for (auto &s : screens_) {
		if (s->output == output) return s.get();
	}
	return nullptr;
}

// ---- opening and closing ------------------------------------------------------------

void Overview::toggle(Output *from) {
	if (open_) {
		close();
	} else {
		open(from);
	}
}

void Overview::open(Output *from) {
	if (open_) {
		return;
	}
	const Config &c = server_->config;
	const double ms = c.animate(c.anim_overview) ? c.ms(260) : 0;
	if (!screens_.empty()) {
		// Still closing: turn round.
		open_ = true;
		pick_ = nullptr;
		server_->anim->cancel(anim_);
		anim_ = server_->anim->tween(t_, 1.0, ms, [this] { apply(t_); }, [this] { anim_ = 0; });
		return;
	}
	server_->close_popups();
	server_->end_switcher();
	server_->finish_workspace_switch();
	if (!from) {
		from = server_->output_at(server_->cursor->x, server_->cursor->y);
	}
	open_ = true;
	pick_ = nullptr;
	query_.clear();
	selected_ = -1;
	hover_ = nullptr;
	pressed_ = nullptr;
	dragging_ = false;
	Output *primary = from;
	for (Output *o : server_->outputs) {
		if (o->enabled()) {
			if (!primary) primary = o;
			build_screen(o, o == primary);
		}
	}
	if (screens_.empty()) {
		open_ = false;
		return;
	}
	// A copy of every window (on every workspace: search finds them all).
	for (auto it = server_->views.rbegin(); it != server_->views.rend(); ++it) {
		View *v = *it;
		if (!v->mapped) continue;
		Screen *s = screen_for(server_->output_for_view(v));
		if (!s) s = screens_.front().get();
		auto w = std::make_unique<Window>();
		w->view = v;
		w->screen = s;
		const wlr_box f = v->frame_box();
		w->real = GhostRect{static_cast<double>(f.x), static_cast<double>(f.y), static_cast<double>(f.width),
			static_cast<double>(f.height), 1};
		const float none[4] = {0, 0, 0, 0};
		w->glow = wlr_scene_rect_create(s->windows, 1, 1, none);
		w->glow->accepts_input = false;
		wlr_scene_node_set_enabled(&w->glow->node, false);
		// A minimized window's whole tree is disabled, and Ghost::copy needs
		// live coordinates to place the parts. Flash the root back on just
		// for this synchronous copy (single-threaded: nothing renders in
		// between), then leave it exactly as it was.
		const bool tree_was_enabled = v->tree->node.enabled;
		if (!tree_was_enabled) {
			wlr_scene_node_set_enabled(&v->tree->node, true);
		}
		w->ghost = std::make_unique<Ghost>(s->windows, &v->tree->node, f.x, f.y, std::max(1, f.width),
			std::max(1, f.height));
		if (!tree_was_enabled) {
			wlr_scene_node_set_enabled(&v->tree->node, false);
		}
		w->badge = wlr_scene_buffer_create(s->windows, nullptr);
		w->badge->point_accepts_input = no_input;
		{
			Canvas canvas(kBadge, kBadge, s->output->output->scale);
			draw_icon(canvas.cr(), server_->icons, server_->apps.icon_for(v->app_id(), v->title()), v->title(), 0, 0, kBadge,
				s->output->output->scale);
			canvas.present(w->badge);
		}
		w->label = wlr_scene_buffer_create(s->windows, nullptr);
		w->label->point_accepts_input = no_input;
		w->close = wlr_scene_buffer_create(s->windows, nullptr);
		w->close->point_accepts_input = no_input;
		wlr_scene_node_set_enabled(&w->label->node, false);
		wlr_scene_node_set_enabled(&w->close->node, false);
		windows_.push_back(std::move(w));
	}
	// A window being dragged goes up here, over every screen's card (in its
	// own screen's tree the next screen's blur and card were drawn over it).
	drag_layer_ = wlr_scene_tree_create(server_->layer_overview);
	// The real windows (and the desktop icons) step aside while it's open.
	wlr_scene_node_set_enabled(&server_->layer_views->node, false);
	wlr_scene_node_set_enabled(&server_->layer_fullscreen->node, false);
	wlr_scene_node_set_enabled(&server_->layer_desktop->node, false);
	layers_hidden_ = true;
	wlr_seat_pointer_notify_clear_focus(server_->seat);

	layout();
	t_ = 0;
	apply(0);
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(t_, 1.0, ms, [this] { apply(t_); }, [this] { anim_ = 0; });
	server_->redraw_panels();
}

void Overview::close(View *pick) {
	if (!open_) {
		return;
	}
	open_ = false;
	pick_ = pick;
	pressed_ = nullptr;
	dragging_ = false;
	show_drop_row(-1);
	set_hover(nullptr);
	select(-1);
	if (pick && !pick->sticky) {
		Output *where = server_->output_for_view(pick);
		if (pick->workspace != server_->shown_workspace(where)) server_->switch_workspace(pick->workspace, false, where);
	}
	if (pick && pick->minimized) {
		pick->minimized = false;   // it comes back with the others
		pick->sync_enabled();
		server_->views_changed();
	}
	// Windows of the workspace go back where they are; the rest fade.
	for (auto &w : windows_) {
		const wlr_box f = w->view->frame_box();
		w->real = GhostRect{static_cast<double>(f.x), static_cast<double>(f.y), static_cast<double>(f.width),
			static_cast<double>(f.height), 1};
		if (w->in_layout) w->place = w->ghost->current;   // from wherever a glide got to
	}
	server_->anim->cancel(glide_anim_);
	glide_anim_ = 0;
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(t_, 0.0, c.animate(c.anim_overview) ? c.ms(240) : 0, [this] { apply(t_); },
		[this] {
			anim_ = 0;
			if (!open_) finish_close();
		});
}

void Overview::finish_close() {
	View *pick = pick_;
	pick_ = nullptr;
	destroy_all();
	if (pick && std::find(server_->views.begin(), server_->views.end(), pick) != server_->views.end() &&
			pick->mapped) {
		server_->focus(pick);
	}
	server_->process_motion(0);
	server_->redraw_panels();
}

void Overview::destroy_all() {
	if (rebuild_) {
		wl_event_source_remove(rebuild_);
		rebuild_ = nullptr;
	}
	server_->anim->cancel(anim_);
	server_->anim->cancel(glide_anim_);
	anim_ = glide_anim_ = 0;
	windows_.clear();
	if (drag_layer_) {
		wlr_scene_node_destroy(&drag_layer_->node);
		drag_layer_ = nullptr;
	}
	for (auto &s : screens_) {
		s->thumbs.clear();
		wlr_scene_node_destroy(&s->tree->node);
	}
	screens_.clear();
	hover_ = nullptr;
	pressed_ = nullptr;
	if (layers_hidden_) {
		layers_hidden_ = false;
		wlr_scene_node_set_enabled(&server_->layer_views->node, true);
		wlr_scene_node_set_enabled(&server_->layer_fullscreen->node, true);
		wlr_scene_node_set_enabled(&server_->layer_desktop->node, true);
		for (View *v : server_->views) {
			v->sync_enabled();
		}
	}
}

void Overview::view_gone(View *view) {
	if (hover_ && hover_->view == view) hover_ = nullptr;
	if (pressed_ && pressed_->view == view) {
		pressed_ = nullptr;
		dragging_ = false;
		show_drop_row(-1);
	}
	if (pick_ == view) pick_ = nullptr;
	const size_t before = windows_.size();
	windows_.erase(std::remove_if(windows_.begin(), windows_.end(),
		[view](const std::unique_ptr<Window> &w) { return w->view == view; }), windows_.end());
	if (windows_.size() != before && open_) {
		layout();
		glide();
	}
}

void Overview::output_gone(Output *output) {
	if (screen_for(output)) {
		open_ = false;
		pick_ = nullptr;
		destroy_all();
	}
}

void Overview::workspaces_changed() {
	if (!open_ || screens_.empty()) {
		return;
	}
	if (!rebuild_) {
		rebuild_ = wl_event_loop_add_idle(server_->loop, &Overview::handle_rebuild, this);
	}
}

void Overview::handle_rebuild(void *data) {
	auto *self = static_cast<Overview *>(data);
	self->rebuild_ = nullptr;
	self->rebuild();
}

void Overview::rebuild() {
	if (!open_ || screens_.empty()) {
		return;
	}
	for (auto &s : screens_) {
		const int ws = s->output->workspace;
		s->slide_dir = ws > s->shown_ws ? 1 : ws < s->shown_ws ? -1 : 0;
		s->shown_ws = ws;
		build_strip(*s);
	}
	layout();
	glide();
	for (auto &s : screens_) s->slide_dir = 0;
}

// ---- building ---------------------------------------------------------------------------

void Overview::build_screen(Output *output, bool primary) {
	auto s = std::make_unique<Screen>();
	s->output = output;
	s->primary = primary;
	s->shown_ws = output->workspace;
	s->tree = wlr_scene_tree_create(server_->layer_overview);
	s->tree->node.data = &tag;
	const wlr_box o = output->box();
	// A little past the screen's edges, so the blur doesn't darken them.
	int ml, mt, mr, mb;
	blur_margins(server_->outputs, s->output, 96, &ml, &mt, &mr, &mb);
	s->blur = wlr_scene_blur_create(s->tree, o.width + ml + mr, o.height + mt + mb);
	wlr_scene_node_set_position(&s->blur->node, o.x - ml, o.y - mt);
	wlr_scene_blur_set_strength(s->blur, 1.0f);
	const float dim[4] = {0, 0, 0, 0};
	s->dim = wlr_scene_rect_create(s->tree, o.width, o.height, dim);
	wlr_scene_node_set_position(&s->dim->node, o.x, o.y);
	// (No shadow under the card: drawn over the blur it showed as a dark
	// smudge down one side.)
	for (auto &p : s->peek) {
		p = wlr_scene_buffer_create(s->tree, nullptr);
		wlr_scene_node_set_enabled(&p->node, false);
	}
	s->card = wlr_scene_buffer_create(s->tree, nullptr);
	s->card->point_accepts_input = no_input;
	s->drop_hl = wlr_scene_rect_create(s->tree, 1, 1, dim);
	wlr_scene_rect_set_corner_radius(s->drop_hl, 14);
	s->drop_hl->accepts_input = false;
	wlr_scene_node_set_enabled(&s->drop_hl->node, false);
	s->strip = wlr_scene_tree_create(s->tree);
	s->search = wlr_scene_buffer_create(s->tree, nullptr);
	s->apps = wlr_scene_buffer_create(s->tree, nullptr);
	s->add = wlr_scene_buffer_create(s->tree, nullptr);
	wlr_scene_node_set_enabled(&s->add->node, false);
	s->label = wlr_scene_buffer_create(s->tree, nullptr);
	s->label->point_accepts_input = no_input;
	wlr_scene_node_set_enabled(&s->label->node, false);
	wlr_scene_node_set_enabled(&s->search->node, false);
	// Clipped to their rounded shapes, so nothing square shows round them
	// (the field's corners were drawing as a dark box over the blur).
	wlr_scene_buffer_set_corner_radii(s->search, corner_radii_all(kSearchH / 2));
	wlr_scene_buffer_set_corner_radii(s->label, corner_radii_all(13));
	wlr_scene_buffer_set_corner_radii(s->add, corner_radii_all(kCardRadius));
	wlr_scene_node_set_enabled(&s->apps->node, false);
	s->windows = wlr_scene_tree_create(s->tree);
	screens_.push_back(std::move(s));
	build_strip(*screens_.back());
}

// The workspaces, small, in a row (or a column) at the edge chosen in
// Settings › Workspaces (top, under the search; bottom; left; right): each
// one's wallpaper and its windows, the one shown ringed in the accent with a
// ✕ to remove it, and a "+" after them. Drag a window onto one to move it
// there; click one to go to it. On the main screen.
void Overview::build_strip(Screen &s) {
	s.thumbs.clear();
	// (Their scene nodes live in s.strip: start it afresh.)
	wlr_scene_node_destroy(&s.strip->node);
	s.strip = wlr_scene_tree_create(s.tree);
	wlr_scene_node_place_below(&s.strip->node, &s.search->node);
	s.strip_box = wlr_box{};
	s.strip_add = wlr_box{};
	s.remove_box = wlr_box{};
	s.strip_bits.clear();
	desk_geometry(s);
	const wlr_box o = s.output->box();
	const int count = std::max(1, server_->workspace_count);
	const int tw = s.thumb_w, th = s.thumb_h;
	auto place = [&](int i) {
		return wlr_box{s.thumb_x, s.rows_top + i * s.row_h + 12, tw, th};
	};
	s.strip_box = wlr_box{s.thumb_x, s.rows_top, tw, count * s.row_h};
	const double k = static_cast<double>(tw) / std::max(1, o.width);
	const float none[4] = {0, 0, 0, 0};
	for (int i = 0; i < count; i++) {
		auto t = std::make_unique<WsThumb>();
		t->index = i;
		t->box = place(i);
		const bool shown = i == s.output->workspace;
		t->ring = wlr_scene_rect_create(s.strip, tw + 6, th + 6, none);
		wlr_scene_node_set_position(&t->ring->node, t->box.x - 3, t->box.y - 3);
		wlr_scene_rect_set_corner_radius(t->ring, 11);
		t->ring->accepts_input = false;
		set_rect_color(t->ring, shown ? with_alpha(theme::accent, alpha_) : rgb(0xffffff, 0.0));
		t->wall = wlr_scene_buffer_create(s.strip, s.output->wallpaper ? s.output->wallpaper->buffer : nullptr);
		wlr_scene_node_set_position(&t->wall->node, t->box.x, t->box.y);
		wlr_scene_buffer_set_dest_size(t->wall, tw, th);
		wlr_scene_buffer_set_corner_radii(t->wall, corner_radii_all(8));
		wlr_scene_buffer_set_opacity(t->wall, static_cast<float>(alpha_));
		t->wall->point_accepts_input = no_input;
		// Its windows, tiny, where they are.
		for (auto it = server_->views.rbegin(); it != server_->views.rend(); ++it) {
			View *v = *it;
			if (!v->mapped || v->minimized || (v->workspace != i && !v->sticky) ||
					server_->output_for_view(v) != s.output) {
				continue;
			}
			const wlr_box f = v->frame_box();
			auto g = std::make_unique<Ghost>(s.strip, &v->tree->node, f.x, f.y, std::max(1, f.width),
				std::max(1, f.height));
			GhostRect mr{t->box.x + (f.x - o.x) * k, t->box.y + (f.y - o.y) * k, std::max(1.0, f.width * k),
				std::max(1.0, f.height * k), alpha_};
			// A window bigger than the screen, or partly off it (common at a
			// high scale), stays inside the picture instead of poking out.
			if (mr.w > tw || mr.h > th) {
				const double fit = std::min(tw / mr.w, th / mr.h);
				mr.w *= fit;
				mr.h *= fit;
			}
			mr.x = std::clamp(mr.x, static_cast<double>(t->box.x), t->box.x + tw - mr.w);
			mr.y = std::clamp(mr.y, static_cast<double>(t->box.y), t->box.y + th - mr.h);
			g->apply(mr);
			t->minis.push_back(std::move(g));
		}
		// The shown one (when there's more than one): a ✕ that removes it.
		if (shown && count > 1) {
			Canvas canvas(20, 20, s.output->output->scale);
			cairo_t *cr = canvas.cr();
			cairo_arc(cr, 10, 10, 9.5, 0, 2 * M_PI);
			set_color(cr, rgb(0x000000, 0.55));
			cairo_fill(cr);
			draw_glyph(cr, "close", 10, 10, 10, rgb(0xffffff));
			wlr_scene_buffer *b = wlr_scene_buffer_create(s.strip, nullptr);
			canvas.present(b);
			b->point_accepts_input = no_input;
			wlr_scene_node_set_position(&b->node, t->box.x + tw - 25, t->box.y + 5);
			s.strip_bits.push_back(b);
			s.remove_box = wlr_box{t->box.x + tw - 27, t->box.y + 3, 24, 24};
		}
		s.thumbs.push_back(std::move(t));
	}
}

// Where everything on the card goes: a row per desktop (its number, its
// picture, then its windows), "Add desktop" under them, the card centred
// over the panel at the bottom of the screen. With many desktops the rows
// get shorter (smaller pictures, then less space between them) so the card
// always fits on the screen.
void Overview::desk_geometry(Screen &s) {
	const wlr_box o = s.output->box();
	const wlr_box u = s.output->usable();
	const int count = std::max(1, server_->workspace_count);
	const double aspect = o.height > 0 ? static_cast<double>(o.width) / o.height : 16.0 / 9.0;
	const int width = std::clamp(static_cast<int>(u.width * 0.62), std::min(520, u.width - 32), std::min(1100, u.width - 32));
	int tw = std::clamp(static_cast<int>(u.width * 0.09), 110, 170);
	int pad = 24;
	const int foot = 56, head = 10, num_w = 34;
	const int room = std::max(200, u.height - 150);   // the time / search above, a margin below
	auto height = [&] {
		const int th = static_cast<int>(tw / aspect);
		return head + count * (th + pad) + foot;
	};
	while (height() > room && tw > 56) tw -= 4;
	while (height() > room && pad > 8) pad -= 2;
	s.thumb_w = tw;
	s.thumb_h = std::max(1, static_cast<int>(tw / aspect));
	s.row_h = s.thumb_h + pad;
	const int h = height();
	s.card_box = wlr_box{u.x + (u.width - width) / 2, std::max(u.y + 8, u.y + u.height - 14 - h), width, h};
	s.rows_top = s.card_box.y + head;
	s.thumb_x = s.card_box.x + 16 + num_w;
	s.rows_x = s.thumb_x + tw + 40;
	const int bw = text_width("Add desktop", theme::font_bold) + 52;
	s.strip_add = server_->workspace_count < 12
		? wlr_box{s.card_box.x + 20, s.card_box.y + h - foot + 10, bw, 34} : wlr_box{};
}

// The card: frosted and tinted with the accent; the desktop shown lit;
// each desktop's name under its picture; the line between pictures and
// windows; and "Add desktop".
void Overview::draw_card(Screen &s) {
	const wlr_box &b = s.card_box;
	const float scale = s.output->output->scale;
	Canvas canvas(b.width, b.height, scale);
	cairo_t *cr = canvas.cr();
	const double r = 26;
	rounded_rect(cr, 0, 0, b.width, b.height, r);
	set_color(cr, theme::dark ? rgb(0x241322, 0.80) : rgb(0xffffff, 0.30));
	cairo_fill_preserve(cr);
	set_color(cr, with_alpha(theme::accent, theme::dark ? 0.22 : 0.42));
	cairo_fill(cr);
	const int count = std::max(1, server_->workspace_count);
	for (int i = 0; i < count; i++) {
		const double y = s.rows_top - b.y + i * s.row_h;
		if (i == s.output->workspace) {
			// The desktop shown: a band in the accent, its corners following the card's.
			const double top = i == 0 ? 0 : y - 2, bottom = y + s.row_h - 2;
			cairo_save(cr);
			rounded_rect(cr, 0, 0, b.width, b.height, r);
			cairo_clip(cr);
			cairo_rectangle(cr, 0, top, b.width, bottom - top);
			set_color(cr, with_alpha(theme::accent, theme::dark ? 0.35 : 0.45));
			cairo_fill(cr);
			cairo_restore(cr);
		}
		// Its number, beside its picture.
		const double ny = y + 12 + s.thumb_h / 2.0 - 14;
		draw_text(cr, std::to_string(i + 1), 12, ny, s.thumb_x - b.x - 18, 28, theme::font_bold,
			i == s.output->workspace ? kText() : kTextDim(), Align::Center);
	}
	// The line between the pictures and the windows.
	cairo_rectangle(cr, s.rows_x - b.x - 20, 14, 1, std::max(1, count * s.row_h - 14));
	set_color(cr, with_alpha(kText(), 0.18));
	cairo_fill(cr);
	if (s.strip_add.width > 0) {
		const wlr_box &a = s.strip_add;
		const double ax = a.x - b.x, ay = a.y - b.y;
		fill_rounded(cr, ax, ay, a.width, a.height, a.height / 2.0, with_alpha(theme::accent, theme::dark ? 0.45 : 0.55));
		draw_glyph(cr, "plus", ax + 20, ay + a.height / 2.0, 14, kText());
		draw_text(cr, "Add desktop", ax + 34, ay, a.width - 40, a.height, theme::font_bold, kText());
	}
	canvas.present(s.card);
	wlr_scene_node_set_position(&s.card->node, b.x, b.y);
}

bool Overview::matches(const View *view) const {
	if (query_.empty()) return true;
	const std::string q = lower(query_);
	if (lower(view->title()).find(q) != std::string::npos) return true;
	if (lower(view->app_id()).find(q) != std::string::npos) return true;
	for (const AppInfo &a : server_->apps.apps()) {
		if (!a.icon.empty() && a.icon == server_->apps.icon_for(view->app_id(), view->title())) {
			return lower(a.name).find(q) != std::string::npos;
		}
	}
	return false;
}

std::vector<int> Overview::app_results() const {
	std::vector<int> out;
	if (query_.empty() || !server_->config.overview_apps) return out;
	const std::string q = lower(query_);
	const auto &apps = server_->apps.apps();
	std::vector<int> starts, contains;
	for (int i = 0; i < static_cast<int>(apps.size()); i++) {
		const AppInfo &a = apps[static_cast<size_t>(i)];
		if (!a.visible) continue;
		const std::string name = lower(a.name);
		if (name.rfind(q, 0) == 0) starts.push_back(i);
		else if (name.find(q) != std::string::npos || lower(a.comment).find(q) != std::string::npos) contains.push_back(i);
	}
	out = starts;
	out.insert(out.end(), contains.begin(), contains.end());
	if (out.size() > 8) out.resize(8);
	return out;
}

// ---- layout -----------------------------------------------------------------------------

void Overview::layout() {
	for (auto &w : windows_) {
		w->was_in_layout = w->in_layout;
		w->in_layout = false;
	}
	for (auto &s : screens_) {
		layout_screen(*s);
	}
	// A keyboard selection that went away.
	const int n = static_cast<int>(selectable().size()) + (screens_.empty() ? 0 : static_cast<int>(app_results().size()));
	if (selected_ >= n) selected_ = n - 1;
	if (!query_.empty() && selected_ < 0 && n > 0) selected_ = 0;
	select(selected_);
}

void Overview::layout_screen(Screen &s) {
	const wlr_box u = s.output->usable();
	desk_geometry(s);
	draw_card(s);
	for (auto *p : s.peek) wlr_scene_node_set_enabled(&p->node, false);
	s.peek_box[0] = s.peek_box[1] = wlr_box{};
	wlr_scene_node_set_enabled(&s.add->node, false);
	s.add_box = wlr_box{};

	// Above the card: the time, big; while you type, the search field there
	// (and the apps it found between it and the card).
	const std::vector<int> apps = s.primary ? app_results() : std::vector<int>{};
	int above = s.card_box.y - 16;
	if (!apps.empty()) {
		s.apps_box = wlr_box{u.x + (u.width - static_cast<int>(apps.size()) * kAppCell) / 2, above - kAppsH,
			static_cast<int>(apps.size()) * kAppCell, kAppsH};
		above -= kAppsH + 10;
		draw_apps(s);
		wlr_scene_node_set_enabled(&s.apps->node, true);
	} else {
		s.apps_box = wlr_box{};
		s.app_hits.clear();
		wlr_scene_node_set_enabled(&s.apps->node, false);
	}
	if (s.primary && !query_.empty()) {
		s.search_box = wlr_box{u.x + (u.width - kSearchW) / 2, above - kSearchH, kSearchW, kSearchH};
		draw_search(s);
		wlr_scene_node_set_enabled(&s.search->node, true);
		wlr_scene_node_set_enabled(&s.label->node, false);
	} else {
		s.search_box = wlr_box{};
		wlr_scene_node_set_enabled(&s.search->node, false);
		const std::string time = "DESKTOPS";
		const std::string font = (server_->config.font.empty() ? std::string("Sans") : server_->config.font) + " Bold 34";
		const int tw = text_width(time, font.c_str()) + 20, th = 56;
		Canvas canvas(tw, th, s.output->output->scale);
		draw_text(canvas.cr(), time, 0, 0, tw, th, font.c_str(), rgb(0xffffff), Align::Center);
		canvas.present(s.label);
		wlr_scene_buffer_set_corner_radii(s.label, corner_radii_all(0));
		wlr_scene_node_set_position(&s.label->node, u.x + (u.width - tw) / 2, above - th);
		wlr_scene_node_set_enabled(&s.label->node, true);
	}

	// Each desktop's windows in its row (or, searching, what was found).
	const int count = std::max(1, server_->workspace_count);
	for (int i = 0; i < count; i++) {
		std::vector<Window *> wins;
		for (auto &w : windows_) {
			if (w->screen != &s) continue;
			View *v = w->view;
			const bool on = v->sticky ? i == s.output->workspace : v->workspace == i;
			const bool here = on && (query_.empty() ? (!v->minimized || server_->config.overview_minimized) : matches(v));
			if (here) {
				w->in_layout = true;
				wins.push_back(w.get());
			}
		}
		const wlr_box area{s.rows_x, s.rows_top + i * s.row_h + 12, s.card_box.x + s.card_box.width - 20 - s.rows_x,
			s.thumb_h};
		place_windows(s, wins, area, 1.0);
	}
}

// Windows in a desktop's row, as big as fits (never bigger than the row).
// On a narrow card (a portrait screen, a high scale) they wrap onto more
// lines when that lets them be bigger, instead of shrinking to dots and
// running off the card.
void Overview::place_windows(Screen &s, std::vector<Window *> &wins, const wlr_box &area, double max_scale) {
	(void)s;
	(void)max_scale;
	if (wins.empty()) return;
	std::sort(wins.begin(), wins.end(), [](const Window *a, const Window *b) { return a->view->id < b->view->id; });
	const int n = static_cast<int>(wins.size());
	constexpr double kLabel = 28;   // the name under each window (drawn 6 below it, 22 tall)
	auto ratio = [](const Window *w) { return w->real.w / std::max(1.0, w->real.h); };
	// Each window gets a slot wide enough for its name under it: 110, or
	// less when even that many don't fit across.
	auto min_slot_for = [&](int per) {
		return std::max(40.0, std::min(110.0, (area.width - kGap * (per - 1.0)) / std::max(1, per)));
	};
	// The height the windows can have with `lines` lines.
	auto height_for = [&](int lines) {
		const int per = (n + lines - 1) / lines;
		const double line_h = (area.height - (lines - 1) * kLabel) / lines;
		if (line_h < 12) return -1.0;
		const double min_slot = min_slot_for(per);
		double h = line_h;
		for (int start = 0; start < n; start += per) {
			const int end = std::min(n, start + per);
			auto total = [&](double hh) {
				double t = kGap * (end - start - 1.0);
				for (int i = start; i < end; i++) t += std::max(min_slot, ratio(wins[static_cast<size_t>(i)]) * hh);
				return t;
			};
			while (h > 12 && total(h) > area.width) h -= 1;
		}
		return h;
	};
	int lines = 1;
	double h = height_for(1);
	for (int l = 2; l <= n; l++) {
		const double hl = height_for(l);
		if (hl < 0) break;
		// (Only worth another line when it makes them clearly bigger.)
		if (hl > h * 1.15) {
			h = hl;
			lines = l;
		}
	}
	h = std::max(12.0, h);
	const int per = (n + lines - 1) / lines;
	const double min_slot = min_slot_for(per);
	const double used = lines * h + (lines - 1) * kLabel;
	const double top = area.y + std::max(0.0, (area.height - used) / 2);
	for (int line = 0; line < lines; line++) {
		double x = area.x;
		const double y = top + line * (h + kLabel);
		for (int i = line * per; i < std::min(n, (line + 1) * per); i++) {
			Window *w = wins[static_cast<size_t>(i)];
			const double ww = ratio(w) * h, slot = std::max(min_slot, ww);
			w->place = GhostRect{std::round(x + (slot - ww) / 2), std::round(y), std::round(ww), std::round(h), 1};
			w->slot = slot;
			x += slot + kGap;
		}
	}
}

// ---- drawing ----------------------------------------------------------------------------

void Overview::draw_search(Screen &s) {
	const float scale = s.output->output->scale;
	Canvas canvas(kSearchW, kSearchH, scale);
	cairo_t *cr = canvas.cr();
	fill_rounded(cr, 0, 0, kSearchW, kSearchH, kSearchH / 2.0, kField());
	draw_glyph(cr, "search", 22, kSearchH / 2.0, 17, kTextDim());
	const int tx = 42;
	if (query_.empty()) {
		draw_text(cr, "Type to search", tx, 0, kSearchW - tx - 16, kSearchH, theme::font_large, kTextDim());
	} else {
		draw_text(cr, query_, tx, 0, kSearchW - tx - 16, kSearchH, theme::font_large, kText());
		const int cx = std::min(kSearchW - 18, tx + text_width(query_, theme::font_large) + 2);
		cairo_rectangle(cr, cx, 11, 2, kSearchH - 22);
		set_color(cr, theme::accent);
		cairo_fill(cr);
	}
	canvas.present(s.search);
	wlr_scene_node_set_position(&s.search->node, s.search_box.x, s.search_box.y);
}

void Overview::draw_apps(Screen &s) {
	const std::vector<int> apps = app_results();
	s.app_hits.clear();
	if (apps.empty()) return;
	const float scale = s.output->output->scale;
	const int w = static_cast<int>(apps.size()) * kAppCell;
	Canvas canvas(w, kAppsH, scale);
	cairo_t *cr = canvas.cr();
	const int n_windows = static_cast<int>(selectable().size());
	const auto &all = server_->apps.apps();
	for (size_t i = 0; i < apps.size(); i++) {
		const AppInfo &a = all[static_cast<size_t>(apps[i])];
		const double x = i * kAppCell;
		if (selected_ == n_windows + static_cast<int>(i)) {
			fill_rounded(cr, x + 4, 2, kAppCell - 8, kAppsH - 4, 16, with_alpha(theme::accent, 0.45));
		}
		draw_icon(cr, server_->icons, a.icon, a.name, x + (kAppCell - 52) / 2.0, 10, 52, scale);
		draw_text(cr, a.name, x + 4, 66, kAppCell - 8, 30, theme::font, kText(), Align::Center);
		s.app_hits.push_back(AppHit{apps[i], wlr_box{s.apps_box.x + static_cast<int>(x), s.apps_box.y, kAppCell, kAppsH}});
	}
	canvas.present(s.apps);
	wlr_scene_node_set_position(&s.apps->node, s.apps_box.x, s.apps_box.y);
}

// The icon under a window, and on hover its title and ✕.
void Overview::draw_window_extras(Window &w) {
	const GhostRect &r = w.ghost->current;
	const double a = std::clamp((t_ - 0.55) / 0.45, 0.0, 1.0) * (w.in_layout ? r.alpha : 0.0);
	wlr_scene_node_set_enabled(&w.badge->node, false);
	const bool hovered = hover_ == &w && open_ && !dragging_;
	const std::vector<Window *> sel = selectable();
	const bool chosen = selected_ >= 0 && selected_ < static_cast<int>(sel.size()) && sel[static_cast<size_t>(selected_)] == &w;
	const bool lit = (hovered || chosen) && a > 0.5;
	wlr_scene_node_set_enabled(&w.glow->node, lit);
	if (lit) {
		wlr_scene_rect_set_size(w.glow, std::max(1, ri(r.w + 10)), std::max(1, ri(r.h + 10)));
		wlr_scene_node_set_position(&w.glow->node, ri(r.x - 5), ri(r.y - 5));
		wlr_scene_rect_set_corner_radius(w.glow, 12);
		set_rect_color(w.glow, chosen ? with_alpha(theme::accent, 0.6) : rgb(0xffffff, 0.35));
	}
	// Its name, with its app's icon, under it.
	const bool named = a > 0.01 && !(dragging_ && pressed_ == &w);
	wlr_scene_node_set_enabled(&w.label->node, named);
	if (named) {
		const std::string title = w.view->title();
		// As wide as its slot allows (narrow on a portrait screen), so the
		// names don't run into each other or off the card.
		const int room = w.slot > 0 ? ri(w.slot + kGap - 4) : 240;
		const int want_w = std::max(std::min(110, room), std::min({240, room, ri(r.w + 20)}));
		if (title != w.label_drawn || want_w != w.label_w) {
			w.label_drawn = title;
			w.label_w = want_w;
			const float sc = w.screen->output->output->scale;
			Canvas canvas(w.label_w, 22, sc);
			cairo_t *cr = canvas.cr();
			const int tw = std::min(w.label_w - kBadge - 6, text_width(title, theme::font_small));
			const double x0 = (w.label_w - (kBadge + 6 + tw)) / 2.0;
			draw_icon(cr, server_->icons, server_->apps.icon_for(w.view->app_id(), title), title, x0, 2, kBadge, sc);
			draw_text(cr, title, x0 + kBadge + 6, 0, tw + 2, 22, theme::font_small, kText());
			canvas.present(w.label);
		}
		wlr_scene_node_set_position(&w.label->node, ri(r.x + r.w / 2 - w.label_w / 2.0), ri(r.y + r.h + 6));
		wlr_scene_buffer_set_opacity(w.label, static_cast<float>(a));
	}
	wlr_scene_node_set_enabled(&w.close->node, hovered && a > 0.5);
	if (hovered && a > 0.5) {
		const int red = hover_close_ ? 1 : 0;
		if (red != w.close_drawn) {
			w.close_drawn = red;
			Canvas canvas(24, 24, w.screen->output->output->scale);
			cairo_t *cr = canvas.cr();
			cairo_arc(cr, 12, 12, 11, 0, 2 * M_PI);
			set_color(cr, red ? theme::danger : (theme::dark ? rgb(0x3a2a38, 0.95) : rgb(0xffffff, 0.95)));
			cairo_fill(cr);
			draw_glyph(cr, "close", 12, 12, 12, red ? rgb(0xffffff) : kText());
			canvas.present(w.close);
		}
		wlr_scene_node_set_position(&w.close->node, ri(r.x + r.w - 14), ri(r.y - 10));
	}
}

void Overview::set_alpha(double a) {
	alpha_ = std::clamp(a, 0.0, 1.0);
	for (auto &s : screens_) {
		wlr_scene_blur_set_alpha(s->blur, static_cast<float>(alpha_));
		set_rect_color(s->dim, with_alpha(kDim(), (theme::dark ? 0.40 : 0.28) * alpha_));
		wlr_scene_buffer_set_opacity(s->card, static_cast<float>(alpha_));
		wlr_scene_buffer_set_opacity(s->search, static_cast<float>(alpha_));
		wlr_scene_buffer_set_opacity(s->apps, static_cast<float>(alpha_));
		wlr_scene_buffer_set_opacity(s->add, static_cast<float>(alpha_));
		wlr_scene_buffer_set_opacity(s->label, static_cast<float>(alpha_));
		for (auto *p : s->peek) wlr_scene_buffer_set_opacity(p, static_cast<float>(0.55 * alpha_));
		wlr_scene_node_set_enabled(&s->strip->node, alpha_ > 0.02);
		// The pictures fade in with everything (all their parts), sliding in a
		// little from their edge.
		// The card rises a little as it fades in.
		const int off = static_cast<int>(std::lround((1.0 - alpha_) * 16));
		wlr_scene_node_set_position(&s->strip->node, 0, off);
		wlr_scene_node_set_position(&s->card->node, s->card_box.x, s->card_box.y + off);
		for (auto &t : s->thumbs) {
			wlr_scene_buffer_set_opacity(t->wall, static_cast<float>(alpha_));
			if (t->index == s->output->workspace && !dragging_) set_rect_color(t->ring, with_alpha(theme::accent, alpha_));
			for (auto &g : t->minis) {
				GhostRect r = g->current;
				r.alpha = alpha_;
				g->apply(r);
			}
		}
		for (wlr_scene_buffer *b : s->strip_bits) wlr_scene_buffer_set_opacity(b, static_cast<float>(alpha_));
	}
}

// The open/close movement: windows between their real place (t = 0) and the
// overview (t = 1); everything else fades.
void Overview::apply(double t) {
	const double tt = std::clamp(t, 0.0, 1.0);
	set_alpha(tt);
	for (auto &w : windows_) {
		const bool here = w->view->visible();   // on the workspace shown
		GhostRect r;
		if (w->in_layout && here) {
			r = lerp(w->real, w->place, t);
			r.alpha = 1;
		} else if (w->in_layout) {
			// (A minimised one fades in at its place, a little faded.)
			r = w->place;
			r.alpha = tt * (w->view->minimized ? 0.65 : 1.0);
		} else if (here && !open_) {
			r = w->real;
			r.alpha = 1 - tt;
		} else {
			r = w->place.w > 1 ? w->place : w->real;
			r.alpha = 0;
		}
		w->ghost->apply(r);
		draw_window_extras(*w);
	}
}

// From where the windows are now to their new places (search, workspace switch).
void Overview::glide() {
	if (!open_) return;
	// Switching workspace: this one's windows slide out one way as the next
	// one's slide in from the other (a quarter of the card), fading.
	for (auto &w : windows_) {
		w->from = w->ghost->current;
		w->away = 0;
		const double shift = w->screen ? w->screen->slide_dir * w->screen->card_box.width * 0.25 : 0;
		if (w->in_layout && !w->was_in_layout) {
			w->from = w->place;
			w->from.x += shift;
			w->from.alpha = 0;
		} else if (!w->in_layout && w->was_in_layout) {
			w->away = -shift;
		}
	}
	server_->anim->cancel(glide_anim_);
	const Config &c = server_->config;
	glide_anim_ = server_->anim->start(c.animate(c.anim_overview) ? c.ms(200) : 0, [this](double t) {
		const double tt = std::clamp(t, 0.0, 1.2);
		for (auto &w : windows_) {
			if (dragging_ && pressed_ == w.get()) continue;
			GhostRect to = w->in_layout ? w->place : w->from;
			if (!w->in_layout) to.x += w->away;
			to.alpha = w->in_layout ? (w->view->minimized ? 0.65 : 1.0) : 0.0;
			GhostRect r = lerp(w->from, to, tt);
			r.alpha = std::clamp(r.alpha, 0.0, 1.0);
			w->ghost->apply(r);
			draw_window_extras(*w);
		}
	}, [this] { glide_anim_ = 0; });
}

// ---- selection ----------------------------------------------------------------------------

std::vector<Overview::Window *> Overview::selectable() {
	std::vector<Window *> out;
	for (auto &s : screens_) {
		std::vector<Window *> mine;
		for (auto &w : windows_) {
			if (w->screen == s.get() && w->in_layout) mine.push_back(w.get());
		}
		std::sort(mine.begin(), mine.end(), [](const Window *a, const Window *b) {
			if (std::fabs(a->place.y - b->place.y) > 2) return a->place.y < b->place.y;
			return a->place.x < b->place.x;
		});
		if (s->primary) {
			out.insert(out.begin(), mine.begin(), mine.end());
		} else {
			out.insert(out.end(), mine.begin(), mine.end());
		}
	}
	return out;
}

void Overview::select(int index) {
	selected_ = index;
	for (auto &w : windows_) draw_window_extras(*w);
	for (auto &s : screens_) {
		if (s->primary && s->apps_box.width > 0) draw_apps(*s);
	}
}

void Overview::activate_selection() {
	std::vector<Window *> wins = selectable();
	const int n = static_cast<int>(wins.size());
	int i = selected_ >= 0 ? selected_ : 0;
	if (i < n) {
		close(wins[static_cast<size_t>(i)]->view);
		return;
	}
	const std::vector<int> apps = app_results();
	const int ai = i - n;
	if (ai >= 0 && ai < static_cast<int>(apps.size())) {
		server_->spawn(server_->apps.apps()[static_cast<size_t>(apps[static_cast<size_t>(ai)])].exec);
		close();
	}
}

// ---- pointer ------------------------------------------------------------------------------

Overview::Window *Overview::window_at(double lx, double ly, bool *on_close) {
	if (on_close) *on_close = false;
	// Topmost first (the end of the list was made last).
	for (auto it = windows_.rbegin(); it != windows_.rend(); ++it) {
		Window *w = it->get();
		if (!w->in_layout) continue;
		const GhostRect &r = w->ghost->current;
		if (hover_ == w && on_close && std::hypot(lx - (r.x + r.w - 2), ly - (r.y + 2)) <= 15) {
			*on_close = true;
			return w;
		}
		if (inside(r, lx, ly)) return w;
		// The icon under it counts too.
		if (std::fabs(lx - (r.x + r.w / 2)) <= kBadge / 2.0 && ly >= r.y + r.h && ly <= r.y + r.h + kBadge * 0.45) return w;
	}
	return nullptr;
}

Overview::WsThumb *Overview::thumb_at(double lx, double ly, Screen **screen) {
	for (auto &s : screens_) {
		for (auto &t : s->thumbs) {
			if (inside(t->box, lx, ly)) {
				if (screen) *screen = s.get();
				return t.get();
			}
		}
	}
	return nullptr;
}

int Overview::peek_at(double lx, double ly) const {
	for (const auto &s : screens_) {
		if (inside(s->peek_box[0], lx, ly)) return -1;
		if (inside(s->peek_box[1], lx, ly)) return 1;
	}
	return 0;
}

int Overview::row_at(double lx, double ly, Screen **screen) const {
	if (screen) *screen = nullptr;
	if (!query_.empty()) return -1;   // searching: the rows show what was found, not desktops
	const int count = std::max(1, server_->workspace_count);
	for (const auto &s : screens_) {
		const wlr_box &c = s->card_box;
		if (lx < c.x || lx >= c.x + c.width || ly < s->rows_top || s->row_h <= 0) continue;
		const int i = static_cast<int>((ly - s->rows_top) / s->row_h);
		if (i >= 0 && i < count) {
			if (screen) *screen = s.get();
			return i;
		}
	}
	return -1;
}

void Overview::reparent_window(Window &w, wlr_scene_tree *parent) {
	if (!parent) return;
	// (In this order: the glow under the copy, its icon and name over it.)
	wlr_scene_node_reparent(&w.glow->node, parent);
	w.ghost->reparent(parent);
	for (wlr_scene_buffer *b : {w.badge, w.label, w.close}) {
		wlr_scene_node_reparent(&b->node, parent);
	}
}

void Overview::show_drop_row(int index, Screen *target) {
	for (auto &s : screens_) {
		// Any row of the screen it's over; its own row there only when it
		// comes from another screen.
		const bool from_here = pressed_ && pressed_->screen == s.get();
		const bool on = index >= 0 && s.get() == target && (index != s->output->workspace || !from_here);
		wlr_scene_node_set_enabled(&s->drop_hl->node, on);
		if (!on) continue;
		const wlr_box &c = s->card_box;
		const int y = s->rows_top + index * s->row_h + 4;
		wlr_scene_rect_set_size(s->drop_hl, c.width - 24, std::max(1, s->row_h - 6));
		wlr_scene_node_set_position(&s->drop_hl->node, c.x + 12, y);
		set_rect_color(s->drop_hl, with_alpha(theme::accent, theme::dark ? 0.30 : 0.35));
	}
}

int Overview::app_at(double lx, double ly) const {
	for (const auto &s : screens_) {
		for (const AppHit &h : s->app_hits) {
			if (inside(h.box, lx, ly)) return h.app;
		}
	}
	return -1;
}

void Overview::set_hover(Window *w) {
	Window *before = hover_;
	hover_ = w;
	if (before && before != w) draw_window_extras(*before);
	if (w) draw_window_extras(*w);
}

void Overview::motion(double lx, double ly) {
	if (!open_) return;
	if (pressed_) {
		if (!dragging_ && std::hypot(lx - press_x_, ly - press_y_) >= 8) {
			dragging_ = true;
			set_hover(nullptr);
			reparent_window(*pressed_, drag_layer_);
			server_->set_cursor("grabbing");
		}
		if (dragging_) {
			// The window follows the pointer, small, until it's dropped on a workspace.
			const GhostRect &p = pressed_->place;
			const double k = std::min(1.0, 220.0 / std::max(1.0, std::max(p.w, p.h)));
			pressed_->ghost->apply(GhostRect{lx - p.w * k / 2, ly - p.h * k / 2, p.w * k, p.h * k, 0.9});
			draw_window_extras(*pressed_);
			// Anywhere on a desktop's row (its picture or beside it) takes the window.
			Screen *target = nullptr;
			const int row = row_at(lx, ly, &target);
			show_drop_row(row, target);
			for (auto &s : screens_) {
				for (auto &t : s->thumbs) {
					const bool over = t->index == row && s.get() == target;
					set_rect_color(t->ring, t->index == s->output->workspace ? theme::accent
						: over ? with_alpha(kText(), 0.55) : rgb(0xffffff, 0.0));
				}
			}
			return;
		}
	}
	bool on_close = false;
	Window *w = window_at(lx, ly, &on_close);
	if (w != hover_ || on_close != hover_close_) {
		hover_close_ = on_close;
		set_hover(w);
	}
	server_->set_cursor("default");
}

void Overview::press(double lx, double ly, uint32_t button) {
	if (!open_) return;
	bool on_close = false;
	if (Window *w = window_at(lx, ly, &on_close)) {
		if (on_close || button == BTN_MIDDLE) {
			w->view->close();
			return;
		}
		if (button == BTN_LEFT) {
			pressed_ = w;
			press_x_ = lx;
			press_y_ = ly;
			dragging_ = false;
		}
		return;
	}
	if (button != BTN_LEFT) return;
	// (The ✕ on the shown workspace's picture before the picture itself.)
	for (const auto &s : screens_) {
		if (inside(s->remove_box, lx, ly)) {
			server_->remove_workspace(s->output->workspace);
			return;
		}
	}
	Screen *on = nullptr;
	if (WsThumb *t = thumb_at(lx, ly, &on)) {
		// The ring moves at once (the rest follows as the workspace changes).
		for (auto &o : on->thumbs) {
			set_rect_color(o->ring, o->index == t->index ? with_alpha(theme::accent, alpha_) : rgb(0xffffff, 0.0));
		}
		server_->switch_workspace(t->index, false, on->output);   // that screen only
		return;
	}
	if (const int side = peek_at(lx, ly)) {
		server_->switch_workspace(server_->workspace + side, false);   // (on the screen you're on)
		return;
	}
	for (const auto &s : screens_) {
		if (inside(s->add_box, lx, ly) || inside(s->strip_add, lx, ly)) {
			server_->add_workspace();
			return;
		}
		if (inside(s->remove_box, lx, ly)) {
			server_->remove_workspace(s->output->workspace);
			return;
		}
	}
	if (const int app = app_at(lx, ly); app >= 0) {
		server_->spawn(server_->apps.apps()[static_cast<size_t>(app)].exec);
		close();
		return;
	}
	for (const auto &s : screens_) {
		if (inside(s->search_box, lx, ly) || inside(s->card_box, lx, ly)) return;
	}
	close();   // the empty background: back to the desktop
}

void Overview::release(double lx, double ly, uint32_t button) {
	if (button != BTN_LEFT || !pressed_) return;
	Window *w = pressed_;
	const bool was_drag = dragging_;
	pressed_ = nullptr;
	dragging_ = false;
	server_->set_cursor("default");
	show_drop_row(-1);
	if (!was_drag) {
		close(w->view);
		return;
	}
	// It's laid out with another screen's windows from now on.
	auto to_screen = [&](Screen *sc) {
		if (!sc || sc == w->screen) return;
		server_->move_to_screen(w->view, sc->output, false);
		w->screen = sc;
		const wlr_box f = w->view->frame_box();
		w->real = GhostRect{static_cast<double>(f.x), static_cast<double>(f.y), static_cast<double>(f.width),
			static_cast<double>(f.height), 1};
	};
	Screen *target = nullptr;
	if (WsThumb *t = thumb_at(lx, ly, &target)) {
		// A desktop's picture on another screen's card: to that screen, on that desktop.
		to_screen(target);
		server_->move_to_workspace(w->view, t->index, false);
	} else if (const int row = row_at(lx, ly, &target); row >= 0) {
		to_screen(target);
		const bool here = w->view->sticky ? row == target->output->workspace : w->view->workspace == row;
		if (!here) server_->move_to_workspace(w->view, row, false);
	} else if (const int side = peek_at(lx, ly)) {
		server_->move_to_workspace(w->view, w->screen->output->workspace + side, false);
	} else {
		bool done = false;
		for (const auto &sc : screens_) {
			if (inside(sc->add_box, lx, ly) || inside(sc->strip_add, lx, ly)) {
				View *v = w->view;
				to_screen(sc.get());
				// A new one, with this window on it, shown on that screen
				// (the other screens stay where they are).
				std::vector<std::pair<Output *, int>> before;
				for (Output *o : server_->outputs) before.emplace_back(o, o->workspace);
				server_->add_workspace();
				for (auto &[o, ws] : before) {
					if (o != sc->output && o->workspace != ws) server_->switch_workspace(ws, false, o);
				}
				server_->move_to_workspace(v, server_->workspace_count - 1, false);
				server_->switch_workspace(v->workspace, false, sc->output);
				done = true;
				break;
			}
		}
		// Dropped anywhere else on another screen: the window goes over to it.
		if (!done) {
			for (const auto &sc : screens_) {
				if (sc.get() != w->screen && inside(sc->output->box(), lx, ly)) {
					to_screen(sc.get());
					break;
				}
			}
		}
	}
	reparent_window(*w, w->screen->windows);
	for (auto &s : screens_) build_strip(*s);
	layout();
	glide();
}

void Overview::scroll(double delta, bool horizontal) {
	if (!open_) return;
	(void)horizontal;
	scroll_accum_ += delta;
	const uint32_t now = static_cast<uint32_t>(now_ms());
	if (std::fabs(scroll_accum_) < 12 || now - last_scroll_ms_ < 180) return;
	const int dir = scroll_accum_ > 0 ? 1 : -1;
	scroll_accum_ = 0;
	last_scroll_ms_ = now;
	server_->switch_workspace(server_->workspace + dir, false);
}

// ---- keys ----------------------------------------------------------------------------------

bool Overview::handle_key(xkb_keysym_t sym, uint32_t modifiers, const std::string &text) {
	if (!open_) return false;
	const bool ctrl = modifiers & WLR_MODIFIER_CTRL;
	const bool alt = modifiers & WLR_MODIFIER_ALT;
	const bool super = modifiers & WLR_MODIFIER_LOGO;
	const int n = static_cast<int>(selectable().size()) + static_cast<int>(app_results().size());
	switch (sym) {
	case XKB_KEY_Escape:
		if (!query_.empty()) {
			query_.clear();
			selected_ = -1;
			layout();
			glide();
		} else {
			close();
		}
		return true;
	case XKB_KEY_Return:
	case XKB_KEY_KP_Enter:
		activate_selection();
		return true;
	case XKB_KEY_Page_Up:
	case XKB_KEY_Page_Down:
		server_->switch_workspace(server_->workspace + (sym == XKB_KEY_Page_Down ? 1 : -1), false);
		return true;
	case XKB_KEY_Left:
	case XKB_KEY_Right:
		if ((ctrl && alt) || super) {
			server_->switch_workspace(server_->workspace + (sym == XKB_KEY_Right ? 1 : -1), false);
			return true;
		}
		[[fallthrough]];
	case XKB_KEY_Up:
	case XKB_KEY_Down:
	case XKB_KEY_Tab:
	case XKB_KEY_ISO_Left_Tab: {
		if (n == 0) return true;
		const bool back = sym == XKB_KEY_Left || sym == XKB_KEY_Up || sym == XKB_KEY_ISO_Left_Tab;
		int i = selected_ < 0 ? (back ? n - 1 : 0) : (selected_ + (back ? n - 1 : 1)) % n;
		select(i);
		return true;
	}
	case XKB_KEY_BackSpace:
		if (!query_.empty()) {
			size_t cut = query_.size() - 1;
			while (cut > 0 && (static_cast<unsigned char>(query_[cut]) & 0xc0) == 0x80) cut--;
			query_.erase(cut);
			selected_ = query_.empty() ? -1 : 0;
			layout();
			glide();
		}
		return true;
	default:
		break;
	}
	if (!ctrl && !super && !text.empty() && static_cast<unsigned char>(text[0]) >= 0x20 && text[0] != 0x7f) {
		query_ += text;
		selected_ = 0;
		layout();
		glide();
	}
	return true;   // nothing else reaches the apps while it's open
}

} // namespace arqen
