#include "osd.hpp"

#include <algorithm>
#include <cmath>

#include "draw.hpp"
#include "glyphs.hpp"
#include "system.hpp"

namespace arqen {

Osd::Osd(Server *server) : server_(server) {
	layer_ = std::make_unique<UiLayer>(server->layer_overlay, &tag_);
	layer_->buffer->point_accepts_input = &Osd::accepts_input;
	layer_->set_enabled(false);
	timer_ = wl_event_loop_add_timer(server->loop, &Osd::handle_timeout, this);
}

Osd::~Osd() {
	if (anim_) {
		server_->anim->cancel(anim_);
	}
	wl_event_source_remove(timer_);
	layer_.reset();
}

int Osd::handle_timeout(void *data) {
	static_cast<Osd *>(data)->hide();
	return 0;
}

void Osd::show(Kind kind, int level, bool off, const std::string &text) {
	const Config &c = server_->config;
	if (!c.osd) {
		return;
	}
	kind_ = kind;
	level_ = std::clamp(level, -1, kind == Kind::Volume ? server_->config.volume_max() : 100);
	off_ = off;
	text_ = text;
	redraw();
	place();
	layer_->set_enabled(true);

	if (!visible_) {
		visible_ = true;
		place();
		server_->anim->cancel(anim_);
		// Fades in from wherever it is, also when it was just fading out.
		anim_ = server_->anim->tween(alpha_, 1.0, c.animate(c.anim_osd) ? c.ms(160) : 0,
			[this] { place(); }, [this] { anim_ = 0; });
	}
	wl_event_source_timer_update(timer_, c.osd_timeout);
}

void Osd::hide() {
	if (!visible_) {
		return;
	}
	visible_ = false;
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 0.0, c.animate(c.anim_osd) ? c.ms(220) : 0,
		[this] { place(); },
		[this] {
			anim_ = 0;
			if (!visible_) {
				layer_->set_enabled(false);
			}
		});
}

void Osd::place() {
	Output *out = server_->output_at(server_->cursor->x, server_->cursor->y);
	if (!out) {
		return;
	}
	const wlr_box u = out->usable();
	const std::string &where = server_->config.osd_position;
	const int margin = 24;
	// One of nine places (Settings: click where on the screen).
	const bool top = where.rfind("top", 0) == 0, bottom = where.rfind("bottom", 0) == 0;
	const bool left = where.find("left") != std::string::npos, right = where.find("right") != std::string::npos;
	int x = left ? u.x + margin : right ? u.x + u.width - width_ - margin : u.x + (u.width - width_) / 2;
	int y = top ? u.y + margin : bottom ? u.y + u.height - height_ - margin - 12 : u.y + (u.height - height_) / 2;
	// A short slide in from the nearest edge while fading in/out.
	const int slide = static_cast<int>(std::lround((1.0 - alpha_) * 10));
	if (top) y -= slide;
	else if (bottom) y += slide;
	else if (left) x -= slide;
	else if (right) x += slide;
	else y += slide;
	layer_->show(x, y, alpha_);
	pos_x_ = x;
	pos_y_ = y;
}

namespace {

constexpr double kInset = 8;   // the slider's gap to the card's edge

// The level as the control centre draws its sliders: a pill track filled
// from the start by a pill in the accent gradient, the icon at the start of
// the fill and the number at the other end. max: what a full bar is (150
// for the volume with overamplification: past 100 it fills orange, then red).
void draw_level(cairo_t *cr, bool vertical, double x, double y, double w, double h, int level, bool off,
		const std::string &glyph, int max) {
	const double pr = std::min(w, h) / 2.0;
	fill_rounded(cr, x, y, w, h, pr, theme::tile_off);
	const double v = std::clamp(level, 0, max) / static_cast<double>(max);
	cairo_save(cr);
	rounded_rect(cr, x, y, w, h, pr);
	cairo_clip(cr);
	if (vertical) {
		const double fh = std::max(w, h * v);
		rounded_rect(cr, x, y + h - fh, w, fh, pr);
	} else {
		const double fw = std::max(h, w * v);
		rounded_rect(cr, x, y, fw, h, pr);
	}
	if (off) set_color(cr, theme::text_dim);
	else accent_gradient(cr, x, y, w, h);
	cairo_fill(cr);
	if (!off) boost_fill(cr, vertical, x, y, w, h, pr, 100.0 / max, v);
	cairo_restore(cr);
	// The icon sits on the fill (it always covers the start).
	const Color on_fill = off ? theme::bg : theme::on_gradient;
	const double icx = vertical ? x + w / 2 : x + h / 2;
	const double icy = vertical ? y + h - w / 2 : y + h / 2;
	draw_glyph(cr, glyph, icx, icy, 20, on_fill);
	// The number at the far end: on the fill once it reaches there.
	const std::string num = off ? "—" : std::to_string(level);
	if (vertical) {
		draw_text(cr, num, x, y + 6, w, 24, theme::font_bold, v > 0.9 ? on_fill : theme::text, Align::Center);
	} else {
		draw_text(cr, off ? num : num + "%", x + w - 70, y, 54, h, theme::font_bold,
			v > 0.85 ? on_fill : theme::text, Align::Right);
	}
}

} // namespace

void Osd::redraw() {
	const bool has_bar = level_ >= 0;
	// Upright (Settings > On-screen display > Orientation): the level ones
	// are a tall pill with the slider; the on/off ones (microphone, Caps
	// Lock, layout) a short one with the icon and its state.
	const bool vertical = server_->config.osd_orientation == "vertical";
	width_ = vertical ? 64 : has_bar ? 320 : 280;
	height_ = vertical ? (has_bar ? 280 : 150) : has_bar ? 60 : 60;
	Output *out = server_->output_at(server_->cursor->x, server_->cursor->y);
	Canvas canvas(width_, height_, out ? out->output->scale : 1.0f);
	cairo_t *cr = canvas.cr();

	// A pill, like the control centre's sliders and the panel's chips.
	const double r = std::min(width_, height_) / 2.0;
	ui_card(cr, 0, 0, width_, height_, r, theme::menu_bg);

	std::string glyph, title;
	switch (kind_) {
	case Kind::Volume:
		glyph = speaker_icon(level_, off_);
		title = off_ ? "Muted" : "Volume";
		break;
	case Kind::Mic:
		glyph = off_ ? "mic-off" : "mic";
		title = off_ ? "Microphone off" : "Microphone on";
		break;
	case Kind::Brightness:
		glyph = level_ < 34 ? "sun-dim" : "sun";
		title = "Brightness";
		break;
	case Kind::CapsLock:
		glyph = "lock";
		title = off_ ? "Caps Lock off" : "Caps Lock on";
		break;
	case Kind::NumLock:
		glyph = "lock";
		title = off_ ? "Num Lock off" : "Num Lock on";
		break;
	case Kind::Layout:
		glyph = "keyboard";
		title = text_.empty() ? "Keyboard layout" : text_;
		break;
	}

	if (has_bar) {
		const int max = kind_ == Kind::Volume ? server_->config.volume_max() : 100;
		draw_level(cr, vertical, kInset, kInset, width_ - 2 * kInset, height_ - 2 * kInset, level_, off_, glyph, max);
		layer_->present(canvas, wlr_box{0, 0, width_, height_}, r);
		return;
	}

	// On/off: the icon in a round chip (accent when on), then its state.
	const double chip = (vertical ? width_ : height_) / 2.0 - kInset;
	const double icx = vertical ? width_ / 2.0 : kInset + chip;
	const double icy = vertical ? height_ - kInset - chip : height_ / 2.0;
	cairo_new_path(cr);
	cairo_arc(cr, icx, icy, chip, 0, 2 * M_PI);
	if (off_) {
		set_color(cr, theme::tile_off);
	} else {
		accent_gradient(cr, icx - chip, icy - chip, 2 * chip, 2 * chip);
	}
	cairo_fill(cr);
	draw_glyph(cr, glyph, icx, icy, 20, off_ ? theme::text_dim : theme::on_gradient);

	if (vertical) {
		// The state above the icon: "On" / "Off", or the layout's short name.
		std::string state = off_ ? "Off" : "On";
		if (kind_ == Kind::Layout) {
			state = text_.empty() ? "Layout" : text_.substr(0, std::min<size_t>(text_.size(), 3));
		}
		draw_text(cr, state, 4, 20, width_ - 8, 30, theme::font_bold,
			off_ ? theme::text_dim : theme::text, Align::Center);
		const char *what = kind_ == Kind::Mic ? "Mic" : kind_ == Kind::CapsLock ? "Caps"
			: kind_ == Kind::NumLock ? "Num" : "Keys";
		draw_text(cr, what, 4, 46, width_ - 8, 22, theme::font, theme::text_dim, Align::Center);
	} else {
		const double tx = icx + chip + 12;
		draw_text(cr, title, tx, 0, width_ - tx - 20, height_, theme::font_bold, theme::text);
	}
	layer_->present(canvas, wlr_box{0, 0, width_, height_}, r);
}

// ---- pointer interaction --------------------------------------------------------

// True while what is on the screen is a level bar that can be set (volume,
// brightness): the on/off states and the keyboard layout are not.
bool Osd::interactive() const {
	return level_ >= 0 && (kind_ == Kind::Volume || kind_ == Kind::Brightness);
}

bool Osd::accepts_input(wlr_scene_buffer *buffer, double *sx, double *sy) {
	wlr_scene_tree *tree = buffer->node.parent;
	auto *tag = tree ? static_cast<NodeTag *>(tree->node.data) : nullptr;
	if (!tag || tag->kind != NodeTag::Kind::Osd) {
		return false;
	}
	const Osd *o = static_cast<const Osd *>(tag->object);
	return o->visible_ && o->interactive() && *sx >= 0 && *sy >= 0 &&
		*sx < o->width_ && *sy < o->height_;
}

bool Osd::grabs_input(double lx, double ly) const {
	return visible_ && interactive() && lx >= pos_x_ && ly >= pos_y_ &&
		lx < pos_x_ + width_ && ly < pos_y_ + height_;
}

void Osd::pointer_set(double lx, double ly) {
	if (!interactive()) {
		return;
	}
	// Where the pointer sits along the slider, with the geometry redraw()
	// draws (kInset in from each edge of the card).
	double frac;
	if (server_->config.osd_orientation == "vertical") {
		frac = ((height_ - kInset) - (ly - pos_y_)) / std::max(1.0, height_ - 2 * kInset);
	} else {
		frac = ((lx - pos_x_) - kInset) / std::max(1.0, width_ - 2 * kInset);
	}
	const int max = kind_ == Kind::Volume ? server_->config.volume_max() : 100;
	const int level = static_cast<int>(std::lround(std::clamp(frac, 0.0, 1.0) * max));
	if (kind_ == Kind::Volume) {
		if (server_->status) {
			server_->status->set_volume(level);   // raising it also unmutes
		}
		show(Kind::Volume, level, false);
	} else if (kind_ == Kind::Brightness) {
		if (server_->status) {
			server_->status->set_brightness(level);
		}
		show(Kind::Brightness, level, false);
	}
}

void Osd::pointer_scroll(double delta) {
	if (!interactive()) {
		return;
	}
	// A notch of the wheel is one step, like the keyboard's: scrolling
	// towards you lowers, as everywhere else in Arqen. Both helpers show the
	// OSD again with the new value themselves.
	if (kind_ == Kind::Volume) {
		server_->volume_key(delta > 0 ? "down" : "up", false);
	} else if (kind_ == Kind::Brightness) {
		server_->brightness_key(delta <= 0);
	}
}

} // namespace arqen
