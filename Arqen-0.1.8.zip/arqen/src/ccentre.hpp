// The control centre (like Arqen shell's): a sidebar with you at the top
// (picture, name, how long the computer has been on) and buttons to edit
// the tiles, open Settings and power off; a grid of tiles you arrange
// yourself (toggles, upright sliders, battery, what's playing); and the
// notifications underneath, stacked by app. It opens from a panel's status
// icons on the side of the screen that button is on.
#pragma once

#include <functional>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>

#include "server.hpp"
#include "mediaview.hpp"
#include "sysmon.hpp"
#include "ui.hpp"
#include "popover.hpp"

namespace arqen {

struct LinkedDevice;

// A connected device as a ring: its picture inside, its battery around it
// (`empty_icon` when there's no device). Shared with the app menu.
void draw_device_ring(cairo_t *cr, Server *server, double cx, double cy, double d, const LinkedDevice *dev,
	const std::string &empty_icon, float scale);
// A device's name made short enough to go under its ring: the owner left
// off ("Joseph's S23 Ultra" -> "S23 Ultra"). Shared with the app menu.
std::string device_short_name(const std::string &name);

class ControlCentre {
public:
	explicit ControlCentre(Server *server);
	~ControlCentre();
	ControlCentre(const ControlCentre &) = delete;
	ControlCentre &operator=(const ControlCentre &) = delete;

	bool is_open() const { return open_; }
	bool is_open_on(const Output *output) const { return open_ && output_ == output; }
	void open(Output *output, wlr_box anchor, const std::string &edge);
	// The notification centre: the same card showing only the date and the
	// notifications (when they're kept apart from the controls).
	void open_notes(Output *output, wlr_box anchor, const std::string &edge);
	void toggle_notes(Output *output, wlr_box anchor, const std::string &edge);
	bool notes_open_on(const Output *output) const { return open_ && notes_only_ && output_ == output; }
	bool notes_open() const { return open_ && notes_only_; }
	bool tiles_open_on(const Output *output) const { return open_ && !notes_only_ && output_ == output; }
	void close();
	void toggle(Output *output, wlr_box anchor, const std::string &edge);
	void toggle(Output *output);   // from the keyboard
	void output_gone(Output *output);
	void refresh();                // something it shows changed

	bool contains(double lx, double ly) const;
	void motion(double lx, double ly);
	void leave();
	void press(double lx, double ly, uint32_t button);   // returns grab via server->cc_grab
	void release();
	void scroll(double lx, double ly, double delta);
	bool handle_key(xkb_keysym_t sym, const std::string &text);
	bool wants_keyboard() const { return open_ && typing_; }
	// A menu about to pop up (ContextMenu::show): while the control centre
	// is building one of its pages from a menu, it takes the items instead
	// and shows them as a page (with a back button), like Wi-Fi's.
	bool take_menu(Output *output, std::vector<MenuItem> &items);

	NodeTag tag{NodeTag::Kind::ControlCentre, this};

private:
	struct Hot {
		std::string id;
		wlr_box box;      // local; what reacts to the pointer
		wlr_box vis;      // what lights up (often the same)
		double radius;    // of the highlight; < 0 = none
	};
	enum class Page { Tiles, Wifi, Bluetooth, Options, Sound };
	bool notes_only_ = false;
	int notes_total_ = 0;   // the notifications' height, all of them
	wlr_box notes_anchor_{};
	std::string notes_edge_;
	void redraw_notes();

	void place();
	void redraw();
	void draw_header(cairo_t *cr, int &y, float scale);
	void draw_grid(cairo_t *cr, int &y, float scale);
	void draw_tile(cairo_t *cr, const CcTile &t, const wlr_box &b, float scale, bool floating);
	// The connected devices tile and the KDE Connect tile: each device's
	// picture in a ring showing its battery, its name, and how it's connected.
	void draw_devices_tile(cairo_t *cr, const CcTile &t, const wlr_box &b, double radius, float scale, bool floating);
	bool shows_devices() const;   // a devices tile is in the grid (or could be added)
	void draw_sysmon_tile(cairo_t *cr, const CcTile &t, const wlr_box &b, double radius, float scale, bool floating);
	bool shows_sysmon() const;
	SysMon sysmon_;
	int timer_ticks_ = 0;
	void draw_edit_tray(cairo_t *cr, int &y, float scale);
	void draw_detail(cairo_t *cr, int &y, int bottom, float scale);
	void draw_notifications(cairo_t *cr, int y, int bottom, float scale);
	void draw_clips(cairo_t *cr, int y, int bottom, float scale);   // the clipboard tab
	// The other looks (Settings > Control centre > Look): Windows 11, GNOME, macOS.
	void draw_media(cairo_t *cr, const wlr_box &b, double radius, float scale, MediaView::Look look,
		bool hot);
	// The media card is drawn on its own small layer over the rest, so the
	// wave and a scrolling title move without redrawing everything.
	void redraw_live();
	void place_live();
	void run_media();
	void media_menu(double lx, double ly);
	void output_menu(double lx, double ly);
	void add_hot(const std::string &id, double x, double y, double w, double h,
		double radius = -1, wlr_box vis = {});
	void update_highlight();
	std::string hot_at(double px, double py) const;
	void activate(const std::string &id);
	void open_page(Page page);
	// A right-clicked tile or card: its options as a page of their own. `build`
	// makes the menu (it's run again after each change, so ticks stay right).
	void open_options(const std::string &title, std::function<void()> build);
	void options_pick(size_t index);
	void options_rebuild();
	void draw_options(cairo_t *cr, int &y, int bottom, float scale);
	void draw_page_header(cairo_t *cr, int &y, const std::string &title, float scale);
	struct OptLevel {
		std::string title;
		std::function<void()> build;
		std::vector<MenuItem> items;
	};
	std::vector<OptLevel> opt_stack_;
	Page opt_return_ = Page::Tiles;   // where Back goes from the first options page
	bool capturing_ = false, captured_ = false;
	std::vector<MenuItem> capture_buf_;
	double capture_until_ = 0;   // a menu that arrives a moment later (it asked something first)
	// The Sound page: where sound goes, the microphones, and each app.
	void open_sound();
	void load_sound();
	void draw_sound(cairo_t *cr, int &y, int bottom, float scale);
	void sound_action(const std::string &args);
	struct SoundDev {
		std::string kind;     // SINK, PORT, SOURCE
		std::string name;     // sink/source name, or the card for a port
		std::string profile;  // a port's profile
		std::string label;
		bool current = false;
		int volume = -1;
	};
	struct SoundApp {
		std::string index, name, icon, sink;
		int volume = 100;
		bool muted = false;
	};
	std::vector<SoundDev> sound_outs_, sound_ins_;
	std::vector<SoundApp> sound_apps_;
	std::map<std::string, std::string> sink_ids_;   // index -> name
	bool sound_loaded_ = false, sound_busy_ = false;
	void tile_action(const std::string &tile);   // the tile's main click
	void tile_more(const std::string &tile, double lx, double ly);   // its list or options
	// A clicked notification opens downward, with its options under it.
	struct NoteOption {
		std::string label, icon;
		std::function<void()> run;
		bool danger;
	};
	std::vector<NoteOption> note_options(uint32_t id);
	uint32_t open_note_ = 0;   // the notification that's opened (0 = none)
	void show_tile_menu(const std::string &tile, double lx, double ly);
	void show_menu(double lx, double ly);   // right-click anywhere else
	void show_power_menu(double lx, double ly);
	void drag_slider(double lx, double ly);
	void drag_edit(double px, double py);
	void end_edit_drag();
	void save_layout();
	std::string layout_key() const;   // each look keeps its own arrangement
	wlr_box tile_box(const CcTile &t) const;   // local
	static int handle_timer(void *data);
	void queue_redraw();               // at most once a frame
	static int handle_redraw_timer(void *data);
	wl_event_source *redraw_timer_ = nullptr;
	bool redraw_queued_ = false;

	Server *server_;
	UiLayer layer_;
	Fades fx_;
	Highlight hl_;
	bool drawing_ = false;
	double hv(const std::string &id);    // eased hover amount
	int card_radius() const;
	wl_event_source *timer_;
	Output *output_ = nullptr;
	bool open_ = false;
	bool left_side_ = false;
	wlr_box box_{};
	double alpha_ = 0;
	uint64_t anim_ = 0;

	std::vector<Hot> hots_;
	std::string hover_;
	Page page_ = Page::Tiles;
	std::string dragging_;       // slider being dragged ("sl:<tile>")
	wlr_box drag_track_{};       // its track, local
	bool drag_vertical_ = true;
	int notes_scroll_ = 0, notes_max_scroll_ = 0;
	wlr_box notes_area_{};
	int list_scroll_ = 0, list_max_scroll_ = 0;
	wlr_box list_area_{};

	// The tile grid.
	std::vector<CcTile> layout_;   // what's shown, in grid order
	int grid_top_ = 0;             // local y of the grid's first row
	double cell_ = 50;             // a cell's width
	double row_h_ = 50;
	int drag_value_ = -1;          // the slider's value while dragged (changes only)            // and height (square, but shorter rows for the Windows look)
	bool editing_ = false;
	std::string edit_tile_;        // being moved or resized
	bool edit_resize_ = false;
	double grab_dx_ = 0, grab_dy_ = 0;   // pointer within the tile when it was picked up
	double edit_px_ = 0, edit_py_ = 0;   // the pointer now (local)
	CcTile edit_target_;           // where it would land
	bool edit_target_ok_ = false;
	std::set<std::string> open_groups_;   // notification stacks that are opened up
	bool clip_tab_ = false;               // the notification centre shows the clipboard history

	// Wi-Fi password entry.
	bool typing_ = false;
	std::string password_;
	std::string password_for_;   // SSID
	std::string wifi_message_;
	bool connecting_ = false;
	std::unique_ptr<BusyBar> busy_;   // the sweeping line while scanning or connecting
	wlr_box busy_box_{};              // where it goes (local); width 0 = not shown

	// You: picture and name.
	cairo_surface_t *avatar_ = nullptr;
	bool avatar_tried_ = false;
	std::string user_name_;

	// What's playing.
	std::unique_ptr<MediaView> media_;
	wlr_scene_buffer *live_ = nullptr;   // the media card, redrawn on its own
	wlr_box media_box_{};                // where it is (local); width 0 = not shown
	MediaView::Look media_look_ = MediaView::Look::Samsung;
	double media_radius_ = 0;
	bool media_live_ = false;
	uint64_t media_ticker_ = 0;
	double live_wait_ = 0;
	int width_ = 392;
	int cal_offset_ = 0;                 // the notification sidebar's calendar: months from this one
};

} // namespace arqen
