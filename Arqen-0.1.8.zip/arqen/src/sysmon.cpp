#include "sysmon.hpp"

#include <dirent.h>
#include <dlfcn.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>

namespace arqen {

namespace {

double mono_ms() {
	using namespace std::chrono;
	return duration<double, std::milli>(steady_clock::now().time_since_epoch()).count();
}

std::string read_line(const std::string &path) {
	std::ifstream f(path);
	std::string s;
	std::getline(f, s);
	return s;
}

bool exists(const std::string &path) {
	std::ifstream f(path);
	return f.good();
}

// NVML (libnvidia-ml, part of NVIDIA's driver): just the calls used here.
using nvmlReturn_t = int;
using nvmlDevice_t = void *;
struct nvmlUtilization_t {
	unsigned int gpu, memory;
};
using InitFn = nvmlReturn_t (*)();
using ShutdownFn = nvmlReturn_t (*)();
using ByPciFn = nvmlReturn_t (*)(const char *, nvmlDevice_t *);
using UtilFn = nvmlReturn_t (*)(nvmlDevice_t, nvmlUtilization_t *);
struct nvmlMemory_t {
	unsigned long long total, free, used;
};
using MemFn = nvmlReturn_t (*)(nvmlDevice_t, nvmlMemory_t *);

constexpr double kGiB = 1024.0 * 1024.0 * 1024.0;

// AMD: the memory of its own, used and all, from sysfs (bytes).
void amd_vram(const std::string &dev, double &used_gb, double &total_gb) {
	const double total = std::atof(read_line(dev + "/mem_info_vram_total").c_str());
	if (total <= 0) return;
	total_gb = total / kGiB;
	used_gb = std::atof(read_line(dev + "/mem_info_vram_used").c_str()) / kGiB;
}

} // namespace

SysMon::SysMon() {
	thread_ = std::thread([this] { run(); });
}

SysMon::~SysMon() {
	{
		std::lock_guard<std::mutex> lock(mutex_);
		quit_ = true;
	}
	cv_.notify_all();
	if (thread_.joinable()) thread_.join();
	if (nvml_) dlclose(nvml_);
}

void SysMon::want(bool on) {
	{
		std::lock_guard<std::mutex> lock(mutex_);
		if (wanted_ == on) return;
		wanted_ = on;
	}
	cv_.notify_all();
}

SysSample SysMon::sample() const {
	std::lock_guard<std::mutex> lock(mutex_);
	return last_;
}

void SysMon::run() {
	std::unique_lock<std::mutex> lock(mutex_);
	while (!quit_) {
		cv_.wait(lock, [this] { return quit_ || wanted_; });
		if (quit_) break;
		SysSample s = last_;
		lock.unlock();
		read(s);
		lock.lock();
		last_ = s;
		cv_.wait_for(lock, std::chrono::seconds(2), [this] { return quit_ || !wanted_; });
	}
}

// Which graphics there are, and where each says how busy it is.
void SysMon::probe(SysSample &s) {
	probed_ = true;
	DIR *d = opendir("/sys/class/drm");
	if (!d) return;
	while (dirent *e = readdir(d)) {
		const std::string name = e->d_name;
		if (name.rfind("card", 0) != 0 || name.find('-') != std::string::npos) continue;
		const std::string card = "/sys/class/drm/" + name, dev = card + "/device";
		const std::string vendor = read_line(dev + "/vendor");
		if (vendor == "0x8086") {
			// Intel: busy is the time it's not resting (RC6), i915 or xe.
			for (const std::string &p : {card + "/gt/gt0/rc6_residency_ms", card + "/power/rc6_residency_ms",
					dev + "/tile0/gt0/gtidle/idle_residency_ms"}) {
				if (exists(p)) {
					intel_rc6_ = p;
					s.has_igpu = true;
					s.igpu_name = "Intel graphics";
					break;
				}
			}
		} else if (vendor == "0x1002" && exists(dev + "/gpu_busy_percent")) {
			// AMD: a little memory of its own is a chip's (an APU), lots a card's.
			const double vram = std::atof(read_line(dev + "/mem_info_vram_total").c_str());
			if (vram > 0 && vram < 3.0 * (1ull << 30)) {
				amd_igpu_busy_ = dev + "/gpu_busy_percent";
				amd_igpu_dev_ = dev;
				s.has_igpu = true;
				s.igpu_name = "AMD graphics";
			} else {
				amd_gpu_busy_ = dev + "/gpu_busy_percent";
				amd_gpu_dev_ = dev;
				s.has_gpu = true;
				s.gpu_name = "AMD Radeon";
			}
		} else if (vendor == "0x10de") {
			// NVIDIA: through NVML; the PCI address finds the card.
			char buf[512] = {};
			const ssize_t n = readlink(dev.c_str(), buf, sizeof buf - 1);
			if (n > 0) {
				std::string target(buf, static_cast<size_t>(n));
				nvidia_pci_ = target.substr(target.rfind('/') + 1);
				s.has_gpu = true;
				s.gpu_name = "NVIDIA";
			}
		}
	}
	closedir(d);
}

// NVIDIA: asked only when the card is awake already. Asking opens the card,
// so it's asked seldom (every ten seconds) and let go at once, or a laptop's
// card would never get to power down.
double SysMon::nvidia_busy(bool &asleep, double &used_gb, double &total_gb) {
	asleep = false;
	const std::string status = read_line("/sys/bus/pci/devices/" + nvidia_pci_ + "/power/runtime_status");
	if (status == "suspended" || status == "suspending") {
		asleep = true;
		return 0;
	}
	if (!nvml_) nvml_ = dlopen("libnvidia-ml.so.1", RTLD_NOW | RTLD_LOCAL);
	if (!nvml_) return -1;
	auto init = reinterpret_cast<InitFn>(dlsym(nvml_, "nvmlInit_v2"));
	auto shutdown = reinterpret_cast<ShutdownFn>(dlsym(nvml_, "nvmlShutdown"));
	auto by_pci = reinterpret_cast<ByPciFn>(dlsym(nvml_, "nvmlDeviceGetHandleByPciBusId_v2"));
	auto util = reinterpret_cast<UtilFn>(dlsym(nvml_, "nvmlDeviceGetUtilizationRates"));
	auto mem = reinterpret_cast<MemFn>(dlsym(nvml_, "nvmlDeviceGetMemoryInfo"));
	if (!init || !shutdown || !by_pci || !util || init() != 0) return -1;
	double busy = -1;
	nvmlDevice_t device = nullptr;
	nvmlUtilization_t u{};
	if (by_pci(nvidia_pci_.c_str(), &device) == 0) {
		if (util(device, &u) == 0) busy = u.gpu / 100.0;
		nvmlMemory_t m{};
		if (mem && mem(device, &m) == 0 && m.total > 0) {
			total_gb = static_cast<double>(m.total) / kGiB;
			used_gb = static_cast<double>(m.used) / kGiB;
		}
	}
	shutdown();
	return busy;
}

void SysMon::read(SysSample &s) {
	if (!probed_) probe(s);

	// CPU: the share of time not idle since the last reading.
	{
		std::ifstream f("/proc/stat");
		std::string cpu;
		uint64_t v[10] = {};
		f >> cpu;
		for (uint64_t &x : v) f >> x;
		const uint64_t idle = v[3] + v[4], total = v[0] + v[1] + v[2] + v[3] + v[4] + v[5] + v[6] + v[7];
		if (cpu_total_ && total > cpu_total_) {
			s.cpu = std::clamp(1.0 - static_cast<double>(idle - cpu_idle_) / static_cast<double>(total - cpu_total_),
				0.0, 1.0);
		}
		cpu_idle_ = idle;
		cpu_total_ = total;
	}

	// Memory and swap.
	{
		std::ifstream f("/proc/meminfo");
		std::string key;
		double total = 0, avail = 0, stotal = 0, sfree = 0, kb = 0;
		std::string unit;
		while (f >> key >> kb) {
			std::getline(f, unit);
			if (key == "MemTotal:") total = kb;
			else if (key == "MemAvailable:") avail = kb;
			else if (key == "SwapTotal:") stotal = kb;
			else if (key == "SwapFree:") sfree = kb;
		}
		const double gb = 1024.0 * 1024.0;
		if (total > 0) {
			s.ram = std::clamp((total - avail) / total, 0.0, 1.0);
			s.ram_used_gb = (total - avail) / gb;
			s.ram_total_gb = total / gb;
		}
		s.has_swap = stotal > 0;
		s.swap = stotal > 0 ? std::clamp((stotal - sfree) / stotal, 0.0, 1.0) : 0;
		s.swap_used_gb = (stotal - sfree) / gb;
		s.swap_total_gb = stotal / gb;
	}

	// The built-in graphics.
	if (!intel_rc6_.empty()) {
		const double rc6 = std::atof(read_line(intel_rc6_).c_str()), now = mono_ms();
		if (rc6_ms_ >= 0 && now > rc6_at_) {
			s.igpu = std::clamp(1.0 - (rc6 - rc6_ms_) / (now - rc6_at_), 0.0, 1.0);
		}
		rc6_ms_ = rc6;
		rc6_at_ = now;
	} else if (!amd_igpu_busy_.empty()) {
		s.igpu = std::clamp(std::atof(read_line(amd_igpu_busy_).c_str()) / 100.0, 0.0, 1.0);
		amd_vram(amd_igpu_dev_, s.igpu_used_gb, s.igpu_total_gb);
	}

	// A separate card.
	if (!amd_gpu_busy_.empty()) {
		s.gpu = std::clamp(std::atof(read_line(amd_gpu_busy_).c_str()) / 100.0, 0.0, 1.0);
		amd_vram(amd_gpu_dev_, s.gpu_used_gb, s.gpu_total_gb);
	} else if (!nvidia_pci_.empty()) {
		static double asked = -1e9;
		const double now = mono_ms();
		bool asleep = false;
		const std::string status = read_line("/sys/bus/pci/devices/" + nvidia_pci_ + "/power/runtime_status");
		if (status == "suspended" || status == "suspending") {
			s.gpu_asleep = true;
			s.gpu = 0;
			s.gpu_used_gb = 0;
		} else if (now - asked >= 10000) {
			asked = now;
			s.gpu = nvidia_busy(asleep, s.gpu_used_gb, s.gpu_total_gb);
			s.gpu_asleep = asleep;
		}
	}
}

} // namespace arqen
