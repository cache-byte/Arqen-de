#include "wallpicker.hpp"

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <linux/input-event-codes.h>

#include "anim.hpp"
#include "draw.hpp"
#include "imageload.hpp"
#include "overview.hpp"
#include "wallpaper.hpp"

namespace arqen {

namespace {

bool no_input(wlr_scene_buffer *, double *, double *) {
	return false;
}

constexpr int kThumb = 560;     // small pictures: fit in this square
constexpr size_t kBigs = 4;     // screen-sized pictures kept at once

std::string lower(std::string s) {
	std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
	return s;
}

// Is (px, py) inside the convex quad (corners in order)?
bool in_quad(const double *x, const double *y, double px, double py) {
	int sign = 0;
	for (int i = 0; i < 4; i++) {
		const int j = (i + 1) % 4;
		const double c = (x[j] - x[i]) * (py - y[i]) - (y[j] - y[i]) * (px - x[i]);
		const int s = c > 0 ? 1 : c < 0 ? -1 : 0;
		if (s == 0) continue;
		if (sign == 0) sign = s;
		else if (s != sign) return false;
	}
	return true;
}

// Paints `img` covering (0, 0, w, h) (cropped to keep its shape).
void paint_cover(cairo_t *cr, cairo_surface_t *img, double w, double h) {
	const double iw = cairo_image_surface_get_width(img), ih = cairo_image_surface_get_height(img);
	if (iw <= 0 || ih <= 0) return;
	const double k = std::max(w / iw, h / ih);
	cairo_save(cr);
	cairo_rectangle(cr, 0, 0, w, h);
	cairo_clip(cr);
	cairo_translate(cr, (w - iw * k) / 2, (h - ih * k) / 2);
	cairo_scale(cr, k, k);
	cairo_set_source_surface(cr, img, 0, 0);
	cairo_pattern_set_filter(cairo_get_source(cr), CAIRO_FILTER_GOOD);
	cairo_paint(cr);
	cairo_restore(cr);
}

} // namespace

WallpaperPicker::WallpaperPicker(Server *server) : server_(server) {
	tree_ = wlr_scene_tree_create(server->layer_overlay);
	for (auto &b : bg_) {
		b = wlr_scene_buffer_create(tree_, nullptr);
		b->point_accepts_input = no_input;
	}
	const float shade[4] = {0, 0, 0, 0};
	shade_ = wlr_scene_rect_create(tree_, 0, 0, shade);
	cards_ = wlr_scene_buffer_create(tree_, nullptr);
	cards_->point_accepts_input = no_input;
	wlr_scene_node_set_enabled(&tree_->node, false);
}

WallpaperPicker::~WallpaperPicker() {
	*alive_ = false;
	if (ticker_) server_->anim->remove_ticker(ticker_);
	for (auto *m : {&thumbs_, &bigs_}) {
		for (auto &[path, s] : *m) {
			if (s) cairo_surface_destroy(s);
		}
	}
	wlr_scene_node_destroy(&tree_->node);
}

// Arqen's own first, then the pictures in your wallpaper folder (by name),
// and the one set now if it lives somewhere else.
void WallpaperPicker::find_items() {
	items_.clear();
	items_.push_back({"", "Arqen"});
	const Config &c = server_->config;
	std::string dir = c.wallpaper_dir;
	const char *h = std::getenv("HOME");
	const std::string home = h ? h : "";
	if (dir.empty()) dir = home + "/Pictures/Wallpapers";
	else if (dir.rfind("~/", 0) == 0) dir = home + dir.substr(1);
	std::vector<std::string> found;
	std::error_code ec;
	std::filesystem::recursive_directory_iterator it(dir, std::filesystem::directory_options::skip_permission_denied |
		std::filesystem::directory_options::follow_directory_symlink, ec);
	for (int seen = 0; !ec && it != std::filesystem::recursive_directory_iterator() && seen < 2000; it.increment(ec), seen++) {
		if (it.depth() > 2) it.disable_recursion_pending();
		if (!it->is_regular_file(ec)) continue;
		const std::string ext = lower(it->path().extension().string());
		if (ext != ".png" && ext != ".jpg" && ext != ".jpeg" && ext != ".webp" && ext != ".jxl" && ext != ".avif") continue;
		found.push_back(it->path().string());
		if (found.size() >= 500) break;
	}
	std::sort(found.begin(), found.end(), [](const std::string &a, const std::string &b) { return lower(a) < lower(b); });
	if (c.wallpaper_type == "image" && !c.wallpaper.empty() &&
			std::find(found.begin(), found.end(), c.wallpaper) == found.end()) {
		found.insert(found.begin(), c.wallpaper);
	}
	for (const std::string &p : found) {
		items_.push_back({p, std::filesystem::path(p).stem().string()});
	}
}

void WallpaperPicker::toggle(Output *output) {
	if (open_) close(false);
	else open(output);
}

void WallpaperPicker::open(Output *output) {
	if (open_ || !output || server_->locked()) return;
	server_->close_popups();
	if (server_->overview && server_->overview->is_open()) server_->overview->close();
	output_ = output;
	style_ = server_->config.wallpaper_picker;
	find_items();
	const Config &c = server_->config;
	selected_ = 0;
	if (c.wallpaper_type == "image") {
		for (size_t i = 1; i < items_.size(); i++) {
			if (items_[i].path == c.wallpaper) selected_ = static_cast<int>(i);
		}
	}
	started_ = selected_;
	pos_ = selected_;
	open_ = true;
	closing_ = false;
	bg_shown_ = -2;
	const wlr_box ob = output_->box();
	wlr_scene_node_set_position(&tree_->node, ob.x, ob.y);
	wlr_scene_rect_set_size(shade_, ob.width, ob.height);
	wlr_scene_node_raise_to_top(&tree_->node);
	wlr_scene_node_set_enabled(&tree_->node, true);
	if (!c.animate(true)) alpha_ = 1;
	want_pictures();
	draw_background();
	draw_cards();
	if (!ticker_) {
		ticker_ = server_->anim->add_ticker([this](double dt) { return tick(dt); });
	}
	tick(0);
}

void WallpaperPicker::close(bool apply) {
	if (!open_) return;
	if (apply) apply_selected();
	open_ = false;
	closing_ = true;
	if (!server_->config.animate(true)) alpha_ = 0;
	if (!ticker_) {
		ticker_ = server_->anim->add_ticker([this](double dt) { return tick(dt); });
	}
	tick(0);
}

void WallpaperPicker::output_gone(Output *output) {
	if (output_ != output) return;
	open_ = false;
	closing_ = false;
	alpha_ = 0;
	output_ = nullptr;
	wlr_scene_node_set_enabled(&tree_->node, false);
}

void WallpaperPicker::apply_selected() {
	if (selected_ < 0 || selected_ >= static_cast<int>(items_.size())) return;
	const Item &it = items_[static_cast<size_t>(selected_)];
	if (it.path.empty()) {
		server_->write_setting("wallpaper_type", "arqen");
	} else {
		// "From wallpaper" (Settings > Appearance): the accent follows the
		// picture. Worked out from the picture already shown here, at once, and
		// written with the picture, the same as Settings does; Arqen otherwise
		// works it out while it reads the whole photo.
		if (server_->config.accent_auto) {
			cairo_surface_t *src = nullptr;
			for (auto *m : {&bigs_, &thumbs_}) {
				auto f = m->find(it.path);
				if (!src && f != m->end() && f->second) src = f->second;
			}
			Color col;
			if (src && accent_from_surface(src, col)) {
				char hex[16];
				std::snprintf(hex, sizeof hex, "#%02x%02x%02x", static_cast<int>(std::lround(col.r * 255)),
					static_cast<int>(std::lround(col.g * 255)), static_cast<int>(std::lround(col.b * 255)));
				Config::write_key("accent", hex);
				Config::write_key("accent_for", it.path);
			}
		}
		server_->write_setting("wallpaper", it.path);
		server_->write_setting("wallpaper_type", "image");
	}
}

void WallpaperPicker::select(int index) {
	if (items_.empty()) return;
	index = std::clamp(index, 0, static_cast<int>(items_.size()) - 1);
	if (index == selected_) return;
	selected_ = index;
	if (!server_->config.animate(true)) pos_ = selected_;
	want_pictures();
	draw_background();
	if (!ticker_) {
		ticker_ = server_->anim->add_ticker([this](double dt) { return tick(dt); });
	}
}

void WallpaperPicker::step_by(int delta) {
	select(selected_ + delta);
}

bool WallpaperPicker::tick(double dt) {
	if (!output_) {
		ticker_ = 0;
		return false;
	}
	dt = std::min(dt, 50.0);
	bool moving = false;
	const double target_alpha = open_ ? 1.0 : 0.0;
	if (std::fabs(alpha_ - target_alpha) > 0.002) {
		alpha_ += (target_alpha - alpha_) * std::min(1.0, dt / 70.0);
		if (std::fabs(alpha_ - target_alpha) <= 0.002) alpha_ = target_alpha;
		moving = true;
	}
	const double old_pos = pos_;
	if (std::fabs(pos_ - selected_) > 0.001) {
		pos_ += (selected_ - pos_) * std::min(1.0, dt / 85.0);
		if (std::fabs(pos_ - selected_) <= 0.001) pos_ = selected_;
		moving = true;
	}
	if (bg_fade_ < 1) {
		bg_fade_ = std::min(1.0, bg_fade_ + dt / 220.0);
		if (!server_->config.animate(true)) bg_fade_ = 1;
		moving = true;
	}
	// The look: everything fades with the picker; the new preview over the old.
	const float a = static_cast<float>(alpha_);
	wlr_scene_buffer_set_opacity(bg_[front_], a * static_cast<float>(bg_fade_));
	wlr_scene_buffer_set_opacity(bg_[1 - front_], a);
	wlr_scene_node_set_enabled(&bg_[1 - front_]->node, bg_fade_ < 1);
	const float shade[4] = {0, 0, 0, 0.22f * a};
	wlr_scene_rect_set_color(shade_, shade);
	wlr_scene_buffer_set_opacity(cards_, a);
	if (old_pos != pos_) draw_cards();
	if (!open_ && alpha_ <= 0) {
		closing_ = false;
		wlr_scene_node_set_enabled(&tree_->node, false);
		// The big pictures are only for the preview: let them go.
		for (auto &[path, s] : bigs_) {
			if (s) cairo_surface_destroy(s);
		}
		bigs_.clear();
		big_order_.clear();
		wlr_scene_buffer_set_buffer(bg_[0], nullptr);
		wlr_scene_buffer_set_buffer(bg_[1], nullptr);
		wlr_scene_buffer_set_buffer(cards_, nullptr);
		ticker_ = 0;
		return false;
	}
	if (!moving) {
		ticker_ = 0;
		return false;
	}
	return true;
}

// Reads the pictures near the chosen one (and forgets far-away ones, so a
// big folder doesn't fill the memory).
void WallpaperPicker::want_pictures() {
	const int n = static_cast<int>(items_.size());
	for (int d = 0; d <= 9; d++) {
		for (int s : {selected_ - d, selected_ + d}) {
			if (s >= 0 && s < n) picture(s, false);
			if (d == 0) break;
		}
	}
	picture(selected_, true);
	for (auto it = thumbs_.begin(); it != thumbs_.end();) {
		int at = -1;
		for (int i = std::max(0, selected_ - 24); i < std::min(n, selected_ + 25); i++) {
			if (items_[static_cast<size_t>(i)].path == it->first) at = i;
		}
		if (at < 0 && it->second) {
			cairo_surface_destroy(it->second);
			it = thumbs_.erase(it);
		} else {
			++it;
		}
	}
}

cairo_surface_t *WallpaperPicker::picture(int index, bool big) {
	if (index < 0 || index >= static_cast<int>(items_.size()) || !output_) return nullptr;
	const std::string &path = items_[static_cast<size_t>(index)].path;
	if (path.empty()) return nullptr;
	auto &cache = big ? bigs_ : thumbs_;
	auto it = cache.find(path);
	if (it != cache.end()) return it->second;
	cache[path] = nullptr;
	if (big) {
		big_order_.push_back(path);
		while (big_order_.size() > kBigs) {
			auto old = bigs_.find(big_order_.front());
			if (old != bigs_.end() && old->second) {
				cairo_surface_destroy(old->second);
				bigs_.erase(old);
			}
			big_order_.erase(big_order_.begin());
		}
	}
	const wlr_box ob = output_->box();
	const float scale = output_->output->scale;
	const int size = big ? static_cast<int>(std::max(ob.width, ob.height) * scale) : kThumb;
	std::weak_ptr<bool> alive = alive_;
	auto done = [this, alive, path, big](cairo_surface_t *s) {
		auto token = alive.lock();
		if (!token || !*token) {
			if (s) cairo_surface_destroy(s);
			return;
		}
		auto &cache = big ? bigs_ : thumbs_;
		auto it = cache.find(path);
		if (it == cache.end()) {   // forgotten meanwhile
			if (s) cairo_surface_destroy(s);
			return;
		}
		if (it->second) cairo_surface_destroy(it->second);
		it->second = s;
		if (!open_) return;
		const bool shown = selected_ >= 0 && selected_ < static_cast<int>(items_.size()) &&
			items_[static_cast<size_t>(selected_)].path == path;
		if (shown && (big || !bigs_[path])) {
			bg_shown_ = -2;   // drawn again, sharper
			draw_background();
		}
		draw_cards();
	};
	if (server_->images) {
		server_->images->request(path, size, size, done);
	} else {
		done(load_image_sized(path, size, size));
	}
	auto again = cache.find(path);
	return again != cache.end() ? again->second : nullptr;
}

void WallpaperPicker::draw_picture(cairo_t *cr, int index, double w, double h, bool big) {
	if (index < 0 || index >= static_cast<int>(items_.size())) return;
	if (items_[static_cast<size_t>(index)].path.empty()) {
		// Arqen's own: drawn at the size it's shown (cheap enough, and sharp).
		cairo_save(cr);
		cairo_rectangle(cr, 0, 0, w, h);
		cairo_clip(cr);
		draw_arqen_wallpaper(cr, server_->config, w, h);
		cairo_restore(cr);
		return;
	}
	cairo_surface_t *img = big ? picture(index, true) : nullptr;
	if (!img) img = picture(index, false);
	if (img) {
		paint_cover(cr, img, w, h);
	} else {
		set_color(cr, rgb(0x2a2a30));
		cairo_rectangle(cr, 0, 0, w, h);
		cairo_fill(cr);
	}
}

// The chosen one, over the whole screen (a quick fade from the last one).
void WallpaperPicker::draw_background() {
	if (!output_ || items_.empty()) return;
	const bool same = bg_shown_ == selected_;
	if (same) return;
	const bool refresh = bg_shown_ == -2 && bg_fade_ >= 1 && bg_[front_]->buffer;
	const wlr_box ob = output_->box();
	Canvas canvas(ob.width, ob.height, output_->output->scale);
	draw_picture(canvas.cr(), selected_, ob.width, ob.height, true);
	if (!refresh) {
		front_ = 1 - front_;
		bg_fade_ = server_->config.animate(true) && bg_[1 - front_]->buffer ? 0 : 1;
	}
	canvas.present(bg_[front_]);
	wlr_scene_node_raise_to_top(&bg_[front_]->node);
	wlr_scene_node_raise_to_top(&shade_->node);
	wlr_scene_node_raise_to_top(&cards_->node);
	wlr_scene_node_set_enabled(&bg_[front_]->node, true);
	bg_shown_ = selected_;
	if (!ticker_ && (open_ || closing_)) {
		ticker_ = server_->anim->add_ticker([this](double dt) { return tick(dt); });
	}
}

void WallpaperPicker::draw_cards() {
	if (!output_ || items_.empty()) return;
	const wlr_box ob = output_->box();
	const double W = ob.width, H = ob.height;
	const double aspect = H / W;
	const int n = static_cast<int>(items_.size());
	const double radius = std::max(8.0, std::min(18.0, theme::ui_radius * 1.0));

	struct Placed {
		int index;
		double cx, cy, w, h, skew, alpha, dim, depth;
		bool chosen;
	};
	std::vector<Placed> placed;
	wlr_box band{0, 0, ob.width, ob.height};

	if (style_ == "strip") {
		// A row of slanted cards along the bottom; the chosen one wide.
		const double hb = std::round(H * 0.25), hs = hb * 0.9;
		const double wb = hb * 1.75, ws = hb * 0.46, gap = 6;
		band = wlr_box{0, static_cast<int>(H - hb - 92), ob.width, static_cast<int>(hb + 84)};
		const double cy = band.height - 20 - hb / 2;
		for (int i = 0; i < n; i++) {
			const double d = i - pos_, a = std::fabs(d);
			const double near = std::max(0.0, 1 - a);
			const double w = ws + (wb - ws) * near, h = hs + (hb - hs) * near;
			const double off = std::min(a, 1.0) * (wb / 2 + ws / 2 + gap) + std::max(0.0, a - 1) * (ws + gap);
			const double cx = W / 2 + (d < 0 ? -off : off);
			if (cx + w / 2 + hb * 0.2 < 0 || cx - w / 2 - hb * 0.2 > W) continue;
			const double edge = std::min(cx, W - cx) / (W * 0.12);
			placed.push_back({i, cx, cy, w, h, 0.2, std::clamp(edge, 0.0, 1.0), 0.28 * std::min(a, 1.0), -a, a < 0.5});
		}
	} else if (style_ == "stack") {
		// A column down the right-hand side; the chosen one bigger, out a little.
		const double ws = std::round(W * 0.15), wb = ws * 1.18;
		const double hs = ws * aspect, hb = wb * aspect, gap = 16, margin = 36;
		// (Wide enough for the name, to the left of the chosen one.)
		const int bw = static_cast<int>(wb + margin + 30 + 380);
		band = wlr_box{static_cast<int>(W) - bw, 0, bw, ob.height};
		for (int i = 0; i < n; i++) {
			const double d = i - pos_, a = std::fabs(d);
			const double near = std::max(0.0, 1 - a);
			const double w = ws + (wb - ws) * near, h = hs + (hb - hs) * near;
			const double off = std::min(a, 1.0) * (hb / 2 + hs / 2 + gap) + std::max(0.0, a - 1) * (hs + gap);
			const double cy = H / 2 + (d < 0 ? -off : off);
			if (cy + h / 2 < 0 || cy - h / 2 > H) continue;
			const double cx = band.width - margin - w / 2 - 12 * near;
			const double edge = std::min(cy, H - cy) / (H * 0.12);
			placed.push_back({i, cx, cy, w, h, 0, std::clamp(edge, 0.0, 1.0), 0.25 * std::min(a, 1.0), -a, a < 0.5});
		}
	} else {
		// Carousel: the chosen one big in the middle, its neighbours behind.
		const double cw = std::round(W * 0.44), ch = cw * aspect;
		band = wlr_box{0, static_cast<int>(H / 2 - ch / 2 - 40), ob.width, static_cast<int>(ch + 80)};
		const double cy = band.height / 2.0;
		for (int i = 0; i < n; i++) {
			const double d = i - pos_, a = std::fabs(d);
			if (a > 3.2) continue;
			const double k = a <= 1 ? 1 - 0.28 * a : std::max(0.45, 0.72 - 0.13 * (a - 1));
			const double off = cw * (a <= 1 ? 0.64 * a : 0.64 + 0.34 * (a - 1));
			const double alpha = a <= 2 ? 1.0 : std::max(0.0, 1 - (a - 2) / 1.2);
			placed.push_back({i, W / 2 + (d < 0 ? -off : off), cy, cw * k, ch * k, 0, alpha,
				0.42 * std::min(a, 1.0) + 0.1 * std::max(0.0, a - 1), -a, a < 0.5});
		}
	}
	band_ = band;
	std::sort(placed.begin(), placed.end(), [](const Placed &a, const Placed &b) { return a.depth < b.depth; });

	const float scale = output_->output->scale;
	Canvas canvas(band.width, band.height, scale);
	cairo_t *cr = canvas.cr();
	cards_drawn_.clear();
	for (const Placed &p : placed) {
		if (p.alpha <= 0.01) continue;
		cairo_save(cr);
		cairo_matrix_t m;
		cairo_matrix_init(&m, 1, 0, -p.skew, 1, p.cx, p.cy);   // slanted: the top leans right
		// A soft shadow under it.
		cairo_save(cr);
		cairo_transform(cr, &m);
		for (int s = 3; s >= 1; s--) {
			rounded_rect(cr, -p.w / 2 - s * 2, -p.h / 2 - s * 2 + 6, p.w + s * 4, p.h + s * 4, radius + s * 2);
			set_color(cr, rgb(0x000000, 0.07 * p.alpha));
			cairo_fill(cr);
		}
		rounded_rect(cr, -p.w / 2, -p.h / 2, p.w, p.h, radius);
		cairo_restore(cr);
		cairo_clip(cr);
		// The picture itself upright (only its frame is slanted).
		const double bw = p.w + std::fabs(p.skew) * p.h;
		cairo_push_group(cr);
		cairo_translate(cr, p.cx - bw / 2, p.cy - p.h / 2);
		draw_picture(cr, p.index, bw, p.h, p.chosen && style_ == "carousel");
		if (p.dim > 0.005) {
			set_color(cr, rgb(0x000000, p.dim));
			cairo_paint(cr);
		}
		cairo_pop_group_to_source(cr);
		cairo_paint_with_alpha(cr, p.alpha);
		cairo_restore(cr);
		// The chosen one: an accent ring; the others a faint edge.
		cairo_save(cr);
		cairo_transform(cr, &m);
		rounded_rect(cr, -p.w / 2, -p.h / 2, p.w, p.h, radius);
		if (p.chosen) {
			set_color(cr, with_alpha(theme::accent, p.alpha));
			cairo_set_line_width(cr, 3);
		} else {
			set_color(cr, rgb(0xffffff, 0.18 * p.alpha));
			cairo_set_line_width(cr, 1);
		}
		cairo_stroke(cr);
		cairo_restore(cr);
		// Its corners on the screen, for clicks.
		Card c{p.index, {}, {}};
		const double xs[4] = {-p.w / 2, p.w / 2, p.w / 2, -p.w / 2}, ys[4] = {-p.h / 2, -p.h / 2, p.h / 2, p.h / 2};
		for (int k = 0; k < 4; k++) {
			double x = xs[k], y = ys[k];
			cairo_matrix_transform_point(&m, &x, &y);
			c.x[k] = band.x + x;
			c.y[k] = band.y + y;
		}
		cards_drawn_.push_back(c);
	}
	// The chosen one's name, and where it is in the list.
	if (selected_ >= 0 && selected_ < n) {
		const std::string label = items_[static_cast<size_t>(selected_)].name + "   " +
			std::to_string(selected_ + 1) + " / " + std::to_string(n);
		const int tw = std::min(text_width(label, theme::font_bold) + 36, band.width - 40);
		const double th = 30;
		double lx, ly;
		if (style_ == "stack") {
			const double wb = std::round(W * 0.15) * 1.18;
			lx = band.width - 36 - 12 - wb - 18 - tw;
			ly = H / 2 - th / 2;
		} else if (style_ == "strip") {
			lx = (band.width - tw) / 2.0;
			ly = 12;
		} else {
			lx = (band.width - tw) / 2.0;
			ly = band.height - th;
		}
		fill_rounded(cr, lx, ly, tw, th, th / 2, rgb(0x000000, 0.45));
		draw_text(cr, label, lx + 18, ly, tw - 36, th, theme::font_bold, rgb(0xffffff), Align::Center);
	}
	canvas.present(cards_);
	wlr_scene_node_set_position(&cards_->node, band.x, band.y);
}

int WallpaperPicker::card_at(double lx, double ly) const {
	if (!output_) return -1;
	const wlr_box ob = output_->box();
	const double x = lx - ob.x, y = ly - ob.y;
	// The ones drawn last are on top.
	for (auto it = cards_drawn_.rbegin(); it != cards_drawn_.rend(); ++it) {
		if (in_quad(it->x, it->y, x, y)) return it->index;
	}
	return -1;
}

void WallpaperPicker::motion(double, double) {
	server_->set_cursor("default");
}

void WallpaperPicker::button(double lx, double ly, uint32_t button, bool pressed) {
	if (!pressed || !open_) return;
	if (button == BTN_RIGHT) {
		close(false);
		return;
	}
	if (button != BTN_LEFT) return;
	const int i = card_at(lx, ly);
	if (i < 0) {
		close(false);
	} else if (i == selected_) {
		close(true);
	} else {
		select(i);
	}
}

void WallpaperPicker::scroll(double delta) {
	if (!open_) return;
	scroll_acc_ += delta;
	while (scroll_acc_ >= 12) {
		scroll_acc_ -= 12;
		step_by(1);
	}
	while (scroll_acc_ <= -12) {
		scroll_acc_ += 12;
		step_by(-1);
	}
}

bool WallpaperPicker::key(xkb_keysym_t sym, uint32_t modifiers) {
	if (!open_) return false;
	const bool super = modifiers & WLR_MODIFIER_LOGO;
	switch (sym) {
	case XKB_KEY_Escape:
		close(false);
		return true;
	case XKB_KEY_w:
	case XKB_KEY_W:
		if (super) close(false);
		return true;
	case XKB_KEY_Return:
	case XKB_KEY_KP_Enter:
	case XKB_KEY_space:
		close(true);
		return true;
	case XKB_KEY_Left:
	case XKB_KEY_Up:
	case XKB_KEY_h:
	case XKB_KEY_k:
		step_by(-1);
		return true;
	case XKB_KEY_Right:
	case XKB_KEY_Down:
	case XKB_KEY_l:
	case XKB_KEY_j:
	case XKB_KEY_Tab:
		step_by(1);
		return true;
	case XKB_KEY_ISO_Left_Tab:
		step_by(-1);
		return true;
	case XKB_KEY_Page_Up:
		step_by(-5);
		return true;
	case XKB_KEY_Page_Down:
		step_by(5);
		return true;
	case XKB_KEY_Home:
		select(0);
		return true;
	case XKB_KEY_End:
		select(static_cast<int>(items_.size()) - 1);
		return true;
	default:
		return true;   // everything else is swallowed while it's open
	}
}

} // namespace arqen
