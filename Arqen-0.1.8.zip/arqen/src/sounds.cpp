#include "sounds.hpp"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>

#include "anim.hpp"
#include "server.hpp"
#include "system.hpp"

namespace arqen {

namespace fs = std::filesystem;

// Freedesktop names first; the bare names after them are the extra sounds
// some themes keep in a folder of their own (Modern Minimal's "cinnamon").
// The window sounds are off unless you turn them on: they'd play all day.
const std::vector<SoundEvent> &sound_events() {
	static const std::vector<SoundEvent> events = {
		{"notification", "A notification arrives", {"message-new-instant", "message", "dialog-information", "notification"}, true},
		{"volume", "Changing the volume", {"audio-volume-change", "volume"}, true},
		{"screenshot", "Taking a screenshot", {"screen-capture", "camera-shutter"}, true},
		{"power-plug", "Charger plugged in", {"power-plug", "plug"}, true},
		{"power-unplug", "Charger unplugged", {"power-unplug", "unplug"}, true},
		{"battery-low", "Battery low", {"battery-low", "battery-caution"}, true},
		{"battery-full", "Battery full", {"battery-full"}, false},
		{"device-added", "A device connects", {"device-added"}, true},
		{"device-removed", "A device disconnects", {"device-removed"}, true},
		{"login", "Logging in", {"desktop-login", "service-login", "login"}, true},
		{"trash", "Emptying the trash", {"trash-empty"}, true},
		{"window-open", "A window opens", {"window-new", "map"}, false},
		{"window-close", "A window closes", {"window-close", "close"}, false},
		{"window-minimize", "Minimising a window", {"window-minimized", "minimize"}, false},
		{"window-maximize", "Maximising a window", {"window-maximized", "maximize"}, false},
		{"window-unmaximize", "Restoring a window", {"window-unmaximized", "unmaximize"}, false},
		{"window-snap", "Snapping a window to a side", {"window-tile", "tile"}, false},
		{"workspace", "Switching workspace", {"desktop-switch-left", "switch"}, false},
	};
	return events;
}

namespace {

// Where sound themes live: yours first, then the system's.
std::vector<std::string> sound_dirs() {
	std::vector<std::string> out;
	const char *data_home = std::getenv("XDG_DATA_HOME");
	const char *home = std::getenv("HOME");
	if (data_home && *data_home) out.push_back(std::string(data_home) + "/sounds");
	else if (home) out.push_back(std::string(home) + "/.local/share/sounds");
	const char *dirs = std::getenv("XDG_DATA_DIRS");
	std::stringstream ss(dirs && *dirs ? dirs : "/usr/local/share:/usr/share");
	std::string d;
	while (std::getline(ss, d, ':')) {
		if (!d.empty()) out.push_back(d + "/sounds");
	}
	return out;
}

std::vector<std::string> split(const std::string &v, char sep) {
	std::vector<std::string> out;
	std::stringstream ss(v);
	std::string part;
	while (std::getline(ss, part, sep)) {
		part.erase(0, part.find_first_not_of(" \t"));
		part.erase(part.find_last_not_of(" \t\r") + 1);
		if (!part.empty()) out.push_back(part);
	}
	return out;
}

// A theme's folders to look in (index.theme's Directories, then any other
// folder in it, then the theme itself) and the themes it inherits.
void theme_layout(const std::string &root, std::vector<std::string> &folders, std::vector<std::string> &inherits) {
	std::ifstream f(root + "/index.theme");
	std::string line;
	bool in_theme = false;
	while (std::getline(f, line)) {
		if (!line.empty() && line[0] == '[') {
			in_theme = line.rfind("[Sound Theme]", 0) == 0;
			continue;
		}
		if (!in_theme) continue;
		const auto eq = line.find('=');
		if (eq == std::string::npos) continue;
		const std::string k = line.substr(0, eq), v = line.substr(eq + 1);
		if (k == "Directories") {
			for (const std::string &d : split(v, ',')) folders.push_back(root + "/" + d);
		} else if (k == "Inherits") {
			inherits = split(v, ',');
		}
	}
	std::error_code ec;
	std::vector<std::string> others;
	for (const auto &e : fs::directory_iterator(root, ec)) {
		if (!e.is_directory(ec)) continue;
		const std::string p = e.path().string();
		if (std::find(folders.begin(), folders.end(), p) == folders.end()) others.push_back(p);
	}
	std::sort(others.begin(), others.end());
	folders.insert(folders.end(), others.begin(), others.end());
	folders.push_back(root);
}

std::string file_in(const std::vector<std::string> &folders, const std::string &name) {
	std::error_code ec;
	for (const std::string &d : folders) {
		for (const char *ext : {".oga", ".ogg", ".wav", ".flac", ".mp3"}) {
			const std::string p = d + "/" + name + ext;
			if (fs::is_regular_file(p, ec)) return p;
		}
	}
	return "";
}

std::string theme_root(const std::string &theme) {
	std::error_code ec;
	for (const std::string &d : sound_dirs()) {
		if (fs::is_directory(d + "/" + theme, ec)) return d + "/" + theme;
	}
	return "";
}

} // namespace

Sounds::Sounds(Server *server) : server_(server), started_(now_ms()) {
	// Logging in: once the desktop is up (the settings are read by then).
	login_timer_ = wl_event_loop_add_timer(server->loop, [](void *data) {
		auto *self = static_cast<Sounds *>(data);
		self->play("login");
		return 0;
	}, this);
	if (login_timer_) wl_event_source_timer_update(login_timer_, 1500);
}

Sounds::~Sounds() {
	if (login_timer_) wl_event_source_remove(login_timer_);
}

void Sounds::config_changed() {
	if (server_->config.sound_theme != theme_) {
		theme_ = server_->config.sound_theme;
		cache_.clear();
	}
}

// A sound by name in the chosen theme, then the themes it inherits, then
// freedesktop's; "message-new-instant" falls back to "message-new" and
// "message", as the freedesktop spec says.
std::string Sounds::find(const std::string &name) {
	config_changed();
	if (auto it = cache_.find(name); it != cache_.end()) return it->second;
	std::vector<std::string> themes = {theme_};
	std::string found;
	std::set<std::string> seen;
	for (size_t i = 0; i < themes.size() && found.empty(); i++) {
		if (!seen.insert(themes[i]).second) continue;
		const std::string root = theme_root(themes[i]);
		if (root.empty()) continue;
		std::vector<std::string> folders, inherits;
		theme_layout(root, folders, inherits);
		for (std::string n = name; !n.empty() && found.empty();) {
			found = file_in(folders, n);
			const auto dash = n.rfind('-');
			n = dash == std::string::npos ? std::string() : n.substr(0, dash);
		}
		for (const std::string &t : inherits) themes.push_back(t);
		if (i == 0) {
			themes.push_back("freedesktop");
			if (theme_ != kDefaultSoundTheme) themes.push_back(kDefaultSoundTheme);
		}
	}
	cache_[name] = found;
	return found;
}

// The file the event plays now ("" = nothing).
std::string Sounds::resolve(const std::string &event) {
	const Config &c = server_->config;
	const SoundEvent *ev = nullptr;
	for (const SoundEvent &e : sound_events()) {
		if (event == e.id) ev = &e;
	}
	if (!ev) return "";
	std::string choice;
	if (auto it = c.sound_choice.find(event); it != c.sound_choice.end()) choice = it->second;
	if (choice.empty()) choice = ev->on ? "on" : "off";
	if (choice == "true" || choice == "yes" || choice == "1") choice = "on";   // (a switch wrote it)
	if (choice == "false" || choice == "no" || choice == "0") choice = "off";
	if (choice == "off") return "";
	if (choice[0] == '/') {
		std::error_code ec;
		return fs::is_regular_file(choice, ec) ? choice : "";
	}
	if (choice != "on") {
		// Another sound from the theme.
		if (std::string f = find(choice); !f.empty()) return f;
	}
	// The theme's own: the first name it has exactly, then with the endings cut off.
	for (const char *n : ev->names) {
		if (std::string f = find(n); !f.empty()) return f;
	}
	return "";
}

void Sounds::run(const std::string &file) {
	if (file.empty()) return;
	char vol[16];
	std::snprintf(vol, sizeof vol, "%.2f", server_->config.sound_volume / 100.0);
	// pw-play (PipeWire), else paplay (its volume is out of 65536).
	const std::string pa = std::to_string(server_->config.sound_volume * 65536 / 100);
	server_->spawn("if command -v pw-play >/dev/null; then pw-play --volume " + std::string(vol) + " " +
		shell_quote(file) + "; else paplay --volume=" + pa + " " + shell_quote(file) + "; fi >/dev/null 2>&1");
}

void Sounds::play(const std::string &event) {
	if (!server_->config.sounds || server_->config.sound_volume <= 0) return;
	// Held keys (volume) and bursts (several windows at once): one sound.
	const uint64_t now = static_cast<uint64_t>(now_ms());
	uint64_t &last = last_[event];
	if (now - last < 90) return;
	last = now;
	run(resolve(event));
}

void Sounds::play_named(const std::string &name_or_file) {
	if (!server_->config.sounds || server_->config.sound_volume <= 0 || name_or_file.empty()) return;
	const uint64_t now = static_cast<uint64_t>(now_ms());
	uint64_t &last = last_["notification"];
	if (now - last < 90) return;
	last = now;
	if (name_or_file[0] == '/') {
		std::error_code ec;
		if (fs::is_regular_file(name_or_file, ec)) run(name_or_file);
		return;
	}
	std::string f = find(name_or_file);
	if (f.empty()) f = resolve("notification");
	run(f);
}

void Sounds::status_changed() {
	const SystemStatus *st = server_->status.get();
	if (!st) return;
	const bool plugged = st->has_battery && st->battery_state != "Discharging" && !st->battery_state.empty();
	const bool full = st->has_battery && st->battery_state == "Full";
	std::set<std::string> devices;
	for (const LinkedDevice &d : st->devices) devices.insert(d.id.empty() ? d.name : d.id);
	for (const LinkedDevice &d : st->phones) devices.insert("kdc:" + (d.id.empty() ? d.name : d.id));
	// (The status fills in bit by bit just after starting: not a charger or a device arriving.)
	if (known_ && now_ms() - started_ > 6000) {
		if (plugged != plugged_ && st->has_battery) play(plugged ? "power-plug" : "power-unplug");
		else if (full && !full_ && plugged) play("battery-full");
		bool added = false, removed = false;
		for (const std::string &d : devices) added = added || !devices_.count(d);
		for (const std::string &d : devices_) removed = removed || !devices.count(d);
		if (added) play("device-added");
		else if (removed) play("device-removed");
	}
	known_ = true;
	plugged_ = plugged;
	full_ = full;
	devices_ = std::move(devices);
}

} // namespace arqen
