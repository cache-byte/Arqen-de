#include "panel.hpp"

#include "mediaview.hpp"
#include "notify.hpp"

#include <algorithm>
#include <cmath>
#include <ctime>
#include <fstream>
#include <linux/input-event-codes.h>

#include "ccentre.hpp"
#include "clipboard.hpp"
#include "draw.hpp"
#include "glyphs.hpp"
#include "launcher.hpp"
#include "osk.hpp"
#include "overview.hpp"
#include "trash.hpp"
#include "popover.hpp"
#include "recorder.hpp"
#include "system.hpp"
#include "tray.hpp"

namespace arqen {

namespace {

// The distribution's logo icon name (LOGO= in os-release), read once.
const std::string &distro_logo() {
	static const std::string name = [] {
		for (const char *file : {"/etc/os-release", "/usr/lib/os-release"}) {
			std::ifstream in(file);
			std::string line;
			while (std::getline(in, line)) {
				if (line.rfind("LOGO=", 0) == 0) {
					std::string v = line.substr(5);
					if (v.size() >= 2 && (v.front() == '"' || v.front() == '\'')) {
						v = v.substr(1, v.size() - 2);
					}
					return v;
				}
			}
		}
		return std::string("distributor-logo");
	}();
	return name;
}

constexpr int kGap = 6;           // between widgets
constexpr int kTaskWidth = 200;   // a window button with its title
constexpr int kStatusIcon = 22;
constexpr int kBellSlot = 12;
constexpr int kBatteryPill = 36;   // the battery pill's width (One UI style)   // the small "notifications waiting" bell

// The recording pill: a red dot and the time ("● 1:07"), while the screen is recorded.
bool recording(Server *server) {
	return server->recorder && (server->recorder->active() || server->recorder->counting_down());
}
std::string rec_text(Server *server) {
	return server->recorder->starting() ? "REC" : server->recorder->elapsed_text();
}
int rec_width(Server *server) {
	return 8 + 8 + 6 + std::max(text_width("0:00", theme::font_bold), text_width(rec_text(server), theme::font_bold)) + 10;
}

// The colour across the colour wheel from c, bright and saturated enough to
// read on the panel (a grey accent has no opposite: then a warm coral).
Color opposite_colour(const Color &c, bool dark) {
	const double mx = std::max({c.r, c.g, c.b}), mn = std::min({c.r, c.g, c.b});
	const double d = mx - mn;
	double h = 0;
	if (d > 1e-6) {
		if (mx == c.r) h = std::fmod((c.g - c.b) / d, 6.0);
		else if (mx == c.g) h = (c.b - c.r) / d + 2;
		else h = (c.r - c.g) / d + 4;
		h *= 60;
		if (h < 0) h += 360;
	}
	const double l0 = (mx + mn) / 2, s0 = d < 1e-6 ? 0 : d / (1 - std::fabs(2 * l0 - 1));
	if (s0 < 0.12) return dark ? rgb(0xff8a65) : rgb(0xe8590c);
	h = std::fmod(h + 180, 360);
	const double s = std::max(0.75, s0), l = dark ? 0.64 : 0.46;
	const double ch = (1 - std::fabs(2 * l - 1)) * s, x = ch * (1 - std::fabs(std::fmod(h / 60, 2) - 1)), m = l - ch / 2;
	double r = 0, g = 0, b = 0;
	if (h < 60) { r = ch; g = x; }
	else if (h < 120) { r = x; g = ch; }
	else if (h < 180) { g = ch; b = x; }
	else if (h < 240) { g = x; b = ch; }
	else if (h < 300) { r = x; b = ch; }
	else { r = ch; b = x; }
	return Color{r + m, g + m, b + m, 1.0};
}
constexpr int kMediaMax = 170;    // the now-playing chip, at most

std::string clock_text(bool h24) {
	std::time_t now = std::time(nullptr);
	std::tm local{};
	localtime_r(&now, &local);
	char buf[16];
	std::strftime(buf, sizeof buf, h24 ? "%H:%M" : "%l:%M %p", &local);
	std::string s = buf;
	if (!s.empty() && s[0] == ' ') {
		s.erase(0, 1);   // "%l" pads single-digit hours
	}
	return s;
}

// "Fri 5": the day and the date, beside the clock.
std::string short_date() {
	std::time_t now = std::time(nullptr);
	std::tm local{};
	localtime_r(&now, &local);
	char buf[32];
	std::strftime(buf, sizeof buf, "%a %e", &local);
	std::string out = buf;
	const size_t dbl = out.find("  ");
	if (dbl != std::string::npos) out.erase(dbl, 1);
	return out;
}

// The clock carries the notifications when it opens them (the default): a
// small count after the date, in the accent while some are new.
bool clock_has_notes(Server *server) {
	return server->config.clock_click == "notifications";
}
int note_count(Server *server) {
	int count = 0;
	if (server->notifications) {
		for (const Notification &n : server->notifications->list()) count += !n.transient;
	}
	return count;
}
std::string clock_badge(Server *server) {
	if (!clock_has_notes(server)) return "";
	const int n = note_count(server);
	return n <= 0 ? "" : n > 99 ? "99+" : std::to_string(n);
}
constexpr int kBadgeH = 18;
int badge_width(const std::string &label) {
	return label.empty() ? 0 : std::max(kBadgeH, text_width(label, theme::font_small) + 10);
}

} // namespace

Panel::Panel(Server *server, Output *output, const PanelConfig &config)
		: server_(server), output_(output), config_(config),
		layer_(server->layer_panel, &tag), fx_(server->anim.get(), [this] { redraw(); }),
		hl_(layer_, server->anim.get()) {
	// The shadow goes under the windows, so tiled windows sit on top of it.
	layer_.put_shadow_in(server->layer_panel_shadow);
	layer_.buffer->point_accepts_input = &Panel::accepts_input;
	hide_timer_ = wl_event_loop_add_timer(server->loop, &Panel::handle_hide_timer, this);
	if (config_.autohide) {
		shown_ = 0.0;
		want_shown_ = false;
	}
}

Panel::~Panel() {
	server_->anim->cancel(anim_);
	wl_event_source_remove(hide_timer_);
}

void Panel::set_config(const PanelConfig &config) {
	const bool was_autohide = config_.autohide;
	config_ = config;
	if (config_.autohide != was_autohide) {
		server_->anim->cancel(anim_);
		anim_ = 0;
		want_shown_ = !config_.autohide;
		shown_ = want_shown_ ? 1.0 : 0.0;
	}
}

int Panel::thickness() const {
	const bool margin = config_.style != "full";
	return config_.size + (margin ? 14 : 0);
}

int Panel::reserved() const {
	return config_.autohide ? 0 : thickness();
}

void Panel::place(int offset, int from, int to) {
	const wlr_box b = output_->box();
	const int t = thickness();
	const std::string &e = config_.edge;
	if (e == "bottom") {
		strip_ = wlr_box{b.x, b.y + b.height - offset - t, b.width, t};
	} else if (e == "top") {
		strip_ = wlr_box{b.x, b.y + offset, b.width, t};
	} else if (e == "left") {
		strip_ = wlr_box{b.x + offset, from, t, std::max(1, to - from)};
	} else {
		strip_ = wlr_box{b.x + b.width - offset - t, from, t, std::max(1, to - from)};
	}
	redraw();
}

bool Panel::accepts_input(wlr_scene_buffer *buffer, double *sx, double *sy) {
	wlr_scene_tree *tree = buffer->node.parent;
	auto *tag = tree ? static_cast<NodeTag *>(tree->node.data) : nullptr;
	if (!tag || tag->kind != NodeTag::Kind::Panel) {
		return true;
	}
	const Panel *p = static_cast<const Panel *>(tag->object);
	const wlr_box &b = p->bar_;
	return p->shown_ > 0.01 && *sx >= b.x && *sy >= b.y && *sx < b.x + b.width &&
		*sy < b.y + b.height;
}

wlr_box Panel::bar_box() const {
	const int slide = static_cast<int>(std::lround((1.0 - shown_) * thickness()));
	wlr_box r{strip_.x + bar_.x, strip_.y + bar_.y, bar_.width, bar_.height};
	const std::string &e = config_.edge;
	if (e == "bottom") r.y += slide;
	else if (e == "top") r.y -= slide;
	else if (e == "left") r.x -= slide;
	else r.x += slide;
	return r;
}

bool Panel::contains(double lx, double ly) const {
	const wlr_box r = bar_box();
	return shown_ > 0.01 && lx >= r.x && ly >= r.y && lx < r.x + r.width && ly < r.y + r.height;
}

bool Panel::task_box(const View *view, wlr_box *out) const {
	const wlr_box bar = bar_box();
	for (const Slot &s : slots_) {
		if (s.kind == "tasks" && s.view == view) {
			*out = wlr_box{bar.x - bar_.x + s.box.x, bar.y - bar_.y + s.box.y, s.box.width,
				s.box.height};
			return shown_ > 0.5;
		}
	}
	return false;
}

std::string Panel::media_label() const {
	const SystemStatus *st = server_->status.get();
	if (!st || !st->media_available) {
		return "";
	}
	return st->media_title.empty() ? "Playing" : st->media_title;
}

wlr_box Panel::anchor(const std::string &widget) const {
	const wlr_box bar = bar_box();
	for (const Slot &s : slots_) {
		if (s.kind == widget) {
			return wlr_box{bar.x - bar_.x + s.box.x, bar.y - bar_.y + s.box.y, s.box.width,
				s.box.height};
		}
	}
	return bar;
}

std::vector<std::string> Panel::status_icons() const {
	std::vector<std::string> icons;
	const SystemStatus *st = server_->status.get();
	if (!st) {
		return icons;
	}
	// Quiet now: Do not disturb, or a recording under way (Arqen quiets
	// itself so nothing pops into the picture).
	const bool quiet_now = server_->config.dnd || (server_->recorder && server_->recorder->active());
	if (recording(server_)) {
		icons.push_back("rec");
	}
	// Notifications waiting: a small bell just before the network icon.
	// (Not when this panel has the bell of a separate notification centre: it has the count.)
	auto has = [this](const char *w) {
		return std::find(config_.widgets.begin(), config_.widgets.end(), w) != config_.widgets.end();
	};
	const bool bell_here = server_->config.separate_notes() &&
		(has("notifications") || (has("clock") && clock_has_notes(server_)));
	if (server_->notifications && server_->notifications->unseen > 0 && !quiet_now && !bell_here) {
		icons.push_back("unseen:bell");
	}
	if (st->airplane) {
		icons.push_back("airplane");
	} else if (st->net_kind == "ethernet") {
		icons.push_back("wired");
	} else if (st->net_kind == "wifi") {
		icons.push_back(wifi_icon(st->wifi_signal));
	} else if (st->wifi_available) {
		icons.push_back("offline");
	}
	if (st->bt_powered && !st->bt_device.empty()) {
		icons.push_back("bluetooth");
	}
	// Privacy first: an app using the camera or recording from the microphone
	// (shown in amber, like on a phone).
	if (st->camera_in_use) {
		icons.push_back("privacy:camera");
	}
	if (st->mic_in_use) {
		icons.push_back("privacy:mic");
	}
	if (quiet_now) {
		icons.push_back("bell-off");
	}
	if (st->has_audio) {
		icons.push_back(speaker_icon(st->volume, st->muted));
	}
	if (st->has_battery) {
		icons.push_back(battery_icon(st->battery, st->charging));
	}
	if (icons.empty()) {
		icons.push_back("gear");   // still something to click for the control centre
	}
	return icons;
}

const AppInfo *Panel::pin_app(int index) const {
	if (index < 0 || index >= static_cast<int>(config_.pins.size())) {
		return nullptr;
	}
	const std::string &id = config_.pins[static_cast<size_t>(index)];
	for (const AppInfo &a : server_->apps.apps()) {
		if (a.id == id || a.id == id + ".desktop") {
			return &a;
		}
	}
	return nullptr;
}

View *Panel::pin_window(int index) const {
	const AppInfo *app = pin_app(index);
	if (!app) {
		return nullptr;
	}
	for (View *v : server_->views) {
		if (v->mapped && !app->icon.empty() && server_->apps.icon_for(v->app_id(), v->title()) == app->icon) {
			return v;
		}
	}
	return nullptr;
}

// Works out the bar and where each widget goes. Everything is computed
// along the panel ("main" axis) and across it, then turned into boxes.
//
// Flexible spaces split the widgets into groups: the first group sits at
// the start of the bar and the last at the end. With two flexible spaces the
// group between them is centred on the bar (so "spacer, clock, spacer" puts
// the clock in the middle of the screen, whatever is on either side), as far
// as the groups beside it allow. With more, the spaces share the room
// equally.
void Panel::layout() {
	const bool vertical = config_.vertical();
	const int t = thickness();
	const int size = config_.size;
	const bool margin = config_.style != "full";
	const bool dock = config_.style == "dock";
	const int m = margin ? 8 : 0;
	const int strip_len = vertical ? strip_.height : strip_.width;
	const int avail = std::max(0, strip_len - 2 * m);
	const int pad = 5;
	const int c = size - 2 * pad;   // square items

	// Windows to show (oldest first, like a taskbar).
	std::vector<View *> windows;
	const Config &cfg = server_->config;
	for (View *v : server_->views) {
		// This workspace's windows (or every workspace's: Settings > Workspaces).
		if (v->mapped && (cfg.tasks_all_workspaces || v->sticky || v->workspace == server_->workspace)) {
			windows.push_back(v);
		}
	}
	std::sort(windows.begin(), windows.end(), [](View *a, View *b) { return a->id < b->id; });

	// The apps on the panel, like a dock: the pinned ones first, in their
	// order (lit with a dot while open, each with its windows), then the
	// other open windows. A pinned app that isn't open is a launcher.
	struct Entry {
		int pin = -1;
		View *view = nullptr;
	};
	std::vector<Entry> entries;
	{
		std::vector<bool> used(windows.size(), false);
		for (int i = 0; i < static_cast<int>(config_.pins.size()); i++) {
			const AppInfo *app = pin_app(i);
			bool any = false;
			for (size_t k = 0; k < windows.size(); k++) {
				if (used[k] || !app || app->icon.empty() || server_->apps.icon_for(windows[k]->app_id(), windows[k]->title()) != app->icon) continue;
				used[k] = true;
				entries.push_back(Entry{any ? -1 : i, windows[k]});
				any = true;
			}
			if (!any && app) entries.push_back(Entry{i, nullptr});
		}
		for (size_t k = 0; k < windows.size(); k++) {
			if (!used[k]) entries.push_back(Entry{-1, windows[k]});
		}
	}

	const bool labels = false;   // (apps are round bubbles: no titles beside them)
	const int n_icons = static_cast<int>(status_icons().size());

	// Length of each widget along the bar; tasks stretch (worked out below).
	struct Part {
		std::string kind;
		int length;
		int widget;
	};
	std::vector<Part> parts;
	bool has_tasks = false;
	for (size_t wi = 0; wi < config_.widgets.size(); wi++) {
		const std::string &w = config_.widgets[wi];
		int len = 0;
		if (w == "menu" || w == "search" || w == "clipboard" || w == "trash" || w == "keyboard" || w == "overview") {
			len = c;
		} else if (w == "pins") {
			const int n = static_cast<int>(config_.pins.size());
			len = n > 0 ? n * c + (n - 1) * 4 : 0;
		} else if (w == "tray") {
			const int n = server_->tray ? static_cast<int>(server_->tray->items().size()) : 0;
			const int tc = std::min(c, 30);
			len = n > 0 ? n * tc + (n - 1) * 2 : 0;
		} else if (w == "tasks") {
			has_tasks = true;
		} else if (w == "spacer") {
			len = 0;
		} else if (w == "separator") {
			len = 13;
		} else if (w == "clock") {
			if (vertical) {
				len = cfg.show_date ? 70 : 40;   // the time, then the day and date (like a horizontal panel)
				if (!clock_badge(server_).empty()) len += kBadgeH + 6;   // the notification count under it
			} else {
				// "12:00  Fri 5": the time in bold, the day beside it.
				len = text_width(clock_text(cfg.clock_24h), theme::font_clock) + 16 + 12;   // + the accent dot
				if (cfg.show_date) len += 10 + text_width(short_date(), theme::font_clock_date);
				if (const std::string badge = clock_badge(server_); !badge.empty()) len += 8 + badge_width(badge);
			}
		} else if (w == "status") {
			len = n_icons * kStatusIcon + 24;
			if (recording(server_) && !vertical) {
				len += rec_width(server_) - kStatusIcon;
			}
			const std::vector<std::string> shown = status_icons();
			if (std::find(shown.begin(), shown.end(), "unseen:bell") != shown.end()) {
				len -= kStatusIcon - kBellSlot;   // the bell takes less room
			}
			if (vertical && server_->status && server_->status->has_battery && cfg.battery_style != "icon") {
				len += 14;   // the percentage under the battery
			}
			if (!vertical && server_->status && server_->status->has_battery) {
				if (cfg.battery_style == "percent") {
					len += kBatteryPill + 4 - kStatusIcon;   // the pill in place of the icon
				} else if (cfg.battery_style == "ring") {
					len += 40 - kStatusIcon;   // the ring is wider than an icon
				}
			}
		} else if (w == "media") {
			// Grows in when something starts playing, shrinks away after.
			const std::string label = media_label();
			int want = 0;
			if (!label.empty()) {
				want = vertical ? c : std::min(kMediaMax, text_width(label, theme::font_small) + 46);
			}
			if (!drawing_) {
				fx_.set("len:media", want, want);
			}
			len = static_cast<int>(std::lround(fx_.get("len:media", want)));
		} else if (w == "showdesktop") {
			len = c;   // a button like the others (it was a thin line)
		} else if (w == "notifications") {
			// A flat badge: how many notifications (a bell when none).
			len = c;
		}
		parts.push_back(Part{w, len, static_cast<int>(wi)});
	}

	// Groups between flexible spaces (a dock has no flexible spaces).
	std::vector<std::vector<size_t>> groups(1);
	for (size_t i = 0; i < parts.size(); i++) {
		if (parts[i].kind == "spacer") {
			if (!dock) groups.emplace_back();
		} else {
			groups.back().push_back(i);
		}
	}
	const int spacers = static_cast<int>(groups.size()) - 1;
	auto group_len = [&](const std::vector<size_t> &g) {
		int len = 0, shown = 0;
		for (size_t i : g) {
			len += parts[i].length;
			shown++;
		}
		return len + std::max(0, shown - 1) * kGap;
	};
	// (A see-through panel keeps its icons off the screen's edges.)
	const int ends = vertical ? pad + 2 : margin ? size / 4 : config_.opacity <= 0.02 ? 16 : 6;
	int used = 2 * ends + spacers * kGap;   // a flexible space is at least one gap wide
	for (const auto &g : groups) {
		used += group_len(g);
	}

	// Window buttons take what they need (up to the room left); with no
	// flexible space they fill the bar.
	int n_windows = 0, n_launchers = 0;
	for (const Entry &en : entries) (en.view ? n_windows : n_launchers)++;
	const int task_ideal = n_windows * (labels ? kTaskWidth : c + 4) + n_launchers * (c + 4);
	const int rest = std::max(0, avail - used);
	if (has_tasks) {
		const int task_len = (spacers == 0 && !dock) ? rest : std::min(task_ideal, rest);
		for (Part &p : parts) {
			if (p.kind == "tasks") p.length = task_len;
		}
	}
	int content = 2 * ends + spacers * kGap;
	for (const auto &g : groups) {
		content += group_len(g);
	}

	// The bar.
	const int bar_len = dock ? std::min(avail, std::max(content, size)) : (margin ? avail : strip_len);
	const int bar_start = dock ? (strip_len - bar_len) / 2 : m;
	const std::string &e = config_.edge;
	const int cross = (e == "bottom" || e == "right") ? t - m - size : m;
	bar_ = vertical ? wlr_box{cross, bar_start, size, bar_len} : wlr_box{bar_start, cross, bar_len, size};

	// Where each group starts along the bar.
	std::vector<int> starts(groups.size(), ends);
	if (spacers >= 1) {
		const int last = static_cast<int>(groups.size()) - 1;
		starts[last] = bar_len - ends - group_len(groups[last]);
		if (spacers == 2) {
			// The middle group, centred on the bar if the others leave room.
			const int len = group_len(groups[1]);
			const int lo = starts[0] + group_len(groups[0]) + kGap;
			const int hi = starts[last] - kGap - len;
			starts[1] = std::max(lo, std::min((bar_len - len) / 2, hi));
		} else if (spacers > 2) {
			int free = bar_len - 2 * ends;
			for (const auto &g : groups) free -= group_len(g);
			const double share = std::max(0, free) / static_cast<double>(spacers);
			double pos = ends;
			for (size_t gi = 0; gi + 1 < groups.size(); gi++) {
				starts[gi] = static_cast<int>(std::lround(pos));
				pos += group_len(groups[gi]) + share;
			}
		}
	}

	// The widgets.
	slots_.clear();
	auto make_box = [&](int main_pos, int main_len, int cross_pos, int cross_len) {
		return vertical ? wlr_box{bar_.x + cross_pos, bar_.y + main_pos, cross_len, main_len}
			: wlr_box{bar_.x + main_pos, bar_.y + cross_pos, main_len, cross_len};
	};
	size_t spacer_index = 0;
	int prev_end = 0;   // where the last group ended (for the flexible space after it)
	for (size_t gi = 0; gi < groups.size(); gi++) {
		int pos = starts[gi];
		if (gi > 0) {
			// The flexible space before this group: empty bar, but it knows
			// which widget it is (for its right-click menu).
			while (spacer_index < parts.size() && parts[spacer_index].kind != "spacer") spacer_index++;
			if (spacer_index < parts.size() && pos - prev_end > 0) {
				Slot s;
				s.kind = "spacer";
				s.widget = parts[spacer_index].widget;
				s.key = "spacer" + std::to_string(s.widget);
				s.box = make_box(prev_end, pos - prev_end, 0, size);
				slots_.push_back(s);
			}
			spacer_index++;
		}
		for (size_t pi : groups[gi]) {
			const Part &p = parts[pi];
			if (p.kind == "tasks") {
				const int win_room = std::max(0, p.length - n_launchers * (c + 4));
				int item = labels ? std::min(kTaskWidth, n_windows > 0 ? win_room / n_windows : kTaskWidth) : c + 4;
				bool icon_only = !labels || item < c + 40;
				if (icon_only) {
					item = c + 4;
				}
				int at_pos = pos;
				for (const Entry &en : entries) {
					const int len = en.view ? item : c + 4;
					if (at_pos + len > pos + p.length) break;   // no more room
					Slot s;
					s.widget = p.widget;
					s.pin = en.pin;
					if (en.view) {
						s.kind = "tasks";
						s.view = en.view;
						s.icon_only = icon_only;
						s.key = "task" + std::to_string(s.view->id);
					} else {
						s.kind = "pins";
						s.key = "pin" + std::to_string(en.pin);
					}
					// Buttons glide to their new place when others come or go.
					const double target = at_pos;
					fx_.set("pos:" + s.key, target, target);
					const int at = static_cast<int>(std::lround(fx_.get("pos:" + s.key, target)));
					s.box = make_box(at, (en.view ? item : c + 4) - 4, pad, c);
					slots_.push_back(s);
					at_pos += len;
				}
			} else if (p.kind == "tray" && server_->tray) {
				const int tc = std::min(c, 30);
				int i = 0;
				for (const TrayItem *item : server_->tray->items()) {
					Slot s;
					s.kind = "tray";
					s.widget = p.widget;
					s.tray = item->key;
					s.key = "tray:" + item->key;
					s.box = make_box(pos + i * (tc + 2), tc, (size - tc) / 2, tc);
					slots_.push_back(s);
					i++;
				}
			} else if (p.kind == "pins") {
				for (int i = 0; i < static_cast<int>(config_.pins.size()); i++) {
					Slot s;
					s.kind = "pins";
					s.widget = p.widget;
					s.pin = i;
					s.key = "pin" + std::to_string(i);
					s.box = make_box(pos + i * (c + 4), c, pad, c);
					slots_.push_back(s);
				}
			} else if (p.length > 0) {
				Slot s;
				s.kind = p.kind;
				s.widget = p.widget;
				s.key = p.kind + std::to_string(p.widget);
				const int inset = p.kind == "separator" ? 0 : pad;
				s.box = make_box(pos, p.length, inset, size - 2 * inset);
				slots_.push_back(s);
			}
			pos += p.length + kGap;
		}
		prev_end = groups[gi].empty() ? pos : pos - kGap;
	}
}

void Panel::redraw() {
	if (strip_.width <= 0 || strip_.height <= 0 || drawing_) {
		return;
	}
	layout();
	drawing_ = true;
	const float scale = output_->output->scale;
	Canvas canvas(strip_.width, strip_.height, scale);
	cairo_t *cr = canvas.cr();

	// A full-width panel with no background and no blur is just its icons
	// over the wallpaper (0% background with blur on leaves only the blur,
	// as Settings says).
	const bool bare = config_.style == "full" && config_.opacity <= 0.02 && server_->config.panel_blur <= 0.001;
	const Color bg = with_alpha(theme::panel_bg, config_.opacity);
	layer_.set_body_opacity(config_.opacity);
	layer_.set_blur(bare ? 0.0 : server_->config.panel_blur);
	const wlr_box &b = bar_;
	double radius = 0;
	if (config_.style == "full") {
		if (!bare) {
			set_color(cr, bg);
			cairo_paint(cr);
		}
	} else {
		radius = std::min(b.width, b.height) / 2.0;
		ui_card(cr, b.x, b.y, b.width, b.height, radius, bg);
	}

	// (Hover is a GPU highlight on top: see update_highlight.)
	for (const Slot &slot : slots_) {
		draw_slot(cr, slot, 0.0, scale);
	}
	layer_.present(canvas, b, radius);
	drawing_ = false;
	update_highlight();   // things may have moved

	// Slide in/out for auto-hide.
	const wlr_box bar = bar_box();
	layer_.show(bar.x - bar_.x, bar.y - bar_.y, std::clamp(0.3 + 0.7 * shown_, 0.0, 1.0));
	layer_.set_enabled(shown_ > 0.001 && !covered());
}

// A full-screen window on this screen's desktop (shown, not minimised): the
// panel is gone altogether (not just under it), until it leaves full screen,
// is minimised, or another desktop is shown. The overview still has it.
bool Panel::covered() const {
	if (server_->overview && server_->overview->is_open()) return false;
	for (View *v : server_->views) {
		if (v->fullscreen && v->mapped && v->visible() && server_->output_for_view(v) == output_) return true;
	}
	return false;
}

void Panel::draw_battery_pill(cairo_t *cr, double x, double y, double w, double h) {
	// One UI 7's battery: a pill that fills up from the left, the number on
	// it (dark where it's over the fill), a bolt while charging. Its colour
	// tells the level, as the old coloured number did: green while charging,
	// the text colour from 50%, amber from 20%, red under that; and a soft
	// glow in that colour when it isn't the plain one.
	const SystemStatus &st = *server_->status;
	const int level = std::clamp(st.battery, 0, 100);
	const bool low = level < 20 && !st.charging;
	const bool plain = !st.charging && level >= 50;
	const Color fillc = st.charging ? theme::success : level >= 50 ? theme::text
		: level >= 20 ? theme::warning : theme::danger;
	const double r = chip_radius(h);
	if (!plain) {
		for (int i = 3; i >= 1; i--) {
			const double g = i * 1.6;
			rounded_rect(cr, x - g, y - g, w + 2 * g, h + 2 * g, r + g);
			set_color(cr, with_alpha(fillc, 0.07 * (4 - i)));
			cairo_fill(cr);
		}
	}
	cairo_save(cr);
	rounded_rect(cr, x, y, w, h, r);
	cairo_clip(cr);
	set_color(cr, with_alpha(theme::text, theme::dark ? 0.22 : 0.18));
	cairo_paint(cr);
	const double fw = std::max(low ? 4.0 : 0.0, w * level / 100.0);
	cairo_rectangle(cr, x, y, fw, h);
	set_color(cr, fillc);
	cairo_fill(cr);
	// The number (and bolt), in the text colour off the fill and in a colour
	// that reads on the fill over it.
	static std::string font;
	{
		std::string f = theme::font_small;
		const auto sp = f.rfind(' ');
		f = sp == std::string::npos ? "Sans Bold 9" : f.substr(0, sp) + " Bold" + f.substr(sp);
		font = f;
	}
	const std::string num = std::to_string(level);
	const int tw = text_width(num, font.c_str());
	const double bolt = st.charging ? 8 : 0;
	const double tx = x + (w - tw - bolt) / 2.0 + bolt;
	const double lum = 0.299 * fillc.r + 0.587 * fillc.g + 0.114 * fillc.b;
	const Color on_fill = lum > 0.55 ? rgb(0x161618) : rgb(0xffffff);
	for (int pass = 0; pass < 2; pass++) {
		cairo_save(cr);
		if (pass == 0) cairo_rectangle(cr, x + fw, y, w - fw, h);
		else cairo_rectangle(cr, x, y, fw, h);
		cairo_clip(cr);
		const Color c = pass == 0 ? (plain ? theme::text : fillc) : on_fill;
		if (st.charging) {
			const double bx = tx - 9, by = y + h / 2.0;
			cairo_move_to(cr, bx + 4.6, by - 5);
			cairo_line_to(cr, bx + 1, by + 0.8);
			cairo_line_to(cr, bx + 3.6, by + 0.8);
			cairo_line_to(cr, bx + 3, by + 5);
			cairo_line_to(cr, bx + 6.6, by - 0.8);
			cairo_line_to(cr, bx + 4, by - 0.8);
			cairo_close_path(cr);
			set_color(cr, c);
			cairo_fill(cr);
		}
		draw_text(cr, num, tx, y, tw + 2, h, font.c_str(), c);
		cairo_restore(cr);
	}
	cairo_restore(cr);
}

void Panel::draw_battery_ring(cairo_t *cr, double x, double y, double w, double h) {
	// A pill whose outline fills up like a progress ring, with the number
	// inside.
	const SystemStatus &st = *server_->status;
	const double r = h / 2.0, lw = 2.2;
	const Color low = theme::danger;
	const Color fillc = st.battery <= 15 && !st.charging ? low
		: st.charging ? theme::success : theme::text;
	rounded_rect(cr, x + lw / 2, y + lw / 2, w - lw, h - lw, r - lw / 2);
	set_color(cr, with_alpha(theme::text, 0.18));
	cairo_set_line_width(cr, lw);
	cairo_stroke(cr);
	// Progress along the outline, starting at the top middle, clockwise.
	cairo_save(cr);
	rounded_rect(cr, x + lw / 2, y + lw / 2, w - lw, h - lw, r - lw / 2);
	cairo_path_t *path = cairo_copy_path_flat(cr);
	cairo_new_path(cr);
	double total = 0;
	for (int pass = 0; pass < 2; pass++) {
		double walked = 0, px = 0, py = 0, sx = 0, sy = 0;
		bool have = false;
		const double limit = total * std::clamp(st.battery, 0, 100) / 100.0;
		for (int i = 0; i < path->num_data; i += path->data[i].header.length) {
			const cairo_path_data_t *d = &path->data[i];
			if (d->header.type == CAIRO_PATH_MOVE_TO) {
				px = sx = d[1].point.x;
				py = sy = d[1].point.y;
				if (pass == 1) cairo_move_to(cr, px, py);
				have = true;
				continue;
			}
			double nx, ny;
			if (d->header.type == CAIRO_PATH_LINE_TO) {
				nx = d[1].point.x;
				ny = d[1].point.y;
			} else if (d->header.type == CAIRO_PATH_CLOSE_PATH) {
				nx = sx;
				ny = sy;
			} else {
				continue;
			}
			const double seg = std::hypot(nx - px, ny - py);
			if (pass == 1 && have) {
				if (walked + seg >= limit) {
					const double t = seg > 0 ? (limit - walked) / seg : 0;
					cairo_line_to(cr, px + (nx - px) * t, py + (ny - py) * t);
					break;
				}
				cairo_line_to(cr, nx, ny);
			}
			walked += seg;
			px = nx;
			py = ny;
		}
		total = walked;
	}
	cairo_path_destroy(path);
	set_color(cr, fillc);
	cairo_set_line_width(cr, lw);
	cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
	cairo_stroke(cr);
	cairo_restore(cr);
	draw_text(cr, std::to_string(st.battery), x, y, w, h, theme::font_small, theme::text,
		Align::Center);
}

void Panel::draw_slot(cairo_t *cr, const Slot &s, double hover, float scale) {
	const wlr_box &b = s.box;
	const bool vertical = config_.vertical();
	const Config &cfg = server_->config;
	const std::string &e = config_.edge;
	const double r = corner(b);
	const double cx = b.x + b.width / 2.0, cy = b.y + b.height / 2.0;
	const double disc = std::min(b.width, b.height) / 2.0 - 1;   // a round button's radius
	// Lit while what it opens is open (fading in and out).
	auto lit = [&](const std::string &key, bool open) {
		fx_.set("open:" + key, open ? 1.0 : 0.0);
		return fx_.get("open:" + key);
	};
	auto plain_icon = [&](const std::string &name, double size = 20) {
		draw_named_icon(cr, server_->icons, name, cx - size / 2, cy - size / 2, size, theme::text, scale);
	};

	if (s.kind == "menu") {
		// The app menu: a disc in the accent gradient with Arqen's arch on it.
		const bool open = server_->launcher && server_->launcher->is_open_on(output_);
		const double dim = 0.12 * std::max(hover, lit("menu", open));
		const std::string &look = server_->config.menu_icon;
		rounded_rect(cr, cx - disc, cy - disc, 2 * disc, 2 * disc, chip_radius(2 * disc));
		accent_gradient(cr, cx - disc, cy - disc, 2 * disc, 2 * disc, dim);
		cairo_fill(cr);
		if (look == "distro" || look == "custom") {
			const std::string name = look == "distro" ? distro_logo() : server_->config.menu_icon_custom;
			const double size = std::round(disc * 1.2);
			draw_icon(cr, server_->icons, name.empty() ? "distributor-logo" : name, "Apps",
				cx - size / 2, cy - size / 2, size, output_->output->scale);
		} else if (look == "dots") {
			// A 3×3 grid of dots.
			const double step = disc * 0.42, dot = std::max(1.6, disc * 0.11);
			set_color(cr, theme::on_gradient);
			for (int i = -1; i <= 1; i++) {
				for (int j = -1; j <= 1; j++) {
					cairo_new_sub_path(cr);
					cairo_arc(cr, cx + i * step, cy + j * step, dot, 0, 2 * M_PI);
				}
			}
			cairo_fill(cr);
		} else if (look == "squares") {
			// Four rounded squares.
			const double sq = disc * 0.48, gap = disc * 0.14;
			set_color(cr, theme::on_gradient);
			for (int i = 0; i < 2; i++) {
				for (int j = 0; j < 2; j++) {
					rounded_rect(cr, cx - gap / 2 - sq + i * (sq + gap), cy - gap / 2 - sq + j * (sq + gap),
						sq, sq, sq * 0.3);
					cairo_fill(cr);
				}
			}
		} else if (look == "search") {
			const double size = std::round(disc * 1.1);
			draw_named_icon(cr, server_->icons, "search", cx - size / 2, cy - size / 2, size,
				theme::on_gradient, scale);
		} else {
			draw_arqen_logo(cr, cx, cy, disc * 1.1, theme::on_gradient);
		}
		return;
	}

	if (s.kind == "spacer") {
		return;   // empty bar
	}

	if (s.kind == "search") {
		plain_icon("search");
		return;
	}

	if (s.kind == "overview") {
		const bool open = server_->overview && server_->overview->is_open();
		if (const double o = lit("overview", open); o > 0.01) {
			glass_disc(cr, cx, cy, disc, with_alpha(theme::glass, theme::glass.a * o));
		}
		// Two windows, one over the other.
		const double w = 13, h = 10, lw = 1.8;
		cairo_set_line_width(cr, lw);
		set_color(cr, theme::text);
		rounded_rect(cr, cx - w / 2 - 2, cy - h / 2 + 2.5, w, h, 2.5);
		cairo_stroke(cr);
		cairo_save(cr);
		rounded_rect(cr, cx - w / 2 + 2, cy - h / 2 - 1.5, w, h, 2.5);
		set_color(cr, theme::text);
		cairo_stroke_preserve(cr);
		cairo_restore(cr);
		cairo_new_path(cr);
		return;
	}

	if (s.kind == "tray") {
		if (server_->tray) {
			for (const TrayItem *item : server_->tray->items()) {
				if (item->key != s.tray) continue;
				const double icon = std::min(18.0, std::min(b.width, b.height) - 8.0);
				server_->tray->draw_icon(cr, *item, cx - icon / 2.0, cy - icon / 2.0, icon, scale);
			}
		}
		return;
	}

	if (s.kind == "trash") {
		plain_icon("trash", 18);
		if (server_->trash && !server_->trash->is_empty()) {
			cairo_new_path(cr);
			cairo_arc(cr, cx + 9, cy - 8, 3.2, 0, 2 * M_PI);
			set_color(cr, theme::accent);
			cairo_fill(cr);
		}
		return;
	}

	if (s.kind == "clipboard") {
		const bool open = server_->clipboard_card && server_->clipboard_card->is_open_on(output_);
		if (const double o = lit(s.key, open); o > 0.01) {
			glass_disc(cr, cx, cy, disc, with_alpha(theme::glass, theme::glass.a * o));
		}
		plain_icon("clipboard", 18);
		return;
	}

	// An app: its icon on its own; a short accent bar under the one in
	// front, a dot under the others that are open.
	auto app_bubble = [&](const std::string &icon_name, const std::string &title, bool open, bool front,
			double fade) {
		// Just the icon, no chip behind it (hover is the GPU highlight; the
		// one in front is marked by the accent bar underneath).
		const double rad = disc - 2;
		const double icon = std::round(rad * 1.3);
		cairo_push_group(cr);
		draw_icon(cr, server_->icons, icon_name, title, cx - icon / 2.0, cy - 1 - icon / 2.0, icon, scale);
		cairo_pop_group_to_source(cr);
		cairo_paint_with_alpha(cr, fade);
		if (!open) return;
		const double len = front ? 12 : 4, th = 3;
		double ix, iy, iw, ih;
		if (vertical) {
			iw = th;
			ih = len;
			ix = e == "left" ? b.x : b.x + b.width - th;
			iy = cy - len / 2;
		} else {
			iw = len;
			ih = th;
			ix = cx - len / 2;
			iy = e == "top" ? b.y - 2 : b.y + b.height - th + 2;
		}
		fill_rounded(cr, ix, iy, iw, ih, th / 2, front ? theme::accent : theme::text_dim);
	};

	if (s.kind == "tasks" && s.view) {
		View *view = s.view;
		const bool front = view->active() && !view->minimized;
		const double act = lit("active:" + s.key, front);
		if (view->urgent && act < 0.5) {
			glass_disc(cr, cx, cy - 1, disc, with_alpha(theme::accent, 0.45));
		}
		// Minimised, or on another workspace: a little faded.
		const bool elsewhere = !view->sticky && view->workspace != server_->workspace;
		const std::string title = view->title();
		app_bubble(server_->apps.icon_for(view->app_id(), title), title, true, act > 0.5,
			view->minimized ? 0.45 : elsewhere ? 0.7 : 1.0);
		return;
	}

	if (s.kind == "pins") {
		const AppInfo *app = pin_app(s.pin);
		View *v = pin_window(s.pin);
		app_bubble(app ? app->icon : "", app ? app->name : "?", v != nullptr, v && v->active(), 1.0);
		return;
	}

	if (s.kind == "separator") {
		if (vertical) {
			cairo_rectangle(cr, b.x + 10, cy, b.width - 20, 1);
		} else {
			cairo_rectangle(cr, cx, b.y + 10, 1, b.height - 20);
		}
		set_color(cr, theme::divider);
		cairo_fill(cr);
		return;
	}

	if (s.kind == "keyboard") {
		if (server_->osk && server_->osk->is_open_on(output_)) {
			glass_disc(cr, cx, cy, disc, theme::glass);
		}
		plain_icon("keyboard", 18);
		return;
	}

	if (s.kind == "notifications") {
		// A flat badge with how many there are (in the accent while some
		// are new); a bell when there are none, crossed out in Do not disturb.
		const bool open = server_->control_centre && server_->control_centre->notes_open_on(output_);
		const double o = lit("notes", open);
		int count = 0;
		if (server_->notifications) {
			for (const Notification &n : server_->notifications->list()) count += !n.transient;
		}
		const double rad = disc - 6;
		if (count > 0 && !server_->config.dnd) {
			const bool unseen = server_->notifications->unseen > 0;
			if (unseen) {
				rounded_rect(cr, cx - rad, cy - rad, 2 * rad, 2 * rad, chip_radius(2 * rad));
				accent_gradient(cr, cx - rad, cy - rad, 2 * rad, 2 * rad, 0.12 * o);
				cairo_fill(cr);
			} else {
				glass_disc(cr, cx, cy, rad, with_alpha(theme::accent, theme::dark ? 0.35 : 0.25));
			}
			const std::string label = count > 9 ? "9+" : std::to_string(count);
			draw_text(cr, label, cx - rad, cy - rad, 2 * rad, 2 * rad, theme::font_clock,
				unseen ? theme::on_gradient : theme::text, Align::Center);
		} else {
			if (o > 0.01) glass_disc(cr, cx, cy, rad, with_alpha(theme::glass, theme::glass.a * o));
			plain_icon(server_->config.dnd ? "bell-off" : "bell", 18);
		}
		return;
	}

	if (s.kind == "showdesktop") {
		if (!server_->shown_desktop.empty()) {
			glass_disc(cr, cx, cy, disc, theme::glass);
		}
		plain_icon("desktop", 18);
		return;
	}

	if (s.kind == "clock") {
		const std::string time = clock_text(cfg.clock_24h);
		// Lit while the notifications (or the calendar) it opens are up.
		const bool open = server_->control_centre && server_->control_centre->notes_open_on(output_);
		if (const double o = lit("clock", open); o > 0.01) {
			const double ch = vertical ? b.height : std::min<double>(b.height - 12, 34);
			const double cw = vertical ? std::min<double>(b.width - 12, 40) : b.width;
			fill_rounded(cr, cx - cw / 2, cy - ch / 2, cw, ch, chip_radius(std::min(cw, ch)),
				with_alpha(theme::accent, (theme::dark ? 0.32 : 0.22) * o));
		}
		// The notification count: a small flat badge.
		const std::string badge = clock_badge(server_);
		auto draw_badge = [&](double bx, double by) {
			const int bw = badge_width(badge);
			const bool fresh = server_->notifications && server_->notifications->unseen > 0 &&
				!cfg.dnd && !(server_->recorder && server_->recorder->active());
			if (fresh) {
				rounded_rect(cr, bx, by, bw, kBadgeH, chip_radius(kBadgeH) * 0.8);
				accent_gradient(cr, bx, by, bw, kBadgeH);
				cairo_fill(cr);
			} else {
				fill_rounded(cr, bx, by, bw, kBadgeH, chip_radius(kBadgeH) * 0.8, with_alpha(theme::text, 0.14));
			}
			draw_text(cr, badge, bx, by, bw, kBadgeH, theme::font_small, fresh ? theme::on_gradient : theme::text,
				Align::Center);
		};
		if (vertical) {
			// "21" over "34", then the day and date.
			const auto colon = time.find(':');
			const std::string hours = time.substr(0, colon);
			std::string minutes = colon == std::string::npos ? "" : time.substr(colon + 1, 2);
			const double mid = b.y + (cfg.show_date ? b.height / 2.0 - 13 : b.height / 2.0);
			draw_text(cr, hours, b.x, mid - 18, b.width, 20, theme::font_clock, theme::text_dim, Align::Center);
			draw_text(cr, minutes, b.x, mid, b.width, 20, theme::font_clock, theme::text, Align::Center);
			if (cfg.show_date) {
				std::time_t now = std::time(nullptr);
				std::tm local{};
				localtime_r(&now, &local);
				char day[16], date[16];
				std::strftime(day, sizeof day, "%a", &local);
				std::strftime(date, sizeof date, "%d %b", &local);
				draw_text(cr, day, b.x, mid + 19, b.width, 13, theme::font_small, theme::text_dim, Align::Center);
				draw_text(cr, date, b.x, mid + 32, b.width, 13, theme::font_small, theme::text_dim, Align::Center);
			}
			if (!badge.empty()) draw_badge(cx - badge_width(badge) / 2.0, b.y + b.height - kBadgeH - 2);
			return;
		}
		// The Soft clock: monospaced, the hours quieter than the minutes, and
		// a small accent dot after it.
		const int tw = text_width(time, theme::font_clock) + 12;
		const double x0 = b.x + 8;
		{
			const auto colon = time.find(':');
			const std::string head = colon == std::string::npos ? "" : time.substr(0, colon + 1);
			const std::string tail = colon == std::string::npos ? time : time.substr(colon + 1);
			const int hw = head.empty() ? 0 : text_width(head, theme::font_clock);
			if (!head.empty()) draw_text(cr, head, x0, b.y, hw + 2, b.height, theme::font_clock, theme::text_dim);
			const int mw = text_width(tail, theme::font_clock);
			draw_text(cr, tail, x0 + hw, b.y, mw + 2, b.height, theme::font_clock, theme::text);
			cairo_new_path(cr);
			cairo_arc(cr, x0 + hw + mw + 7, b.y + b.height / 2.0, 3, 0, 2 * M_PI);
			set_color(cr, theme::accent);
			cairo_fill(cr);
		}
		const int bw = badge_width(badge);
		if (cfg.show_date) {
			draw_text(cr, short_date(), x0 + tw + 10, b.y, b.width - tw - 18 - (bw ? bw + 8 : 0), b.height,
				theme::font_clock_date, with_alpha(theme::text, 0.85));
		}
		if (!badge.empty()) draw_badge(b.x + b.width - 8 - bw, cy - kBadgeH / 2.0);
		return;
	}

	if (s.kind == "status") {
		// The status icons on one frosted pill.
		const bool open = server_->control_centre && server_->control_centre->tiles_open_on(output_);
		const double o = lit("status", open);
		{
			const double ph = vertical ? b.height : std::min<double>(b.height - 12, 34);
			const double pw = vertical ? std::min<double>(b.width - 12, 34) : b.width;
			const double px = vertical ? cx - pw / 2 : b.x, py = vertical ? b.y : cy - ph / 2;
			fill_rounded(cr, px, py, pw, ph, chip_radius(std::min(pw, ph)),
				o > 0.01 ? with_alpha(theme::accent, (theme::dark ? 0.32 : 0.22) * o + theme::glass.a * (1 - o))
					: theme::glass);
		}
		const std::vector<std::string> icons = status_icons();
		const double icon = 16;
		double p = (vertical ? b.y : b.x) + 12;
		for (const std::string &name : icons) {
			const bool battery = name.rfind("battery", 0) == 0;
			if (battery && vertical && cfg.battery_style != "icon" && server_->status) {
				const double ix = cx - icon / 2.0, iy = p + (kStatusIcon - icon) / 2;
				draw_named_icon(cr, server_->icons, name, ix, iy, icon, theme::text, scale);
				const int level = server_->status->battery;
				const Color col = server_->status->charging || level >= 50 ? theme::success
					: level >= 20 ? theme::warning : theme::danger;
				draw_text(cr, std::to_string(level) + "%", b.x, p + kStatusIcon - 3, b.width, 14, theme::font_small, col,
					Align::Center);
				p += kStatusIcon + 14;
				continue;
			}
			if (battery && !vertical && cfg.battery_style == "percent" && server_->status) {
				draw_battery_pill(cr, p + 2, cy - 9, kBatteryPill, 18);
				p += kBatteryPill + 4;
				continue;
			}
			if (battery && !vertical && cfg.battery_style == "ring" && server_->status) {
				draw_battery_ring(cr, p + 2, cy - 9, 34, 18);
				p += 40;
				continue;
			}
			const double ix = vertical ? cx - icon / 2.0 : p + (kStatusIcon - icon) / 2;
			const double iy = vertical ? p + (kStatusIcon - icon) / 2 : cy - icon / 2.0;
			if (name == "rec") {
				// Recording: a red pill with the time (click it to stop).
				const Color red = theme::danger;
				if (vertical) {
					fill_rounded(cr, ix - 3, iy - 3, icon + 6, icon + 6, (icon + 6) / 2.0, red);
					fill_rounded(cr, ix + 4, iy + 4, icon - 8, icon - 8, 1.5, rgb(0xffffff));
					p += kStatusIcon;
					continue;
				}
				const int rw = rec_width(server_);
				const double ph = 22;
				const double py = cy - ph / 2;
				fill_rounded(cr, p, py, rw - 4, ph, ph / 2, red);
				const double blink = server_->recorder->starting() ? 0.5 : 1.0;
				cairo_new_path(cr);
				cairo_arc(cr, p + 12, py + ph / 2, 4, 0, 2 * M_PI);
				set_color(cr, rgb(0xffffff, blink));
				cairo_fill(cr);
				draw_text(cr, rec_text(server_), p + 20, py, rw - 28, ph, theme::font_bold, rgb(0xffffff));
				p += rw;
				continue;
			}
			if (name == "unseen:bell") {
				const Color vivid = opposite_colour(theme::accent, theme::dark);
				const double bs = 9;
				const double bx = vertical ? cx - bs / 2.0 : p + (kBellSlot - bs) / 2.0;
				const double by = vertical ? p + (kBellSlot - bs) / 2.0 : cy - bs - 1;
				draw_named_icon(cr, server_->icons, "bell", bx, by, bs, vivid, scale);
				p += kBellSlot;
				continue;
			}
			if (name.rfind("privacy:", 0) == 0) {
				// In use: an amber disc with the icon on it.
				const Color amber = rgb(theme::dark ? 0xf5a524 : 0xd97706);
				fill_rounded(cr, ix - 3, iy - 3, icon + 6, icon + 6, (icon + 6) / 2.0, amber);
				draw_named_icon(cr, server_->icons, name.substr(8), ix + 1.5, iy + 1.5, icon - 3, rgb(0x1a1206), scale);
				p += kStatusIcon;
				continue;
			}
			draw_named_icon(cr, server_->icons, name, ix, iy, icon, theme::text, scale);
			p += kStatusIcon;
		}
		return;
	}

	if (s.kind == "media") {
		// The now-playing chip: a pill in the album's colours with play/pause and the title.
		const SystemStatus *st = server_->status.get();
		if (!st || b.width < 8) {
			return;
		}
		const bool open = server_->media_card && server_->media_card->is_open_on(output_);
		const double ch = std::min<double>(b.height - 12, 32);
		const double top = cy - ch / 2.0;
		cairo_save(cr);
		rounded_rect(cr, b.x, top, b.width, ch, ch / 2);
		cairo_clip(cr);
		rounded_rect(cr, b.x, top, b.width, ch, ch / 2);
		// In the album's colours (the accent's without a cover).
		media_gradient(cr, b.x, top, b.width, ch, 0.12 * std::max(hover, open ? 1.0 : 0.0));
		cairo_fill(cr);
		const Color fg = theme::on_media_gradient();
		draw_named_icon(cr, server_->icons, st->media_playing ? "pause" : "play",
			b.x + 10, cy - 7, 14, fg, scale);
		if (!vertical) {
			draw_text(cr, media_label(), b.x + 30, top, b.width - 40, ch, theme::font_small, fg);
		}
		cairo_restore(cr);
		return;
	}
	(void)r;
}

// Flat-ish: buttons and chips are softly rounded rectangles.
double Panel::corner(const wlr_box &b) const {
	return chip_radius(std::min(b.width, b.height));
}

double Panel::slot_radius(const Slot &s) const {
	const wlr_box &b = s.box;
	if (s.kind == "media") {
		return chip_radius(std::min<double>(b.height - 12, 32));
	}
	return corner(b);
}

void Panel::update_highlight() {
	if (hover_ < 0 || hover_ >= static_cast<int>(slots_.size())) {
		hl_.hide();
		return;
	}
	const Slot &s = slots_[static_cast<size_t>(hover_)];
	if (s.kind == "separator" || s.kind == "spacer") {
		hl_.hide();
		return;
	}
	wlr_box b = s.box;
	if (s.kind == "tasks" || s.kind == "pins") {
		// The app's chip (see app_bubble).
		const int side = std::min(b.width, b.height) - 6;
		b = wlr_box{b.x + (b.width - side) / 2, b.y + (b.height - side) / 2 - 1, side, side};
		hl_.show(b, chip_radius(side), with_alpha(theme::text, theme::dark ? 0.12 : 0.10));
		return;
	}
	if (s.kind == "media") {
		const int ch = std::min(b.height, 28);
		b = wlr_box{b.x, b.y + (b.height - ch) / 2, b.width, ch};
	} else if ((s.kind == "status" || s.kind == "clock") && !config_.vertical()) {
		// The same shape as the chip it lights up.
		const int ch = std::min(b.height - 12, 34);
		b = wlr_box{b.x, b.y + (b.height - ch) / 2, b.width, ch};
	}
	hl_.show(b, slot_radius(s), with_alpha(theme::text, theme::dark ? 0.10 : 0.08));
}

int Panel::slot_at(double px, double py) const {
	for (size_t i = 0; i < slots_.size(); i++) {
		const wlr_box &b = slots_[i].box;
		if (px >= b.x && px < b.x + b.width && py >= b.y && py < b.y + b.height) {
			return static_cast<int>(i);
		}
	}
	return -1;
}

void Panel::motion(double lx, double ly) {
	const wlr_box bar = bar_box();
	const int now = slot_at(lx - (bar.x - bar_.x), ly - (bar.y - bar_.y));
	if (now != hover_) {
		set_hover(now);
	}
}

// The slot under the pointer gets the soft GPU highlight (no redraw, no
// growing: hover stays quiet).
void Panel::set_hover(int index) {
	hover_ = index;
	update_highlight();
}

void Panel::leave() {
	if (hover_ != -1) {
		set_hover(-1);
	}
}

void Panel::click(double lx, double ly, uint32_t button) {
	const wlr_box bar = bar_box();
	const int index = slot_at(lx - (bar.x - bar_.x), ly - (bar.y - bar_.y));
	const Slot *s = index >= 0 ? &slots_[static_cast<size_t>(index)] : nullptr;
	if (s && s->kind == "tray" && server_->tray) {
		// An app's status icon: its window (left), its menu (right).
		const wlr_box anchor{bar.x - bar_.x + s->box.x, bar.y - bar_.y + s->box.y, s->box.width, s->box.height};
		const std::string key = s->tray;
		server_->close_popups();
		hl_.flash();
		if (button == BTN_RIGHT) {
			server_->tray->context_menu(key, output_, anchor, config_.edge);
		} else if (button == BTN_MIDDLE) {
			server_->tray->secondary(key, static_cast<int>(lx), static_cast<int>(ly));
		} else {
			server_->tray->activate(key, static_cast<int>(lx), static_cast<int>(ly));
		}
		return;
	}
	if (button == BTN_RIGHT) {
		// Right-click: a menu for what's under the pointer and the panel.
		show_menu(s, lx, ly);
		return;
	}
	const std::string kind = s ? s->kind : "";
	if (s && s->kind == "spacer") {
		s = nullptr;   // empty bar
	}
	if (s) {
		hl_.flash();
	}
	const wlr_box anchor_box = s ? wlr_box{bar.x - bar_.x + s->box.x, bar.y - bar_.y + s->box.y,
		s->box.width, s->box.height} : bar;

	if (kind == "overview") {
		server_->close_popups();
		if (server_->overview) server_->overview->toggle(output_);
		return;
	}
	if (kind == "trash") {
		server_->close_popups();
		if (server_->trash) server_->trash->open();
		return;
	}
	if (kind == "menu" || kind == "search") {
		const bool was = server_->launcher->is_open_on(output_);
		server_->close_popups();
		if (!was) {
			server_->launcher->open(output_, anchor_box, config_.edge);
		}
		return;
	}
	if (kind == "notifications" || (kind == "clock" && server_->config.clock_click == "notifications")) {
		const bool was = server_->control_centre->notes_open_on(output_);
		server_->close_popups();
		if (!was) server_->control_centre->open_notes(output_, anchor_box, config_.edge);
		return;
	}
	if (kind == "clock" && server_->config.clock_click == "calendar") {
		const bool was = server_->calendar->is_open_on(output_);
		server_->close_popups();
		if (!was) {
			server_->calendar->open(output_, anchor_box, config_.edge);
		}
		return;
	}
	if (kind == "clipboard") {
		const bool was = server_->clipboard_card->is_open_on(output_);
		server_->close_popups();
		if (!was) {
			server_->clipboard_card->open(output_, anchor_box, config_.edge);
		}
		return;
	}
	if (kind == "media") {
		const bool was = server_->media_card->is_open_on(output_);
		server_->close_popups();
		if (!was) {
			server_->media_card->open(output_, anchor_box, config_.edge);
		}
		return;
	}
	if (kind == "status" && recording(server_) && !config_.vertical()) {
		// The recording pill comes first in the status area: clicking it stops.
		const double sx = bar.x - bar_.x + s->box.x + 8;
		if (lx >= sx && lx < sx + rec_width(server_)) {
			server_->recorder->stop();
			return;
		}
	}
	if (kind == "status" || kind == "clock") {
		const bool was = server_->control_centre->is_open_on(output_);
		server_->close_popups();
		if (!was) {
			server_->control_centre->open(output_, anchor_box, config_.edge);
		}
		return;
	}
	server_->close_popups();
	if (kind == "showdesktop") {
		server_->toggle_show_desktop();
		return;
	}
	if (kind == "keyboard") {
		if (server_->osk) server_->osk->toggle(output_);
		redraw();
		return;
	}
	if (kind == "pins") {
		if (button != BTN_LEFT) {
			return;
		}
		View *running = pin_window(s->pin);
		if (running) {
			if (running->minimized) {
				running->restore_from_minimize();
			} else {
				server_->focus(running);
			}
		} else if (const AppInfo *app = pin_app(s->pin)) {
			server_->spawn(app->exec);
		}
		return;
	}
	if (kind == "tasks" && s->view) {
		View *view = s->view;
		if (button == BTN_MIDDLE) {
			view->close();
			return;
		}
		if (button != BTN_LEFT) {
			return;
		}
		if (server_->overview && server_->overview->is_open()) {
			server_->overview->close(view);   // out of the overview, to that window
			return;
		}
		if (view->minimized) {
			view->restore_from_minimize();
		} else if (view->active()) {
			view->minimize();
		} else {
			server_->focus(view);
		}
	}
}

bool Panel::scroll(double lx, double ly, double delta) {
	const wlr_box bar = bar_box();
	const int index = slot_at(lx - (bar.x - bar_.x), ly - (bar.y - bar_.y));
	if (index < 0) return false;
	const std::string &kind = slots_[static_cast<size_t>(index)].kind;
	if (kind == "status") {
		// The status icons (the speaker among them): the wheel sets the
		// volume, a notch a step, with the on-screen display.
		scroll_accum_ += delta;
		while (std::fabs(scroll_accum_) >= 12) {
			server_->volume_key(scroll_accum_ > 0 ? "down" : "up", false);
			scroll_accum_ += scroll_accum_ > 0 ? -15 : 15;
			if (std::fabs(scroll_accum_) < 3) scroll_accum_ = 0;
		}
		return true;
	}
	if (kind != "overview") {
		return false;
	}
	scroll_accum_ += delta;
	if (std::fabs(scroll_accum_) >= 12) {
		server_->switch_workspace(server_->workspace + (scroll_accum_ > 0 ? 1 : -1));
		scroll_accum_ = 0;
	}
	return true;
}

// ---- right-click menus --------------------------------------------------------

std::function<Panel *()> Panel::finder() const {
	Server *srv = server_;
	Output *out = output_;
	const std::string id = config_.id;
	return [srv, out, id]() -> Panel * {
		for (Output *o : srv->outputs) {
			if (o != out) continue;
			for (auto &p : o->panels) {
				if (p->config().id == id) return p.get();
			}
		}
		return nullptr;
	};
}

namespace {

std::string join_list(const std::vector<std::string> &v) {
	std::string out;
	for (const std::string &x : v) {
		out += (out.empty() ? "" : ",") + x;
	}
	return out;
}

std::string long_date() {
	std::time_t now = std::time(nullptr);
	std::tm local{};
	localtime_r(&now, &local);
	char buf[64];
	std::strftime(buf, sizeof buf, "%A %-d %B %Y", &local);
	return buf;
}

} // namespace

// A widget's own options (and a way to the panel's).
void Panel::show_menu(const Slot *slot, double lx, double ly) {
	if (!slot || slot->kind == "spacer" || slot->kind == "separator") {
		show_panel_menu(slot, lx, ly);
		return;
	}
	std::vector<MenuItem> items;
	add_widget_items(*slot, items);
	items.push_back(MenuItem::separator());
	auto find = finder();
	items.push_back(MenuItem::action("Panel options", [find, lx, ly] {
		if (Panel *p = find()) p->show_panel_menu(nullptr, lx, ly);
	}, "gear"));
	server_->close_popups();
	server_->menu->show(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1},
		config_.edge, std::move(items));
}

void Panel::add_widget_items(const Slot &slot, std::vector<MenuItem> &items) {
	Server *srv = server_;
	const Config &cfg = srv->config;
	const std::string pre = "panel." + config_.id + ".";
	const std::vector<std::string> widgets = config_.widgets;
	auto find = finder();
	auto set = [srv](std::string key, std::string value) {
		return [srv, key, value] { srv->write_setting(key, value); };
	};
	// Takes this widget off the panel.
	auto remove_item = [&] {
		const int wi = slot.widget;
		MenuItem m = MenuItem::action("Remove from panel", [srv, pre, widgets, wi] {
			std::vector<std::string> w = widgets;
			if (wi >= 0 && wi < static_cast<int>(w.size())) {
				w.erase(w.begin() + wi);
			}
			srv->write_setting(pre + "widgets", join_list(w));
		}, "minus");
		return m;
	};
	const std::string &kind = slot.kind;

	if (kind == "tasks" && slot.view) {
		View *v = slot.view;
		auto alive = [srv, v] {
			return std::find(srv->views.begin(), srv->views.end(), v) != srv->views.end();
		};
		items.push_back(MenuItem::header(v->title().empty() ? "Window" : v->title()));
		if (v->minimized) {
			items.push_back(MenuItem::action("Restore", [v, alive] { if (alive()) v->restore_from_minimize(); }));
		} else {
			items.push_back(MenuItem::action("Minimise", [v, alive] { if (alive()) v->minimize(); }));
		}
		items.push_back(MenuItem::action(v->maximized ? "Restore size" : "Maximise",
			[v, alive] { if (alive()) v->toggle_maximize(); }));
		int screens = 0;
		for (Output *o : srv->outputs) screens += o->enabled();
		if (screens > 1) {
			items.push_back(MenuItem::action("Move to the next screen",
				[srv, v, alive] { if (alive()) srv->move_to_next_screen(v, 1); }, "display"));
		}
		// Pin its app to this panel (adding pinned apps to it if needed).
		const std::string icon = srv->apps.icon_for(v->app_id(), v->title());
		const AppInfo *app = nullptr;
		for (const AppInfo &a : srv->apps.apps()) {
			if (!icon.empty() && a.icon == icon) {
				app = &a;
				break;
			}
		}
		if (app) {
			const std::string app_id = app->id;
			const bool pinned = std::find(config_.pins.begin(), config_.pins.end(), app_id) != config_.pins.end();
			std::vector<std::string> pins = config_.pins;
			if (pinned) {
				pins.erase(std::remove(pins.begin(), pins.end(), app_id), pins.end());
			} else {
				pins.push_back(app_id);
			}
			std::vector<std::string> w = widgets;   // (pinned apps show with the open ones)
			items.push_back(MenuItem::action(pinned ? "Unpin from panel" : "Pin to panel",
				[srv, pre, pins, w, widgets] {
					if (w != widgets) Config::write_key(pre + "widgets", join_list(w));
					srv->write_setting(pre + "pins", join_list(pins));
				}, "plus"));
		}
		MenuItem close = MenuItem::action("Close", [v, alive] { if (alive()) v->close(); }, "close");
		close.danger = true;
		items.push_back(MenuItem::separator());
		items.push_back(close);
		return;
	}

	if (kind == "pins" && slot.pin >= 0) {
		const AppInfo *app = pin_app(slot.pin);
		const std::string exec = app ? app->exec : "";
		std::vector<std::string> pins = config_.pins;
		const size_t i = static_cast<size_t>(slot.pin);
		if (app) {
			items.push_back(MenuItem::header(app->name));
			items.push_back(MenuItem::action(pin_window(slot.pin) ? "New window" : "Open",
				[srv, exec] { srv->spawn(exec); }, "open"));
		}
		if (i > 0 && i < pins.size()) {
			std::vector<std::string> moved = pins;
			std::swap(moved[i], moved[i - 1]);
			items.push_back(MenuItem::action(config_.vertical() ? "Move up" : "Move left",
				[srv, pre, moved] { srv->write_setting(pre + "pins", join_list(moved)); }));
		}
		if (i + 1 < pins.size()) {
			std::vector<std::string> moved = pins;
			std::swap(moved[i], moved[i + 1]);
			items.push_back(MenuItem::action(config_.vertical() ? "Move down" : "Move right",
				[srv, pre, moved] { srv->write_setting(pre + "pins", join_list(moved)); }));
		}
		if (i < pins.size()) {
			pins.erase(pins.begin() + slot.pin);
		}
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::action("Unpin from panel",
			[srv, pre, pins] { srv->write_setting(pre + "pins", join_list(pins)); }, "minus"));
		return;
	}

	if (kind == "menu") {
		items.push_back(MenuItem::action("Open the app menu", [srv, find] {
			if (Panel *p = find()) srv->launcher->open(p->output(), p->anchor("menu"), p->config().edge);
		}, "apps"));
		items.push_back(MenuItem::action("Terminal", [srv] { srv->spawn_terminal(); }, "terminal"));
		items.push_back(MenuItem::action("Files", [srv] { srv->spawn("xdg-open \"$HOME\""); }, "folder"));
		items.push_back(MenuItem::action("Settings", [srv] { srv->open_settings(); }, "gear"));
		items.push_back(MenuItem::separator());
		items.push_back(remove_item());
		return;
	}

	if (kind == "clock") {
		items.push_back(MenuItem::header(long_date()));
		items.push_back(MenuItem::action("Calendar", [srv, find] {
			if (Panel *p = find()) srv->calendar->open(p->output(), p->anchor("clock"), p->config().edge);
		}));
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::check("24-hour clock", cfg.clock_24h,
			set("clock_24h", cfg.clock_24h ? "false" : "true")));
		items.push_back(MenuItem::check("Show the date", cfg.show_date,
			set("show_date", cfg.show_date ? "false" : "true")));
		items.push_back(MenuItem::header("Clicking the clock opens"));
		items.push_back(MenuItem::radio("The calendar", cfg.clock_click == "calendar",
			set("clock_click", "calendar")));
		items.push_back(MenuItem::radio("The notifications", cfg.clock_click == "notifications",
			set("clock_click", "notifications")));
		items.push_back(MenuItem::radio("The control centre", cfg.clock_click == "controlcentre",
			set("clock_click", "controlcentre")));
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::action("Date & time settings…", [srv] { srv->open_settings("datetime"); }));
		items.push_back(remove_item());
		return;
	}

	if (kind == "status") {
		const SystemStatus *st = srv->status.get();
		items.push_back(MenuItem::action("Control centre", [srv, find] {
			if (Panel *p = find()) srv->control_centre->open(p->output(), p->anchor("status"), p->config().edge);
		}, "gear"));
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::check("Do not disturb", cfg.dnd, set("dnd", cfg.dnd ? "false" : "true")));
		if (st && st->has_audio) {
			items.push_back(MenuItem::check("Mute sound", st->muted, [srv] { srv->status->toggle_mute(); }));
			items.push_back(MenuItem::action("Play sound on…", [srv, find] {
				if (Panel *p = find()) {
					const wlr_box a = p->anchor("status");
					sound_output_menu(srv, p->output(), a.x + a.width / 2.0, a.y + a.height / 2.0);
				}
			}, "speaker"));
		}
		items.push_back(MenuItem::check("Night light", cfg.night_light,
			set("night_light", cfg.night_light ? "false" : "true")));
		items.push_back(MenuItem::check("Dark mode", cfg.dark, set("theme", cfg.dark ? "light" : "dark")));
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::action("Control centre settings…",
			[srv] { srv->open_settings("controlcentre"); }));
		items.push_back(remove_item());
		return;
	}

	if (kind == "media") {
		const SystemStatus *st = srv->status.get();
		if (st && !st->media_title.empty()) {
			items.push_back(MenuItem::header(st->media_title));
		}
		items.push_back(MenuItem::action(st && st->media_playing ? "Pause" : "Play",
			[srv] { srv->status->media("play-pause"); }, st && st->media_playing ? "pause" : "play"));
		items.push_back(MenuItem::action("Next", [srv] { srv->status->media("next"); }, "next"));
		items.push_back(MenuItem::action("Previous", [srv] { srv->status->media("previous"); }, "previous"));
		items.push_back(MenuItem::action("Show the player", [srv, find] {
			if (Panel *p = find()) srv->media_card->open(p->output(), p->anchor("media"), p->config().edge);
		}));
		items.push_back(MenuItem::separator());
		// The same as the media card's own menu: lyrics, the visualizer, settings.
		media_menu_items(srv, output_, anchor("media"), config_.edge, items);
		items.push_back(MenuItem::separator());
		items.push_back(remove_item());
		return;
	}

	if (kind == "clipboard") {
		const bool any = srv->clipboard && !srv->clipboard->history().empty();
		items.push_back(MenuItem::action("Clipboard history", [srv, find] {
			srv->clipboard_card->show_tab(0);
			if (Panel *p = find()) srv->clipboard_card->open(p->output(), p->anchor("clipboard"), p->config().edge);
		}, "clipboard"));
		MenuItem clear = MenuItem::action("Clear history", [srv] {
			if (srv->clipboard) srv->clipboard->clear();
		}, "trash");
		clear.enabled = any;
		items.push_back(clear);
		items.push_back(MenuItem::check("Keep a history", cfg.clipboard_history,
			set("clipboard_history", cfg.clipboard_history ? "false" : "true")));
		items.push_back(MenuItem::check("Middle-click pastes", cfg.middle_click_paste,
			set("middle_click_paste", cfg.middle_click_paste ? "false" : "true")));
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::action("Clipboard settings…", [srv] { srv->open_settings("desktop"); }));
		items.push_back(remove_item());
		return;
	}

	if (kind == "overview") {
		Output *out = output_;
		items.push_back(MenuItem::action("Overview", [srv, out] { if (srv->overview) srv->overview->toggle(out); }, "layout-grid"));
		items.push_back(MenuItem::header("Workspaces"));
		for (int i = 0; i < srv->workspace_count; i++) {
			const bool empty = !srv->workspace_used(i);
			items.push_back(MenuItem::radio("Workspace " + std::to_string(i + 1) + (empty ? "  (empty)" : ""),
				i == srv->workspace, [srv, i] { srv->switch_workspace(i); }));
		}
		if (srv->workspace_count < 12) {
			items.push_back(MenuItem::action("New workspace", [srv] { srv->add_workspace(); }, "plus"));
		}
		if (srv->workspace_count > 1) {
			const int cur = srv->workspace;
			items.push_back(MenuItem::action("Remove this workspace", [srv, cur] { srv->remove_workspace(cur); }, "minus"));
		}
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::action("Workspace settings…", [srv] { srv->open_settings("workspaces"); }, "gear"));
		items.push_back(remove_item());
		return;
	}

	if (kind == "trash") {
		if (srv->trash) {
			const wlr_box bar = bar_box();
			const wlr_box anchor{bar.x - bar_.x + slot.box.x, bar.y - bar_.y + slot.box.y, slot.box.width, slot.box.height};
			srv->trash->add_menu_items(items, output_, anchor, config_.edge);
		}
		items.push_back(MenuItem::separator());
		items.push_back(remove_item());
		return;
	}

	if (kind == "notifications") {
		items.push_back(MenuItem::check("Do not disturb", cfg.dnd, set("dnd", cfg.dnd ? "false" : "true")));
		items.push_back(MenuItem::action("Clear all", [srv] {
			if (srv->notifications) srv->notifications->clear_all();
			srv->redraw_panels();
		}, "trash"));
		items.push_back(MenuItem::action("Notification settings", [srv] { srv->open_settings("notifications"); }, "gear"));
		items.push_back(MenuItem::separator());
		items.push_back(remove_item());
		return;
	}

	if (kind == "showdesktop") {
		items.push_back(MenuItem::action(srv->shown_desktop.empty() ? "Show the desktop" : "Bring the windows back",
			[srv] { srv->toggle_show_desktop(); }, "desktop"));
		items.push_back(MenuItem::separator());
		items.push_back(remove_item());
		return;
	}
}

// The panel itself: auto-hide, position, style, panels.
void Panel::show_panel_menu(const Slot *slot, double lx, double ly) {
	Server *srv = server_;
	const std::string id = config_.id;
	const std::string pre = "panel." + id + ".";
	std::vector<MenuItem> items;

	// A flexible space or separator: it can go.
	if (slot && (slot->kind == "spacer" || slot->kind == "separator") && slot->widget >= 0) {
		const std::vector<std::string> widgets = config_.widgets;
		const int wi = slot->widget;
		items.push_back(MenuItem::action(slot->kind == "spacer" ? "Remove this flexible space"
			: "Remove this separator", [srv, pre, widgets, wi] {
				std::vector<std::string> w = widgets;
				if (wi < static_cast<int>(w.size())) w.erase(w.begin() + wi);
				srv->write_setting(pre + "widgets", join_list(w));
			}, "minus"));
		items.push_back(MenuItem::separator());
	}

	items.push_back(MenuItem::header("Panel"));
	items.push_back(MenuItem::check("Auto-hide", config_.autohide,
		[srv, pre, on = config_.autohide] { srv->write_setting(pre + "autohide", on ? "false" : "true"); }));
	if (!config_.vertical() && std::find(config_.widgets.begin(), config_.widgets.end(), "tasks") !=
			config_.widgets.end()) {
	}
	items.push_back(MenuItem::header("Position"));
	for (const auto &[label, edge] : std::vector<std::pair<std::string, std::string>>{
			{"Bottom", "bottom"}, {"Top", "top"}, {"Left", "left"}, {"Right", "right"}}) {
		items.push_back(MenuItem::radio(label, config_.edge == edge,
			[srv, pre, e = edge] { srv->write_setting(pre + "edge", e); }));
	}
	items.push_back(MenuItem::header("Style"));
	for (const auto &[label, style] : std::vector<std::pair<std::string, std::string>>{
			{"Floating", "floating"}, {"Full width", "full"}, {"Dock", "dock"}}) {
		items.push_back(MenuItem::radio(label, config_.style == style,
			[srv, pre, st = style] { srv->write_setting(pre + "style", st); }));
	}
	items.push_back(MenuItem::separator());

	std::vector<std::string> ids;
	for (const PanelConfig &pc : srv->config.panels) {
		ids.push_back(pc.id);
	}
	items.push_back(MenuItem::action("Add a panel", [srv, ids] {
		std::vector<std::string> next = ids;
		std::string fresh;
		for (int n = 2; fresh.empty(); n++) {
			const std::string candidate = "panel" + std::to_string(n);
			if (std::find(next.begin(), next.end(), candidate) == next.end()) {
				fresh = candidate;
			}
		}
		// On an edge nobody uses yet, if there is one.
		std::string edge = "top";
		for (const char *e : {"top", "left", "right", "bottom"}) {
			bool used = false;
			for (const PanelConfig &pc : srv->config.panels) {
				used = used || pc.edge == e;
			}
			if (!used) {
				edge = e;
				break;
			}
		}
		Config::write_key("panel." + fresh + ".edge", edge);
		Config::write_key("panel." + fresh + ".widgets", "menu,tasks,spacer,clock");
		next.push_back(fresh);
		srv->write_setting("panels", join_list(next));
	}, "plus"));
	if (ids.size() > 1) {
		std::vector<std::string> rest = ids;
		rest.erase(std::remove(rest.begin(), rest.end(), id), rest.end());
		MenuItem remove = MenuItem::action("Remove this panel",
			[srv, rest] { srv->write_setting("panels", join_list(rest)); }, "trash");
		remove.danger = true;
		items.push_back(remove);
	}
	items.push_back(MenuItem::action("Panel settings…", [srv] { srv->open_settings("panels"); }, "gear"));

	srv->close_popups();
	srv->menu->show(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1},
		config_.edge, std::move(items));
}

// ---- auto-hide --------------------------------------------------------------

bool Panel::something_open() const {
	return (server_->launcher && server_->launcher->is_open_on(output_)) ||
		(server_->control_centre && server_->control_centre->is_open_on(output_)) ||
		(server_->calendar && server_->calendar->is_open_on(output_)) ||
		(server_->media_card && server_->media_card->is_open_on(output_)) ||
		(server_->clipboard_card && server_->clipboard_card->is_open_on(output_)) ||
		(server_->menu && server_->menu->is_open_on(output_));
}

void Panel::show(bool on) {
	if (on == want_shown_) {
		return;
	}
	want_shown_ = on;
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(shown_, on ? 1.0 : 0.0,
		c.animate(c.anim_panel) ? c.ms(on ? 160 : 220) : 0, [this] { redraw(); },
		[this] { anim_ = 0; });
}

int Panel::handle_hide_timer(void *data) {
	auto *self = static_cast<Panel *>(data);
	self->hide_armed_ = false;
	if (self->something_open()) {
		self->hide_armed_ = true;
		wl_event_source_timer_update(self->hide_timer_, 500);   // check again later
		return 0;
	}
	const double cx = self->server_->cursor->x, cy = self->server_->cursor->y;
	if (!self->contains(cx, cy)) {
		self->show(false);
	}
	return 0;
}

void Panel::pointer_moved(double lx, double ly) {
	if (!config_.autohide) {
		return;
	}
	const wlr_box o = output_->box();
	const std::string &e = config_.edge;
	const bool inside_range = config_.vertical()
		? (ly >= strip_.y && ly < strip_.y + strip_.height)
		: (lx >= strip_.x && lx < strip_.x + strip_.width);
	bool at_edge = false;
	if (inside_range) {
		if (e == "bottom") at_edge = ly >= o.y + o.height - 2;
		else if (e == "top") at_edge = ly <= o.y + 1;
		else if (e == "left") at_edge = lx <= o.x + 1;
		else at_edge = lx >= o.x + o.width - 2;
	}
	if (at_edge || (want_shown_ && contains(lx, ly))) {
		show(true);
		wl_event_source_timer_update(hide_timer_, 0);
		hide_armed_ = false;
	} else if (want_shown_ && !hide_armed_) {
		wl_event_source_timer_update(hide_timer_, 600);
		hide_armed_ = true;
	}
}

// ---- Dragging pinned apps into order ---------------------------------------------

bool Panel::pin_press(double lx, double ly) {
	const wlr_box bar = bar_box();
	const int index = slot_at(lx - (bar.x - bar_.x), ly - (bar.y - bar_.y));
	if (index < 0) return false;
	const Slot &s = slots_[static_cast<size_t>(index)];
	// A pinned app, whether it's waiting (pins) or running (its first window
	// in the task list carries the pin).
	if (s.pin < 0 || (s.kind != "pins" && s.kind != "tasks") || config_.pins.size() < 2) return false;
	drag_pin_ = s.pin;
	drag_x_ = lx;
	drag_y_ = ly;
	pin_dragging_ = false;
	pins_before_ = config_.pins;
	return true;
}

void Panel::pin_drag(double lx, double ly) {
	if (drag_pin_ < 0) return;
	if (!pin_dragging_) {
		if (std::hypot(lx - drag_x_, ly - drag_y_) < 8) return;   // still a click
		pin_dragging_ = true;
		server_->close_popups();
	}
	// The pinned app under the pointer: ours moves into its place.
	const wlr_box bar = bar_box();
	const double px = lx - (bar.x - bar_.x), py = ly - (bar.y - bar_.y);
	const int index = slot_at(px, py);
	if (index < 0) return;
	const Slot &s = slots_[static_cast<size_t>(index)];
	if (s.pin < 0 || (s.kind != "pins" && s.kind != "tasks") || s.pin == drag_pin_) return;
	const int to = s.pin;
	if (to >= static_cast<int>(config_.pins.size()) || drag_pin_ >= static_cast<int>(config_.pins.size())) return;
	// Only once past the middle of the other one (no flicking back and forth).
	const double mid = config_.vertical() ? s.box.y + s.box.height / 2.0 : s.box.x + s.box.width / 2.0;
	const double at = config_.vertical() ? py : px;
	if ((to > drag_pin_ && at < mid) || (to < drag_pin_ && at > mid)) return;
	const std::string moving = config_.pins[static_cast<size_t>(drag_pin_)];
	config_.pins.erase(config_.pins.begin() + drag_pin_);
	config_.pins.insert(config_.pins.begin() + to, moving);
	drag_pin_ = to;
	redraw();
}

void Panel::pin_release(double lx, double ly) {
	const bool dragged = pin_dragging_;
	drag_pin_ = -1;
	pin_dragging_ = false;
	if (!dragged) {
		click(lx, ly, BTN_LEFT);
		return;
	}
	if (config_.pins != pins_before_) {
		server_->write_setting("panel." + config_.id + ".pins", join_list(config_.pins));
	}
}

} // namespace arqen
