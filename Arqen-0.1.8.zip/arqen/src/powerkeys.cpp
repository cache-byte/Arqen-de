// The laptop's lid and the power button (Settings › Power › Lid and power
// button).
//
// Normally logind does what systemd's logind.conf says (close the lid:
// sleep; power button: shut down). When Settings picks something else,
// Arqen takes logind's "handle-lid-switch" / "handle-power-key" inhibitor
// locks, as GNOME and KDE do, so logind leaves that one alone, and does it
// here instead. Left at "As the system says", nothing is taken.
#include "server.hpp"
#include "lock.hpp"
#include "system.hpp"

#include <fcntl.h>
#include <systemd/sd-bus.h>
#include <unistd.h>

#include <memory>

#include "anim.hpp"

namespace arqen {

namespace {

// A built-in screen (a laptop's own), going by the connector's name.
bool internal_output(const Output *o) {
	const std::string name = o->output->name ? o->output->name : "";
	return name.rfind("eDP", 0) == 0 || name.rfind("LVDS", 0) == 0 || name.rfind("DSI", 0) == 0;
}

} // namespace

struct LidSwitch {
	Server *server;
	wlr_switch *sw;
	Listener on_toggle, on_destroy;

	LidSwitch(Server *s, wlr_switch *w) : server(s), sw(w) {
		on_toggle.connect<&LidSwitch::handle_toggle>(&w->events.toggle, this);
		on_destroy.connect<&LidSwitch::handle_destroy>(&w->base.events.destroy, this);
	}
	void handle_toggle(void *data);
	void handle_destroy(void *data);
};

struct PowerKeys {
	Server *server;
	sd_bus *bus = nullptr;
	sd_bus_slot *sleep_slot = nullptr;
	wl_event_source *bus_source = nullptr;
	int lid_fd = -1, key_fd = -1;   // logind's inhibitor locks, while held
	std::vector<std::unique_ptr<LidSwitch>> lids;
	double woke_at = 0;     // now_ms() when the computer last woke up
	double pressed_at = 0;  // the power button's last press

	explicit PowerKeys(Server *s) : server(s) {}
	~PowerKeys() {
		release(lid_fd);
		release(key_fd);
		if (bus_source) wl_event_source_remove(bus_source);
		sd_bus_slot_unref(sleep_slot);
		if (bus) sd_bus_flush_close_unref(bus);
	}

	static void release(int &fd) {
		if (fd >= 0) close(fd);
		fd = -1;
	}

	bool open_bus() {
		if (bus) return true;
		if (sd_bus_open_system(&bus) < 0) {
			bus = nullptr;
			return false;
		}
		// Just woken up: the button press that woke it can arrive as a
		// press, which mustn't put it straight back to sleep.
		sd_bus_match_signal(bus, &sleep_slot, "org.freedesktop.login1", "/org/freedesktop/login1",
			"org.freedesktop.login1.Manager", "PrepareForSleep",
			[](sd_bus_message *m, void *data, sd_bus_error *) {
				int going = 0;
				if (sd_bus_message_read(m, "b", &going) >= 0 && !going) {
					static_cast<PowerKeys *>(data)->woke_at = now_ms();
				}
				return 0;
			}, this);
		bus_source = wl_event_loop_add_fd(server->loop, sd_bus_get_fd(bus), WL_EVENT_READABLE,
			[](int, uint32_t, void *data) {
				auto *self = static_cast<PowerKeys *>(data);
				while (self->bus && sd_bus_process(self->bus, nullptr) > 0) {
				}
				return 0;
			}, this);
		while (sd_bus_process(bus, nullptr) > 0) {
		}
		return true;
	}

	// Takes (or gives back) one of logind's "handle-..." locks.
	void hold(int &fd, bool want, const char *what, const char *why) {
		if (!want) {
			if (fd >= 0) wlr_log(WLR_INFO, "Giving %s back to logind", what);
			release(fd);
			return;
		}
		if (fd >= 0 || !open_bus()) return;
		sd_bus_error err = SD_BUS_ERROR_NULL;
		sd_bus_message *reply = nullptr;
		if (sd_bus_call_method(bus, "org.freedesktop.login1", "/org/freedesktop/login1",
				"org.freedesktop.login1.Manager", "Inhibit", &err, &reply, "ssss", what, "Arqen", why,
				"block") >= 0) {
			int got = -1;
			if (sd_bus_message_read(reply, "h", &got) >= 0 && got >= 0) {
				fd = fcntl(got, F_DUPFD_CLOEXEC, 3);
				wlr_log(WLR_INFO, "Arqen handles %s itself", what);
			}
		} else {
			wlr_log(WLR_ERROR, "Couldn't take %s from logind: %s", what, err.message ? err.message : "?");
		}
		sd_bus_message_unref(reply);
		sd_bus_error_free(&err);
	}

	void sync() {
		// Only in a real session: nested in another desktop, the lid and the
		// button belong to that one.
		const Config &c = server->config;
		const bool real = server->session != nullptr;
		const bool lid = real && (c.lid_battery != "system" || c.lid_ac != "system" || c.lid_docked != "system");
		const bool key = real && c.power_key != "system";
		hold(lid_fd, lid, "handle-lid-switch", "Does what Settings › Power says when the lid closes");
		hold(key_fd, key, "handle-power-key", "Does what Settings › Power says for the power button");
	}
};

void LidSwitch::handle_toggle(void *data) {
	auto *event = static_cast<wlr_switch_toggle_event *>(data);
	if (event->switch_type != WLR_SWITCH_TYPE_LID) return;
	server->lid_changed(event->switch_state == WLR_SWITCH_STATE_ON);
}

void LidSwitch::handle_destroy(void *) {
	if (!server->power_keys) return;
	auto &lids = server->power_keys->lids;
	for (auto it = lids.begin(); it != lids.end(); ++it) {
		if (it->get() == this) {
			lids.erase(it);   // (deletes this: nothing after it)
			return;
		}
	}
}

PowerKeys &Server::power_keys_here() {
	if (!power_keys) {
		power_keys = std::unique_ptr<PowerKeys, void (*)(PowerKeys *)>(new PowerKeys(this),
			[](PowerKeys *p) { delete p; });
	}
	return *power_keys;
}

void Server::add_switch(wlr_input_device *device) {
	power_keys_here().lids.push_back(std::make_unique<LidSwitch>(this, wlr_switch_from_input_device(device)));
}

void Server::sync_power_keys() {
	power_keys_here().sync();
}

void Server::stop_power_keys() {
	power_keys.reset();
}

// Does one of the choices in Settings (the lid's and the button's are
// the same words).
void Server::do_power_choice(const std::string &what) {
	if (what == "sleep" || what == "hibernate" || what == "shutdown" || what == "lock") {
		power_action(what);
	} else if (what == "screen_off") {
		screens_off_now();
	} else if (what == "lock_screen_off") {
		power_action("lock");
		screens_off_now();
	} else if (what == "menu") {
		if (locked()) return;   // (the button just wakes the screen)
		Output *o = focused_output();
		if (!o) return;
		wlr_box b{};
		wlr_output_layout_get_box(layout, o->output, &b);
		show_power_menu(o, wlr_box{b.x + b.width / 2, b.y + b.height / 2, 1, 1}, "point");
	}
}

void Server::lid_changed(bool closed) {
	if (!power_keys || power_keys->lid_fd < 0) return;   // logind's job
	wlr_log(WLR_INFO, "Lid %s", closed ? "closed" : "opened");
	if (!closed) {
		note_activity();   // the screen comes back
		return;
	}
	// Another screen in use: "docked".
	bool docked = false;
	for (Output *o : outputs) {
		if (o->enabled() && !internal_output(o)) docked = true;
	}
	const bool on_battery = status && status->has_battery && !status->battery_dead && !status->charging &&
		status->on_mains != 1;
	std::string what = docked ? config.lid_docked : on_battery ? config.lid_battery : config.lid_ac;
	if (what == "system") {
		// (Only some of the three were picked: this one wasn't. What logind
		// would do by default.)
		what = docked ? "nothing" : "sleep";
	}
	do_power_choice(what);
}

// The power button. True: dealt with here (logind leaves it to us).
bool Server::power_key_pressed() {
	if (!power_keys || power_keys->key_fd < 0) return false;
	PowerKeys &pk = *power_keys;
	const double now = now_ms();
	// The press that woke the computer, or the button held a moment.
	if (now - pk.woke_at < 3000 || now - pk.pressed_at < 800) return true;
	pk.pressed_at = now;
	do_power_choice(config.power_key);
	return true;
}

} // namespace arqen
