#!/usr/bin/env python3
"""Arqen's icon pack: the source for src/arqen_icons.hpp.

Two-tone line icons on a 24 px grid (2 px margin): the outline that names
the thing in the full tone, a detail in the soft tone (the colour at 40%),
round ends and joins, a little small solid where it helps at 16 px.

    python3 tools/arqen_icons.py            # writes src/arqen_icons.hpp
    python3 tools/arqen_icons.py --preview out.png   # a sheet to look at

Layers: s / t  line, full / soft tone      f / b  filled, full / soft
        F / B  filled with rounded corners (fill + a line round it)
Ops:    M x y | L x y | C x1 y1 x2 y2 x y | Z | O cx cy r
        R x y w h r | A cx cy r from to (new piece) | a ... (continues)
"""
import math
import sys


def n(v):
    s = f"{v:.2f}".rstrip("0").rstrip(".")
    return "0" if s == "-0" else s


def R(x, y, w, h, r):
    return f"R {n(x)} {n(y)} {n(w)} {n(h)} {n(r)}"


def O(cx, cy, r):
    return f"O {n(cx)} {n(cy)} {n(r)}"


def A(cx, cy, r, a0, a1, cont=False):
    return f"{'a' if cont else 'A'} {n(cx)} {n(cy)} {n(r)} {n(a0)} {n(a1)}"


def P(*pts, close=False):
    s = "M " + " L ".join(f"{n(x)} {n(y)}" for x, y in pts)
    return s + (" Z" if close else "")


def gear(cx, cy, r_out, r_in, teeth, hole=None):
    """A gear outline with rounded-looking teeth (round joins do the rest)."""
    pts = []
    step = 2 * math.pi / teeth
    for i in range(teeth):
        a = i * step - math.pi / 2
        for da, r in ((-0.30, r_in), (-0.15, r_out), (0.15, r_out), (0.30, r_in)):
            pts.append((cx + r * math.cos(a + da * step), cy + r * math.sin(a + da * step)))
    return P(*pts, close=True)


def star(cx, cy, ro, ri, k=5, rot=-90):
    pts = []
    for i in range(2 * k):
        r = ro if i % 2 == 0 else ri
        a = math.radians(rot + i * 180 / k)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return P(*pts, close=True)


SPARK = lambda cx, cy, r: (  # a four-point sparkle
    f"M {n(cx)} {n(cy - r)} C {n(cx + r * .12)} {n(cy - r * .3)} {n(cx + r * .3)} {n(cy - r * .12)} {n(cx + r)} {n(cy)} "
    f"C {n(cx + r * .3)} {n(cy + r * .12)} {n(cx + r * .12)} {n(cy + r * .3)} {n(cx)} {n(cy + r)} "
    f"C {n(cx - r * .12)} {n(cy + r * .3)} {n(cx - r * .3)} {n(cy + r * .12)} {n(cx - r)} {n(cy)} "
    f"C {n(cx - r * .3)} {n(cy - r * .12)} {n(cx - r * .12)} {n(cy - r * .3)} {n(cx)} {n(cy - r)} Z")

# Shared shapes
SPEAKER = "M 3.5 10.5 C 3.5 9.7 4.2 9 5 9 L 7.3 9 L 10.9 5.9 C 11.5 5.4 12.3 5.8 12.3 6.6 L 12.3 17.4 C 12.3 18.2 11.5 18.6 10.9 18.1 L 7.3 15 L 5 15 C 4.2 15 3.5 14.3 3.5 13.5 Z"
BELL = "M 6 10 C 6 6.7 8.7 4 12 4 C 15.3 4 18 6.7 18 10 L 18 13.6 L 19.6 16.2 C 20 16.9 19.5 17.6 18.8 17.6 L 5.2 17.6 C 4.5 17.6 4 16.9 4.4 16.2 L 6 13.6 Z"
FOLDER = "M 3 7 C 3 5.6 4.1 4.5 5.5 4.5 L 9.3 4.5 C 9.9 4.5 10.4 4.8 10.8 5.2 L 12.2 6.8 L 18.5 6.8 C 19.9 6.8 21 7.9 21 9.3 L 21 17 C 21 18.4 19.9 19.5 18.5 19.5 L 5.5 19.5 C 4.1 19.5 3 18.4 3 17 Z"
FILE = "M 7 3 L 13.6 3 L 19 8.4 L 19 18.5 C 19 19.9 17.9 21 16.5 21 L 7 21 C 5.6 21 4.5 19.9 4.5 18.5 L 4.5 5.5 C 4.5 4.1 5.6 3 7 3 Z"
EYE = "M 2.5 12 C 4.6 7.8 8 5.5 12 5.5 C 16 5.5 19.4 7.8 21.5 12 C 19.4 16.2 16 18.5 12 18.5 C 8 18.5 4.6 16.2 2.5 12 Z"
MOON = "M 19.5 14.6 C 18.4 17.8 15.4 20 12 20 C 7.6 20 4 16.4 4 12 C 4 8.6 6.2 5.6 9.4 4.5 C 9 5.4 8.8 6.4 8.8 7.4 C 8.8 11.7 12.3 15.2 16.6 15.2 C 17.6 15.2 18.6 15 19.5 14.6 Z"
HOUSE = "M 3.5 10.4 C 3.5 9.8 3.8 9.2 4.3 8.8 L 10.6 3.9 C 11.4 3.3 12.6 3.3 13.4 3.9 L 19.7 8.8 C 20.2 9.2 20.5 9.8 20.5 10.4 L 20.5 18 C 20.5 19.4 19.4 20.5 18 20.5 L 6 20.5 C 4.6 20.5 3.5 19.4 3.5 18 Z"
TRASH_BODY = "M 5.5 7.5 L 18.5 7.5 L 17.6 18.6 C 17.5 19.7 16.6 20.5 15.5 20.5 L 8.5 20.5 C 7.4 20.5 6.5 19.7 6.4 18.6 Z"
SHIELD_LOCK_SHACKLE = "M 8 10.5 L 8 7.5 C 8 5.3 9.8 3.5 12 3.5 C 14.2 3.5 16 5.3 16 7.5 L 16 10.5"
BOLT = "M 13.2 3 L 6.5 13 L 11.5 13 L 10.8 21 L 17.5 11 L 12.5 11 Z"
LEAF = "M 5 19 C 5 11 9.5 5.5 19.5 4.5 C 19.5 13.5 15 19 7.5 19 Z"
PLAY = "M 7.5 5.6 C 7.5 4.6 8.6 4 9.4 4.6 L 18.4 10.9 C 19.1 11.4 19.1 12.6 18.4 13.1 L 9.4 19.4 C 8.6 20 7.5 19.4 7.5 18.4 Z"
CHAT = "M 4 7 C 4 5.3 5.3 4 7 4 L 17 4 C 18.7 4 20 5.3 20 7 L 20 14 C 20 15.7 18.7 17 17 17 L 10 17 L 6.2 19.8 C 5.6 20.2 4.8 19.8 4.8 19.1 L 4.8 17 C 4.3 16.6 4 15.9 4 15 Z"
POINTER = "M 5.8 4.2 L 18.6 9.4 C 19.4 9.7 19.4 10.9 18.6 11.2 L 13.3 13.3 L 11.2 18.6 C 10.9 19.4 9.7 19.4 9.4 18.6 L 4.2 5.8 C 3.9 4.9 4.9 3.9 5.8 4.2 Z"
PEN = "M 15.2 4.8 C 16.1 3.9 17.6 3.9 18.5 4.8 L 19.2 5.5 C 20.1 6.4 20.1 7.9 19.2 8.8 L 9 19 L 4.5 19.5 L 5 15 Z"
MIC = R(9, 3, 6, 11, 3)
MIC_ARC = "M 5.5 11.5 C 5.5 15.1 8.4 18 12 18 C 15.6 18 18.5 15.1 18.5 11.5"
SUN_RAYS = ";".join(
    "s " + P((12 + 7.6 * math.cos(math.radians(a)), 12 + 7.6 * math.sin(math.radians(a))),
             (12 + 9.2 * math.cos(math.radians(a)), 12 + 9.2 * math.sin(math.radians(a))))
    for a in range(0, 360, 45))
SUN_RAYS_SOFT = SUN_RAYS.replace("s M", "t M")
MONITOR = R(2.5, 4, 19, 12.5, 3)
PHONE = R(6.5, 2.5, 11, 19, 3)
CLIP = "M 9 5 L 7.5 5 C 6.1 5 5 6.1 5 7.5 L 5 18.5 C 5 19.9 6.1 21 7.5 21 L 16.5 21 C 17.9 21 19 19.9 19 18.5 L 19 7.5 C 19 6.1 17.9 5 16.5 5 L 15 5"

ICONS = {
    # ---- system and status
    "airplane": f"b {P((12,3),(13.5,5),(13.5,20),(10.5,20),(10.5,5),close=True)};"
                "s M 12 3 C 12.9 3 13.5 3.9 13.5 5 L 13.5 9.6 L 20.5 13.8 L 20.5 15.8 L 13.5 13.8 L 13.5 17.8 L 15.6 19.5 L 15.6 21 L 12 20.1 "
                "L 8.4 21 L 8.4 19.5 L 10.5 17.8 L 10.5 13.8 L 3.5 15.8 L 3.5 13.8 L 10.5 9.6 L 10.5 5 C 10.5 3.9 11.1 3 12 3 Z",
    "bell": f"s {BELL};t M 10 20.5 L 14 20.5",
    "bell-off": f"s {BELL};t M 10 20.5 L 14 20.5;s M 3.5 3.5 L 20.5 20.5",
    "bluetooth": f"s M 7.5 8.2 L 16.2 15.6 L 12 19.6 L 12 4.4 L 16.2 8.4 L 7.5 15.8;t {O(4.6,12,1.1)};t {O(19.4,12,1.1)}",
    "bluetooth-off": f"t M 7.5 8.2 L 16.2 15.6 L 12 19.6 L 12 4.4 L 16.2 8.4 L 7.5 15.8;s M 4 4 L 20 20",
    "coffee": "s M 4.5 9 L 16.5 9 L 16.5 15 C 16.5 17.8 14.3 20 11.5 20 L 9.5 20 C 6.7 20 4.5 17.8 4.5 15 Z;"
              "s M 16.5 10.5 L 17.5 10.5 C 19 10.5 20.2 11.7 20.2 13.2 C 20.2 14.7 19 15.9 17.5 15.9 L 16.5 15.9;"
              "t M 8 3.5 C 7.2 4.4 8.8 5.1 8 6;t M 11.5 3.5 C 10.7 4.4 12.3 5.1 11.5 6",
    "gauge": f"s {A(12,13.5,8.5,180,360)};t M 3.5 13.5 L 3.5 16.5;t M 20.5 13.5 L 20.5 16.5;s M 12 14.5 L 15.5 9.5;f {O(12,14.5,1.8)}",
    "leaf": f"b {LEAF};s {LEAF};s M 5 19 C 8 14.5 11 11.5 15 9",
    "zap": f"b {BOLT};s {BOLT}",
    "lock": f"s {R(4.5,10.5,15,10.5,3.5)};s {SHIELD_LOCK_SHACKLE};t M 12 14.5 L 12 17",
    "unlock": f"s {R(4.5,10.5,15,10.5,3.5)};s M 8 10.5 L 8 7.5 C 8 5.3 9.8 3.5 12 3.5 C 13.6 3.5 15 4.4 15.6 5.8;t M 12 14.5 L 12 17",
    "power": f"s {A(12,12.5,8,-55,235)};t M 12 3.5 L 12 11",
    "logout": "s M 10 20 L 6.5 20 C 5.1 20 4 18.9 4 17.5 L 4 6.5 C 4 5.1 5.1 4 6.5 4 L 10 4;"
              "t M 10 12 L 20 12;s M 16.5 8 L 20.5 12 L 16.5 16",
    "restart": f"s {A(12,12,8,-60,250)};s M 16 2.8 L 16 6.2 L 19.3 6.2",
    "refresh": f"s {A(12,12,8,-160,-20)};s M 18.6 3.8 L 19.6 7.4 L 16 8.3;t {A(12,12,8,20,160)};t M 5.4 20.2 L 4.4 16.6 L 8 15.7",
    "history": f"s {A(12,12,8.5,-200,90)};s M 3.5 4.5 L 3.5 9 L 8 9;t M 12 7.5 L 12 12 L 15 14",
    "suspend": f"s {MOON};t {SPARK(17.5,6,2.2)}",
    "moon": f"b {MOON};s {MOON}",
    "nightlight": f"s {MOON};f {SPARK(17,5.5,2.4)};t {O(20.5,10.5,0.9)}",
    "sun": f"s {O(12,12,4.2)};{SUN_RAYS_SOFT}",
    "sun-dim": f"t {O(12,12,4.2)};" + ";".join(
        "t " + O(12 + 8 * math.cos(math.radians(a)), 12 + 8 * math.sin(math.radians(a)), 0.35) for a in range(0, 360, 45)),
    "mic": f"s {MIC};t {MIC_ARC};t M 12 18 L 12 21",
    "mic-off": f"s {MIC};t {MIC_ARC};t M 12 18 L 12 21;s M 3.5 3.5 L 20.5 20.5",
    "mic-vocal": f"s {O(15.5,8.5,4.5)};t M 12.2 11.8 L 5 19 L 6.2 20.2 L 13.4 13",
    "speaker-on": f"s {R(6,2.5,12,19,3.5)};t {O(12,14.5,3)};f {O(12,7,1.2)}",
    "headphones": "s M 4 15 L 4 12 C 4 7.6 7.6 4 12 4 C 16.4 4 20 7.6 20 12 L 20 15;"
                  f"b {R(4,13.5,4.5,6.5,2)};s {R(4,13.5,4.5,6.5,2)};b {R(15.5,13.5,4.5,6.5,2)};s {R(15.5,13.5,4.5,6.5,2)}",
    "audio-lines": "t M 4 10 L 4 14;s M 8 6.5 L 8 17.5;t M 12 3.5 L 12 20.5;s M 16 8 L 16 16;t M 20 10.5 L 20 13.5",
    "disc-3": f"s {O(12,12,9)};t {O(12,12,3)};t {A(12,12,6,200,260)};t {A(12,12,6,20,80)}",
    # ---- media
    "play": f"F {PLAY}",
    "pause": f"F {R(6,4.5,4,15,1.6)};F {R(14,4.5,4,15,1.6)}",
    "next": "F M 5 6.4 C 5 5.5 6 5 6.7 5.5 L 14.5 11 C 15.2 11.5 15.2 12.5 14.5 13 L 6.7 18.5 C 6 19 5 18.5 5 17.6 Z;t M 19 5.5 L 19 18.5",
    "previous": "F M 19 6.4 C 19 5.5 18 5 17.3 5.5 L 9.5 11 C 8.8 11.5 8.8 12.5 9.5 13 L 17.3 18.5 C 18 19 19 18.5 19 17.6 Z;t M 5 5.5 L 5 18.5",
    # ---- arrows and marks
    "chevron-down": "s M 6.5 9.5 L 12 15 L 17.5 9.5",
    "chevron-up": "s M 6.5 14.5 L 12 9 L 17.5 14.5",
    "chevron-left": "s M 14.5 6.5 L 9 12 L 14.5 17.5",
    "chevron-right": "s M 9.5 6.5 L 15 12 L 9.5 17.5",
    "check": "s M 5 12.5 L 10 17.5 L 19 6.5",
    "close": "s M 6.5 6.5 L 17.5 17.5;s M 17.5 6.5 L 6.5 17.5",
    "plus": "s M 12 5 L 12 19;s M 5 12 L 19 12",
    "minus": "s M 5 12 L 19 12",
    "circle": f"s {O(12,12,8.5)}",
    "circle-dot": f"s {O(12,12,8.5)};f {O(12,12,2.4)}",
    "circle-x": f"s {O(12,12,8.5)};t M 9.2 9.2 L 14.8 14.8;t M 14.8 9.2 L 9.2 14.8",
    "info": f"s {O(12,12,8.5)};t M 12 11 L 12 16.2;f {O(12,7.9,1.2)}",
    "download": "t M 4 15.5 L 4 17.5 C 4 18.9 5.1 20 6.5 20 L 17.5 20 C 18.9 20 20 18.9 20 17.5 L 20 15.5;"
                "s M 12 4 L 12 15;s M 7.5 10.5 L 12 15 L 16.5 10.5",
    "external-link": "s M 10 5 L 7 5 C 5.6 5 4.5 6.1 4.5 7.5 L 4.5 17 C 4.5 18.4 5.6 19.5 7 19.5 L 16.5 19.5 C 17.9 19.5 19 18.4 19 17 L 19 14;"
                     "t M 19.5 4.5 L 11 13;s M 14 4.5 L 19.5 4.5 L 19.5 10",
    "send": "s M 20.5 3.5 L 3.8 10 C 3.1 10.3 3.1 11.2 3.8 11.5 L 10.5 13.5 L 12.5 20.2 C 12.8 20.9 13.7 20.9 14 20.2 Z;t M 20.5 3.5 L 10.5 13.5",
    "move": "t M 12 4 L 12 20;t M 4 12 L 20 12;s M 9.5 6.5 L 12 4 L 14.5 6.5;s M 9.5 17.5 L 12 20 L 14.5 17.5;s M 6.5 9.5 L 4 12 L 6.5 14.5;s M 17.5 9.5 L 20 12 L 17.5 14.5",
    "crosshair": f"s {O(12,12,8)};t M 12 2.5 L 12 7;t M 12 17 L 12 21.5;t M 2.5 12 L 7 12;t M 17 12 L 21.5 12;f {O(12,12,1.3)}",
    "pin": "s M 9 3.5 L 15 3.5;s M 10 3.5 L 10 9 L 6.5 13.5 L 17.5 13.5 L 14 9 L 14 3.5;t M 12 13.5 L 12 20.5",
    # ---- things
    "gear": f"s {gear(12,12,9,6.9,8)};t {O(12,12,2.8)}",
    "edit": f"s {PEN};t M 13.5 6.5 L 17.5 10.5;t M 13 20 L 19.5 20",
    "pencil": f"s {PEN};t M 13.5 6.5 L 17.5 10.5",
    "search": f"s {O(11,11,6.5)};t M 16 16 L 20 20;t {A(11,11,3.6,190,260)}",
    "trash": f"s {TRASH_BODY};s M 4 7.5 L 20 7.5;s M 9 7.5 L 9 5.5 C 9 4.4 9.9 3.5 11 3.5 L 13 3.5 C 14.1 3.5 15 4.4 15 5.5 L 15 7.5;"
             "t M 10.2 11 L 10.2 16.5;t M 13.8 11 L 13.8 16.5",
    "folder": f"s {FOLDER};t M 3 10 L 21 10",
    "folder-new": f"s {FOLDER};t M 12 10.5 L 12 16;t M 9.2 13.2 L 14.8 13.2",
    "file": f"s {FILE};t M 13.5 3 L 13.5 7 C 13.5 7.8 14.1 8.5 15 8.5 L 19 8.5;t M 8 13 L 15.5 13;t M 8 16.5 L 12.5 16.5",
    "clipboard": f"s {CLIP};s {R(9,3,6,4,1.5)};t M 8.5 12 L 15.5 12;t M 8.5 16 L 13 16",
    "paste": f"s {CLIP};s {R(9,3,6,4,1.5)};t M 12 10.5 L 12 17;t M 9.2 14.3 L 12 17 L 14.8 14.3",
    "copy": f"s {R(8.5,8.5,12,12,3)};t M 15.5 8.5 L 15.5 6.5 C 15.5 4.8 14.2 3.5 12.5 3.5 L 6.5 3.5 C 4.8 3.5 3.5 4.8 3.5 6.5 L 3.5 12.5 C 3.5 14.2 4.8 15.5 6.5 15.5 L 8.5 15.5",
    "image": f"s {R(3,4,18,16,3.5)};t M 3.5 17.5 L 8.5 12.5 C 9.3 11.7 10.6 11.7 11.4 12.5 L 18.5 19.5;t M 14 15 L 15.6 13.4 C 16.4 12.6 17.6 12.6 18.4 13.4 L 20.5 15.5;f {O(15.5,8.8,1.6)}",
    "wallpaper": f"s {R(3,4,18,16,3.5)};t M 3.5 17 L 9 11.5 L 15 17.5;t M 13 15.5 L 16 12.5 L 20.5 17;t {O(15.5,8.5,1.6)}",
    "camera": f"s M 3.5 9.5 C 3.5 8.1 4.6 7 6 7 L 7.6 7 L 8.9 4.9 C 9.2 4.4 9.7 4 10.3 4 L 13.7 4 C 14.3 4 14.8 4.4 15.1 4.9 L 16.4 7 L 18 7 C 19.4 7 20.5 8.1 20.5 9.5 L 20.5 17.5 C 20.5 18.9 19.4 20 18 20 L 6 20 C 4.6 20 3.5 18.9 3.5 17.5 Z;t {O(12,13.3,3.6)}",
    "video": f"s {R(2.5,6,13,12,3)};t M 15.5 10.5 L 20 7.8 C 20.7 7.4 21.5 7.9 21.5 8.7 L 21.5 15.3 C 21.5 16.1 20.7 16.6 20 16.2 L 15.5 13.5",
    "screenshot": "s M 3.5 8 L 3.5 6.5 C 3.5 4.8 4.8 3.5 6.5 3.5 L 8 3.5;s M 16 3.5 L 17.5 3.5 C 19.2 3.5 20.5 4.8 20.5 6.5 L 20.5 8;"
                  "s M 20.5 16 L 20.5 17.5 C 20.5 19.2 19.2 20.5 17.5 20.5 L 16 20.5;s M 8 20.5 L 6.5 20.5 C 4.8 20.5 3.5 19.2 3.5 17.5 L 3.5 16;"
                  f"t {O(12,12,3.5)}",
    "area": "s M 3.5 8 L 3.5 6.5 C 3.5 4.8 4.8 3.5 6.5 3.5 L 8 3.5;s M 16 3.5 L 17.5 3.5 C 19.2 3.5 20.5 4.8 20.5 6.5 L 20.5 8;"
            "s M 20.5 16 L 20.5 17.5 C 20.5 19.2 19.2 20.5 17.5 20.5 L 16 20.5;s M 8 20.5 L 6.5 20.5 C 4.8 20.5 3.5 19.2 3.5 17.5 L 3.5 16;"
            "t M 11 3.5 L 13 3.5;t M 11 20.5 L 13 20.5;t M 3.5 11 L 3.5 13;t M 20.5 11 L 20.5 13",
    "timer": f"s {O(12,13.5,7.5)};t M 12 13.5 L 12 9.5;s M 9.5 2.8 L 14.5 2.8;t M 18.2 6.8 L 19.5 5.5",
    "clock": f"s {O(12,12,8.5)};t M 12 7.5 L 12 12 L 15 14",
    "star": f"b {star(12,12.3,9,4.2)};s {star(12,12.3,9,4.2)}",
    "star-off": f"t {star(12,12.3,9,4.2)};s M 3.5 3.5 L 20.5 20.5",
    "sparkles": f"s {SPARK(10,10,6.5)};b {SPARK(18,17.5,3.2)};t {SPARK(18,17.5,3.2)}",
    "palette": "s M 12 3.5 C 7.3 3.5 3.5 7.3 3.5 12 C 3.5 16.7 7.3 20.5 12 20.5 C 13.1 20.5 13.6 19.8 13.6 19 C 13.6 18.2 13 17.8 13 17 C 13 16.2 13.6 15.5 14.5 15.5 L 16.5 15.5 C 18.7 15.5 20.5 13.7 20.5 11.5 C 20.5 7.1 16.7 3.5 12 3.5 Z;"
               f"t {O(8,11,1.3)};f {O(10.5,7.5,1.3)};t {O(15,7.8,1.3)}",
    "gamepad-2": "s M 7.5 7 L 16.5 7 C 19.3 7 21.3 9.4 20.9 12.2 L 20.4 15.6 C 20.1 17.5 17.6 18.2 16.3 16.7 L 15 15.2 L 9 15.2 L 7.7 16.7 C 6.4 18.2 3.9 17.5 3.6 15.6 L 3.1 12.2 C 2.7 9.4 4.7 7 7.5 7 Z;"
                 f"t M 7 11 L 10 11;t M 8.5 9.5 L 8.5 12.5;f {O(15,10,1)};f {O(17,12.3,1)}",
    "keyboard": f"s {R(2.5,5.5,19,13,3)};t M 6.5 9.5 L 7 9.5;t M 10 9.5 L 10.5 9.5;t M 13.5 9.5 L 14 9.5;t M 17 9.5 L 17.5 9.5;s M 8 14.5 L 16 14.5",
    "mouse": f"s {R(6,3,12,18,6)};t M 12 7 L 12 10",
    "message-square": f"s {CHAT};t M 8.5 9.5 L 15.5 9.5;t M 8.5 12.8 L 13 12.8",
    "usb": f"s M 12 3 L 12 17;s {O(12,18.5,2)};t M 12 13.5 L 7.5 11 L 7.5 8.5;t M 12 11.5 L 16.5 9 L 16.5 7;t {R(6.3,6.3,2.4,2.4,0.4)};t {O(16.5,6.2,1.2)};s M 10 5 L 12 3 L 14 5",
    "eye": f"s {EYE};t {O(12,12,3.2)}",
    "eye-off": f"t {EYE};t {O(12,12,3.2)};s M 4 4 L 20 20",
    "house": f"s {HOUSE};t M 9.5 20.5 L 9.5 15.5 C 9.5 14.7 10.2 14 11 14 L 13 14 C 13.8 14 14.5 14.7 14.5 15.5 L 14.5 20.5",
    "pointer": f"s {POINTER};t M 13.3 13.3 L 18 18",
    # ---- screens and windows
    "monitor": f"s {MONITOR};t M 8.5 20.5 L 15.5 20.5;t M 12 16.5 L 12 20.5",
    "smartphone": f"s {PHONE};t M 10.5 18.5 L 13.5 18.5",
    "tablet-smartphone": f"s {R(3,3.5,10.5,16,2.8)};t {R(15.5,9,5.5,10.5,2)}",
    "monitor-smartphone": f"s M 15.5 6 L 15.5 5.5 C 15.5 4.4 14.6 3.5 13.5 3.5 L 5 3.5 C 3.6 3.5 2.5 4.6 2.5 6 L 2.5 12.5 C 2.5 13.9 3.6 15 5 15 L 12 15;t M 6 20 L 12 20;t M 9 15 L 9 20;s {R(15,8,6.5,12.5,2)}",
    "window": f"s {R(3,4,18,16,3.5)};t M 3 9 L 21 9;f {O(6.5,6.5,0.9)};f {O(9.3,6.5,0.9)}",
    "terminal": f"s {R(3,4,18,16,3.5)};s M 7.5 9.5 L 10.5 12.5 L 7.5 15.5;t M 13 15.5 L 16.5 15.5",
    "apps": f"s {R(3.5,3.5,7,7,2.2)};t {R(13.5,3.5,7,7,2.2)};t {R(3.5,13.5,7,7,2.2)};s {R(13.5,13.5,7,7,2.2)}",
    "layout-template": f"s {R(3.5,3.5,17,7,2.2)};t {R(3.5,13.5,7,7,2.2)};t {R(13.5,13.5,7,7,2.2)}",
    "layers": "s M 12 3.5 L 20.5 8 L 12 12.5 L 3.5 8 Z;t M 3.5 12 L 12 16.5 L 20.5 12;t M 3.5 16 L 12 20.5 L 20.5 16",
}

ALIASES = {
    "settings": "gear", "system": "gear", "home": "house", "display": "monitor", "desktop": "monitor",
    "log-out": "logout", "tray": "layers", "square-terminal": "terminal", "open": "external-link",
    "x": "close", "skip-forward": "next", "skip-back": "previous", "prev": "previous",
    "layout-grid": "apps", "mouse-pointer-2": "pointer", "plane": "airplane", "phone": "smartphone",
    "sun-moon": "moon", "moon-star": "nightlight", "circle-check": "check", "image-x-generic": "image",
    "app-window": "window", "refresh-cw": "refresh", "rotate-cw": "restart", "rotate-ccw-clock": "history",
    "gauge-power-saver": "leaf", "gauge-performance": "zap", "gauge-balanced": "gauge", "scan": "screenshot",
    "square-dashed": "area", "folder-plus": "folder-new", "clipboard-paste": "paste", "speaker": "speaker-on",
    "volume-x": "speaker-muted", "volume": "speaker-1", "volume-1": "speaker-2", "volume-2": "speaker-3",
    "wifi": "wifi-4", "wifi-off": "offline", "ethernet-port": "wired", "battery": "battery-100",
}


def level_icons():
    """Wi-Fi, speaker, wired: icons with levels, as ops (the battery is drawn in code)."""
    out = {}
    # Wi-Fi: a dot and three arcs; the lit ones in the full tone.
    def wifi(lit, dot):
        ops = [f"{'f' if dot else 'b'} {O(12, 18.6, 1.5)}"]
        for i, r in enumerate((4.6, 8.6, 12.6)):
            ops.append(f"{'s' if i < lit else 't'} {A(12, 18.6, r, -138, -42)}")
        return ";".join(ops)
    for lv in range(5):
        out[f"wifi-{lv}"] = wifi(max(0, lv - 1), lv > 0)
    out["offline"] = wifi(0, False) + ";s M 4 4 L 20 20"
    out["wired"] = f"s {R(8.5,3,7,6,1.8)};t M 12 9 L 12 14;s {R(3,14,7,6.5,1.8)};s {R(14,14,7,6.5,1.8)};t M 6.5 14 L 6.5 12 L 17.5 12 L 17.5 14"
    # Speaker: an outlined body with a soft fill, two waves lit by the volume.
    body = f"b {SPEAKER};s {SPEAKER}"
    for lv in range(1, 4):
        lit = 1 if lv == 1 else 2
        out[f"speaker-{lv}"] = ";".join([body] + [
            f"{'s' if i < lit else 't'} {A(13, 12, r, -45, 45)}" for i, r in enumerate((3.6, 7.2))])
    out["speaker-0"] = out["speaker-muted"] = f"{body};s M 16 9.6 L 20.6 14.2;s M 20.6 9.6 L 16 14.2"
    return out


def all_icons():
    d = dict(ICONS)
    d.update(level_icons())
    return d


def header():
    icons = all_icons()
    lines = [
        "// Arqen's icon pack (generated by tools/arqen_icons.py: edit that, then",
        "// run it). Two-tone line icons on a 24 px grid: the outline in the full",
        "// tone, a detail in the soft tone, round ends. See the script for the",
        "// format. Icons not drawn here fall back to Lucide's, in the same line.",
        "#pragma once",
        "",
        "#include <cairo.h>",
        "",
        "#include <cmath>",
        "#include <cstdlib>",
        "#include <cstring>",
        "#include <string>",
        "",
        "namespace arqicons {",
        "",
        "constexpr double kSoft = 0.40;   // the soft tone: the colour at 40%",
        "constexpr double kLine = 1.85;   // line width on the 24 px grid",
        "",
        "struct Icon {",
        "\tconst char *name;",
        "\tconst char *ops;",
        "};",
        "",
        "// Sorted by name (binary search).",
        "inline constexpr Icon kIcons[] = {",
    ]
    for k in sorted(icons):
        lines.append(f'\t{{"{k}", "{icons[k]}"}},')
    lines += ["};", "", "// Other names for the icons above.", "inline constexpr Icon kAliases[] = {"]
    for k in sorted(ALIASES):
        lines.append(f'\t{{"{k}", "{ALIASES[k]}"}},')
    lines += ["};", "", DRAW_CPP, "} // namespace arqicons", ""]
    return "\n".join(lines)


DRAW_CPP = r"""template <size_t N>
inline const char *lookup(const Icon (&table)[N], const char *name) {
	size_t lo = 0, hi = N;
	while (lo < hi) {
		const size_t mid = (lo + hi) / 2;
		const int c = std::strcmp(table[mid].name, name);
		if (c == 0) return table[mid].ops;
		if (c < 0) lo = mid + 1;
		else hi = mid;
	}
	return nullptr;
}

// The ops for `name` (or one of its other names), or null.
inline const char *find(const std::string &name) {
	if (const char *ops = lookup(kIcons, name.c_str())) return ops;
	if (const char *real = lookup(kAliases, name.c_str())) return lookup(kIcons, real);
	return nullptr;
}

// Draws `ops` into the square (x, y, size) in colour (r, g, b, a).
inline void draw_ops(cairo_t *cr, const char *ops, double x, double y, double size,
		double r, double g, double b, double a, double line = kLine) {
	cairo_save(cr);
	cairo_translate(cr, x, y);
	cairo_scale(cr, size / 24.0, size / 24.0);
	cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
	cairo_set_line_join(cr, CAIRO_LINE_JOIN_ROUND);
	const char *p = ops;
	auto number = [&p]() {
		char *end = nullptr;
		const double v = std::strtod(p, &end);
		p = end;
		return v;
	};
	while (*p) {
		while (*p == ' ' || *p == ';') p++;
		if (!*p) break;
		const char layer = *p++;
		const bool soft = layer == 'b' || layer == 't' || layer == 'B';
		const bool fill = layer == 'b' || layer == 'f' || layer == 'B' || layer == 'F';
		const bool round_fill = layer == 'B' || layer == 'F';
		cairo_new_path(cr);
		while (*p && *p != ';') {
			const char op = *p++;
			switch (op) {
			case 'M': { const double px = number(), py = number(); cairo_move_to(cr, px, py); break; }
			case 'L': { const double px = number(), py = number(); cairo_line_to(cr, px, py); break; }
			case 'C': {
				const double x1 = number(), y1 = number(), x2 = number(), y2 = number(), px = number(), py = number();
				cairo_curve_to(cr, x1, y1, x2, y2, px, py);
				break;
			}
			case 'Z': cairo_close_path(cr); break;
			case 'O': {
				const double cx = number(), cy = number(), rr = number();
				cairo_new_sub_path(cr);
				cairo_arc(cr, cx, cy, rr, 0, 2 * M_PI);
				cairo_close_path(cr);
				break;
			}
			case 'A':
			case 'a': {
				const double cx = number(), cy = number(), rr = number(), from = number(), to = number();
				if (op == 'A') cairo_new_sub_path(cr);
				cairo_arc(cr, cx, cy, rr, from * M_PI / 180, to * M_PI / 180);
				break;
			}
			case 'R': {
				const double rx = number(), ry = number(), w = number(), h = number();
				double rr = number();
				rr = std::fmin(rr, std::fmin(w, h) / 2);
				cairo_new_sub_path(cr);
				cairo_arc(cr, rx + w - rr, ry + rr, rr, -M_PI / 2, 0);
				cairo_arc(cr, rx + w - rr, ry + h - rr, rr, 0, M_PI / 2);
				cairo_arc(cr, rx + rr, ry + h - rr, rr, M_PI / 2, M_PI);
				cairo_arc(cr, rx + rr, ry + rr, rr, M_PI, 3 * M_PI / 2);
				cairo_close_path(cr);
				break;
			}
			default: break;   // spaces
			}
		}
		cairo_set_source_rgba(cr, r, g, b, soft ? a * kSoft : a);
		if (round_fill) {
			// Filled, with its corners rounded by a line in the same colour
			// (one group, so where they overlap isn't darker).
			cairo_path_t *path = cairo_copy_path(cr);
			cairo_push_group(cr);
			cairo_set_source_rgba(cr, r, g, b, 1.0);
			cairo_fill_preserve(cr);
			cairo_set_line_width(cr, line);
			cairo_stroke(cr);
			cairo_pop_group_to_source(cr);
			cairo_paint_with_alpha(cr, soft ? a * kSoft : a);
			cairo_path_destroy(path);
		} else if (fill) {
			cairo_fill(cr);
		} else {
			cairo_set_line_width(cr, line);
			cairo_stroke(cr);
		}
	}
	cairo_restore(cr);
}
"""


def preview(path):
    import cairo
    icons = all_icons()
    names = sorted(icons)
    cols = 12
    cell = 64
    rows = (len(names) + cols - 1) // cols
    W, H = 2 * (cols * cell + 20), rows * cell + 20
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H)
    cr = cairo.Context(surf)
    cr.set_source_rgb(0.08, 0.08, 0.1)
    cr.rectangle(0, 0, W // 2, H)
    cr.fill()
    cr.set_source_rgb(0.96, 0.96, 0.97)
    cr.rectangle(W // 2, 0, W // 2, H)
    cr.fill()
    for half, col in ((0, (0.96, 0.96, 0.97)), (1, (0.1, 0.1, 0.13))):
        for i, name in enumerate(names):
            x = half * (W // 2) + 10 + (i % cols) * cell
            y = 10 + (i // cols) * cell
            draw_py(cr, icons[name], x + 4, y + 4, 32, col)
            draw_py(cr, icons[name], x + 40, y + 12, 16, col)
            cr.set_source_rgba(*col, 0.5)
            cr.select_font_face("Sans")
            cr.set_font_size(8)
            cr.move_to(x + 2, y + 50)
            cr.show_text(name[:16])
    surf.write_to_png(path)


def draw_py(cr, ops, x, y, size, col, line=1.85):
    import re
    cr.save()
    cr.translate(x, y)
    cr.scale(size / 24, size / 24)
    cr.set_line_cap(1)
    cr.set_line_join(1)
    for el in [e.strip() for e in ops.split(";") if e.strip()]:
        layer, body = el[0], el[1:]
        toks = re.findall(r"[A-Za-z]|-?[0-9.]+", body)
        cr.new_path()
        i = 0
        def num():
            nonlocal i
            v = float(toks[i]); i += 1; return v
        while i < len(toks):
            op = toks[i]; i += 1
            if op == "M": cr.move_to(num(), num())
            elif op == "L": cr.line_to(num(), num())
            elif op == "C": cr.curve_to(num(), num(), num(), num(), num(), num())
            elif op == "Z": cr.close_path()
            elif op == "O":
                cx, cy, r = num(), num(), num(); cr.new_sub_path(); cr.arc(cx, cy, r, 0, 2 * math.pi); cr.close_path()
            elif op in "Aa":
                cx, cy, r, a0, a1 = num(), num(), num(), num(), num()
                if op == "A": cr.new_sub_path()
                cr.arc(cx, cy, r, math.radians(a0), math.radians(a1))
            elif op == "R":
                rx, ry, w, h, rr = num(), num(), num(), num(), num(); rr = min(rr, min(w, h) / 2)
                cr.new_sub_path()
                cr.arc(rx + w - rr, ry + rr, rr, -math.pi / 2, 0)
                cr.arc(rx + w - rr, ry + h - rr, rr, 0, math.pi / 2)
                cr.arc(rx + rr, ry + h - rr, rr, math.pi / 2, math.pi)
                cr.arc(rx + rr, ry + rr, rr, math.pi, 3 * math.pi / 2)
                cr.close_path()
        soft = layer in "btB"
        a = 0.4 if soft else 1.0
        if layer in "BF":
            cr.push_group(); cr.set_source_rgb(*col); cr.fill_preserve(); cr.set_line_width(line); cr.stroke()
            cr.pop_group_to_source(); cr.paint_with_alpha(a)
        elif layer in "bf":
            cr.set_source_rgba(*col, a); cr.fill()
        else:
            cr.set_source_rgba(*col, a); cr.set_line_width(line); cr.stroke()
    cr.restore()


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--preview":
        preview(sys.argv[2])
    else:
        import os
        out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "arqen_icons.hpp")
        with open(out, "w") as f:
            f.write(header())
        print("wrote", os.path.normpath(out), len(all_icons()), "icons")
