// The control centre's System monitor tile: how busy the CPU, the graphics
// (the built-in one and a separate card) and the memory are. Read on a
// thread of its own, every two seconds, only while the tile is on screen.
#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <mutex>
#include <string>
#include <thread>

namespace arqen {

struct SysSample {
	double cpu = -1;          // 0..1, -1: not known yet
	double igpu = -1;         // the built-in graphics (Intel, or an AMD APU)
	double gpu = -1;          // a separate card (NVIDIA, AMD)
	bool gpu_asleep = false;  // the card is powered down (a laptop's, idle): not woken to ask
	double ram = -1, swap = -1;
	double ram_used_gb = 0, ram_total_gb = 0, swap_used_gb = 0, swap_total_gb = 0;
	bool has_igpu = false, has_gpu = false, has_swap = false;
	std::string igpu_name, gpu_name;
};

class SysMon {
public:
	SysMon();
	~SysMon();
	SysMon(const SysMon &) = delete;
	SysMon &operator=(const SysMon &) = delete;

	// While something shows the readings; they stop when nobody looks.
	void want(bool on);
	SysSample sample() const;

private:
	void run();
	void read(SysSample &s);

	mutable std::mutex mutex_;
	std::condition_variable cv_;
	SysSample last_;
	std::thread thread_;
	bool wanted_ = false, quit_ = false;

	// Between readings (all on the worker thread).
	uint64_t cpu_idle_ = 0, cpu_total_ = 0;
	double rc6_ms_ = -1, rc6_at_ = 0;
	std::string intel_rc6_, amd_igpu_busy_, amd_gpu_busy_, nvidia_pci_;
	bool probed_ = false;
	void probe(SysSample &s);
	double nvidia_busy(bool &asleep);
	void *nvml_ = nullptr;   // libnvidia-ml, once loaded
};

} // namespace arqen
