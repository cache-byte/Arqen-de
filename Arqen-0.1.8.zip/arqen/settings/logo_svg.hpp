// Arqen's logo and the Settings icon (data/icons/*.svg), built in so they show
// before Arqen is installed too. Keep in step with the files.
#pragma once

inline const char *kArqenLogoSvg = R"svg(<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <!-- Arqen: an arch with its crossbar (a rounded "A", and a doorway) on a
       rounded square, as on the app menu button.
       Plain shapes only, so every SVG reader draws it the same. Arqen Settings
       draws it in your accent colour (it swaps the two stop colours). -->
  <defs>
    <linearGradient id="tile" x1="0" y1="1" x2="1" y2="0">
      <stop offset="0" stop-color="#e8459a"/>
      <stop offset="1" stop-color="#9e2f69"/>
    </linearGradient>
  </defs>
  <rect x="8" y="8" width="112" height="112" rx="30" fill="url(#tile)"/>
  <g fill="none" stroke="#ffffff" stroke-width="9.24" stroke-linecap="round" stroke-linejoin="round">
    <path d="M45.52 84.9 L45.52 60.3 A18.48 18.48 0 0 1 82.48 60.3 L82.48 84.9"/>
    <path d="M45.52 71.4 L82.48 71.4"/>
  </g>
</svg>
)svg";

inline const char *kSettingsIconSvg = R"svg(<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <!-- Arqen Settings: Arqen's rounded square with a cog.
       Plain shapes only, so every SVG reader draws it the same. Arqen Settings
       draws it in your accent colour (it swaps the two stop colours). -->
  <defs>
    <linearGradient id="tile" x1="0" y1="1" x2="1" y2="0">
      <stop offset="0" stop-color="#e8459a"/>
      <stop offset="1" stop-color="#9e2f69"/>
    </linearGradient>
  </defs>
  <rect x="8" y="8" width="112" height="112" rx="30" fill="url(#tile)"/>
  <g transform="translate(32.8 32.8) scale(2.6)" fill="none" stroke="#ffffff" stroke-width="2"
     stroke-linecap="round" stroke-linejoin="round">
    <path d="M 9.671 4.136 C 9.785 2.935 10.794 2.017 12 2.017 C 13.207 2.017 14.216 2.935 14.33 4.136 C 14.397 4.896 14.831 5.575 15.491 5.957 C 16.152 6.338 16.957 6.373 17.649 6.051 C 18.745 5.553 20.04 5.969 20.643 7.011 C 21.245 8.054 20.958 9.383 19.979 10.084 C 19.355 10.522 18.983 11.237 18.983 11.999 C 18.983 12.762 19.355 13.477 19.979 13.915 C 20.958 14.616 21.245 15.945 20.643 16.988 C 20.04 18.03 18.745 18.446 17.649 17.948 C 16.957 17.626 16.152 17.661 15.491 18.042 C 14.831 18.424 14.397 19.103 14.33 19.863 C 14.216 21.064 13.207 21.982 12.001 21.982 C 10.794 21.982 9.785 21.064 9.671 19.863 C 9.604 19.103 9.17 18.423 8.509 18.042 C 7.848 17.66 7.043 17.625 6.351 17.948 C 5.255 18.446 3.96 18.03 3.357 16.988 C 2.755 15.945 3.042 14.616 4.021 13.915 C 4.645 13.477 5.017 12.762 5.017 11.999 C 5.017 11.237 4.645 10.522 4.021 10.084 C 3.044 9.383 2.757 8.054 3.359 7.013 C 3.961 5.971 5.254 5.555 6.35 6.051 C 7.042 6.373 7.847 6.338 8.508 5.957 C 9.168 5.575 9.602 4.896 9.669 4.136"/>
    <circle cx="12" cy="12" r="3"/>
  </g>
</svg>
)svg";
