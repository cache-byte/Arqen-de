#include "launcher.hpp"

#include <sys/stat.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <linux/input-event-codes.h>
#include <pwd.h>
#include <unistd.h>

#include <ctime>
#include <filesystem>
#include <fstream>
#include <sstream>

#include "desktop.hpp"
#include "draw.hpp"
#include "glyphs.hpp"
#include "overview.hpp"
#include "panel.hpp"
#include "popover.hpp"
#include "ccentre.hpp"
#include "system.hpp"

namespace arqen {

namespace {

constexpr int kWidth = 700;
constexpr int kHeight = 620;
constexpr int kPad = 20;
constexpr int kSearchHeight = 42;
constexpr int kListTop = kPad + kSearchHeight + 18;
constexpr int kGutter = 24;         // between the home's two columns
constexpr int kWidgetH = 104;       // a widget card
constexpr int kRowHeight = 44;
constexpr int kFooterHeight = 12;   // (just a margin: you and the buttons are in the header)
constexpr int kPinH = 80;           // pinned apps: icons with names, four to a row
constexpr int kPinCols = 4;
constexpr int kPinPage = 3 * kPinCols;   // pinned apps on a page
constexpr int kMaxFiles = 12;

// Settings pages the search finds, by the words you'd use for them.
struct SettingsPage {
	const char *page, *title, *words;
};
const SettingsPage kSettingsPages[] = {
	{"appearance", "Appearance", "theme dark light accent colour color wallpaper background font look style corners"},
	{"panels", "Panels & dock", "panel taskbar dock bar top bottom widgets clock tray"},
	{"controlcentre", "Control centre", "control centre center quick settings tiles"},
	{"desktop", "Desktop & clipboard", "desktop icons clipboard history"},
	{"lockscreen", "Lock screen", "lock screen password idle"},
	{"animations", "Animations", "animations motion effects speed"},
	{"displays", "Displays", "display monitor screen resolution scale refresh rate hdmi tv night light"},
	{"power", "Power & battery", "power battery sleep suspend hibernate performance saver lid"},
	{"notifications", "Notifications", "notifications do not disturb dnd alerts"},
	{"osd", "On-screen display", "osd volume popup on-screen"},
	{"datetime", "Date & time", "date time clock timezone calendar 24-hour"},
	{"language", "Language & region", "language region locale input format"},
	{"windows", "Windows", "windows title bar snapping tiling focus"},
	{"workspaces", "Workspaces", "workspaces virtual desktops overview"},
	{"keyboard", "Keyboard", "keyboard shortcuts layout keys typing repeat"},
	{"pointer", "Mouse & touchpad", "mouse touchpad pointer cursor scrolling tap speed"},
	{"media", "Media & lyrics", "media music lyrics player sound output speakers"},
	{"screenshots", "Screenshots & recording", "screenshot screen recording capture"},
	{"apps", "Default apps", "default apps browser terminal file manager open with"},
	{"startup", "Startup apps", "startup autostart login apps"},
	{"about", "About & updates", "about update version system computer"},
};

// A sum typed into the search ("12*8", "(3+4)/2", "2^10", "15% of 80"
// isn't one): its answer, or nothing.
struct Sum {
	const std::string &t;
	size_t i = 0;
	bool bad = false;
	void ws() { while (i < t.size() && t[i] == ' ') i++; }
	bool eat(const char *op) {
		ws();
		const size_t n = std::strlen(op);
		if (t.compare(i, n, op) == 0) { i += n; return true; }
		return false;
	}
	double atom() {
		ws();
		if (eat("(")) {
			const double v = expr();
			if (!eat(")")) bad = true;
			return v;
		}
		if (eat("-")) return -atom();
		const size_t start = i;
		while (i < t.size() && (std::isdigit(static_cast<unsigned char>(t[i])) || t[i] == '.' || t[i] == ',')) i++;
		if (i == start) { bad = true; return 0; }
		std::string num = t.substr(start, i - start);
		num.erase(std::remove(num.begin(), num.end(), ','), num.end());
		double v = std::atof(num.c_str());
		if (eat("%")) v /= 100;
		return v;
	}
	double power() {
		const double b = atom();
		if (eat("^") || eat("**")) return std::pow(b, power());
		return b;
	}
	double term() {
		double v = power();
		for (;;) {
			if (eat("*") || eat("x") || eat("\xc3\x97")) v *= power();
			else if (eat("/") || eat("\xc3\xb7")) v /= power();
			else return v;
		}
	}
	double expr() {
		double v = term();
		for (;;) {
			if (eat("+")) v += term();
			else if (eat("-")) v -= term();
			else return v;
		}
	}
};

std::string sum_answer(const std::string &q) {
	bool digit = false, op = false;
	for (size_t k = 0; k < q.size(); k++) {
		const char c = q[k];
		if (std::isdigit(static_cast<unsigned char>(c))) digit = true;
		else if (std::strchr("+-*/^x%()., ", c) || static_cast<unsigned char>(c) >= 0x80) op = op || std::strchr("+-*/^x", c) || static_cast<unsigned char>(c) >= 0x80;
		else return "";
	}
	if (!digit || !op) return "";
	Sum p{q};
	const double v = p.expr();
	p.ws();
	if (p.bad || p.i != q.size() || !std::isfinite(v)) return "";
	char buf[64];
	if (std::fabs(v - std::round(v)) < 1e-9 && std::fabs(v) < 1e15) std::snprintf(buf, sizeof buf, "%.0f", v);
	else std::snprintf(buf, sizeof buf, "%.10g", v);
	return buf;
}

// "%2F" and friends back to characters (file:// addresses).
std::string url_decode(const std::string &u) {
	std::string out;
	for (size_t k = 0; k < u.size(); k++) {
		if (u[k] == '%' && k + 2 < u.size() && std::isxdigit(static_cast<unsigned char>(u[k + 1])) &&
				std::isxdigit(static_cast<unsigned char>(u[k + 2]))) {
			out += static_cast<char>(std::stoi(u.substr(k + 1, 2), nullptr, 16));
			k += 2;
		} else {
			out += u[k];
		}
	}
	return out;
}

// "2026-11-07T21:04:05.123Z" as "4 hours ago".
std::string ago(const std::string &iso) {
	tm t{};
	if (!strptime(iso.c_str(), "%Y-%m-%dT%H:%M:%S", &t)) return "";
	const long d = static_cast<long>(time(nullptr) - timegm(&t));
	if (d < 90) return "just now";
	if (d < 3600) return std::to_string(d / 60) + " min ago";
	if (d < 86400) return std::to_string(d / 3600) + (d / 3600 == 1 ? " hour ago" : " hours ago");
	if (d < 2 * 86400) return "yesterday";
	return std::to_string(d / 86400) + " days ago";
}

std::string up_for() {
	std::ifstream f("/proc/uptime");
	double sec = 0;
	f >> sec;
	const long m = static_cast<long>(sec) / 60, h = m / 60, d = h / 24;
	if (d > 0) return std::to_string(d) + "d " + std::to_string(h % 24) + "h";
	if (h > 0) return std::to_string(h) + " h " + std::to_string(m % 60) + " min";
	return std::to_string(m) + " min";
}

// An icon for a file, by what it is.
std::string file_icon(const std::string &name, bool dir) {
	if (dir) return "folder";
	std::string ext = name.substr(name.find_last_of('.') == std::string::npos ? name.size() : name.find_last_of('.') + 1);
	for (char &c : ext) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
	static const std::pair<const char *, const char *> kKinds[] = {
		{"png", "image-x-generic"}, {"jpg", "image-x-generic"}, {"jpeg", "image-x-generic"}, {"webp", "image-x-generic"},
		{"gif", "image-x-generic"}, {"svg", "image-x-generic"}, {"mp4", "video-x-generic"}, {"mkv", "video-x-generic"},
		{"webm", "video-x-generic"}, {"mov", "video-x-generic"}, {"mp3", "audio-x-generic"}, {"flac", "audio-x-generic"},
		{"ogg", "audio-x-generic"}, {"wav", "audio-x-generic"}, {"m4a", "audio-x-generic"}, {"pdf", "application-pdf"},
		{"zip", "package-x-generic"}, {"gz", "package-x-generic"}, {"xz", "package-x-generic"}, {"7z", "package-x-generic"},
		{"rar", "package-x-generic"}, {"doc", "x-office-document"}, {"docx", "x-office-document"},
		{"odt", "x-office-document"}, {"xls", "x-office-spreadsheet"}, {"xlsx", "x-office-spreadsheet"},
		{"ods", "x-office-spreadsheet"}, {"ppt", "x-office-presentation"}, {"pptx", "x-office-presentation"},
		{"odp", "x-office-presentation"}, {"sh", "text-x-script"}, {"py", "text-x-script"},
	};
	for (const auto &[e, icon] : kKinds) {
		if (ext == e) return icon;
	}
	return "text-x-generic";
}

std::string join(const std::vector<std::string> &v) {
	std::string out;
	for (const std::string &x : v) out += (out.empty() ? "" : ",") + x;
	return out;
}

std::string lower(std::string s) {
	for (char &c : s) {
		c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
	}
	return s;
}

} // namespace

Launcher::Launcher(Server *server)
		: server_(server), layer_(server->layer_menu, &tag),
		fx_(server->anim.get(), [this] { if (open_ || alpha_ > 0) redraw(); }),
		sel_(layer_, server->anim.get()), hl_(layer_, server->anim.get()) {
	layer_.set_enabled(false);
	fx_.set_speed(55);
	search_timer_ = wl_event_loop_add_timer(server->loop, &Launcher::handle_search_timer, this);
	if (const passwd *pw = getpwuid(getuid())) {
		std::string gecos = pw->pw_gecos ? pw->pw_gecos : "";
		gecos = gecos.substr(0, gecos.find(','));
		user_name_ = gecos.empty() ? pw->pw_name : gecos;
		if (!user_name_.empty()) user_name_[0] = static_cast<char>(std::toupper(user_name_[0]));
	}
}

// ---- The looks' measurements ----------------------------------------------------------------

void Launcher::measure() {
	if (!output_) return;
	const wlr_box u = output_->usable();
	// Two columns: pinned apps and widgets on the left, recent files and
	// every app on the right. Searching uses the whole width for the results.
	w_ = std::min(kWidth, u.width - 16);
	h_ = std::min(kHeight, u.height - 16);
	if (query_.empty()) pinned_ = static_cast<int>(favs_.size());   // (kept while searching)
	if (home()) {
		const int rows = std::clamp((pinned_ + kPinCols - 1) / kPinCols, 1, 3);
		favs_area_ = wlr_box{kPad, kListTop, left_width(), 28 + rows * kPinH};
		list_top_ = h_;
	} else {
		favs_area_ = wlr_box{};
		list_top_ = kListTop + (query_.empty() ? 36 : 0) + (calc_.empty() ? 0 : 70);
	}
}

int Launcher::left_width() const {
	return (w_ - 2 * kPad - kGutter) * 52 / 100;
}

int Launcher::max_first() const {
	return std::max(0, count() - visible_rows());
}

// ---- What's listed ---------------------------------------------------------------------

std::string Launcher::item_name(int i) const {
	if (is_file(i)) return file_of(i).name;
	if (is_setting(i)) return kSettingsPages[setting_of(i)].title;
	return server_->apps.apps()[static_cast<size_t>(app_of(i))].name;
}

std::string Launcher::item_icon(int i) const {
	if (is_file(i)) {
		const FileHit &f = file_of(i);
		return file_icon(f.name, f.dir);
	}
	if (is_setting(i)) return "preferences-system";
	return server_->apps.apps()[static_cast<size_t>(app_of(i))].icon;
}

// ---- Favourites ---------------------------------------------------------------------

int Launcher::pin_pages() const {
	return std::max(1, (static_cast<int>(favs_.size()) + kPinPage - 1) / kPinPage);
}

// `k`: the pinned app's index (it's on page k / kPinPage).
wlr_box Launcher::fav_box(int k) const {
	k %= kPinPage;
	const int cw = favs_area_.width / kPinCols;
	return wlr_box{favs_area_.x + (k % kPinCols) * cw, favs_area_.y + 28 + (k / kPinCols) * kPinH, cw, kPinH - 4};
}

int Launcher::fav_at(double px, double py) const {
	if (favs_.empty() || !home()) return -1;
	const int from = std::min(pin_page_, pin_pages() - 1) * kPinPage;
	const int to = std::min(static_cast<int>(favs_.size()), from + kPinPage);
	for (int k = from; k < to; k++) {
		const wlr_box b = fav_box(k);
		if (px >= b.x && px < b.x + b.width && py >= b.y && py < b.y + b.height) return k;
	}
	return -1;
}

void Launcher::toggle_favourite(const std::string &id) {
	std::vector<std::string> favs = server_->config.launcher_favorites;
	auto it = std::find(favs.begin(), favs.end(), id);
	if (it != favs.end()) favs.erase(it);
	else favs.push_back(id);
	server_->write_setting("launcher_favorites", join(favs));
	filter();
	redraw();
}

// An app's .desktop file (to put a copy of it on the desktop). Ids with a
// "-" may live in a subfolder ("kde-org.foo.desktop" = kde/org.foo.desktop).
static std::string desktop_file_of(const std::string &id) {
	namespace fs = std::filesystem;
	const char *home = std::getenv("HOME");
	std::vector<std::string> dirs;
	if (const char *d = std::getenv("XDG_DATA_HOME"); d && *d) dirs.push_back(std::string(d) + "/applications");
	if (home) {
		dirs.push_back(std::string(home) + "/.local/share/applications");
		dirs.push_back(std::string(home) + "/.local/share/flatpak/exports/share/applications");
	}
	std::string sys = std::getenv("XDG_DATA_DIRS") ? std::getenv("XDG_DATA_DIRS") : "/usr/local/share:/usr/share";
	std::stringstream ss(sys);
	for (std::string d; std::getline(ss, d, ':');) if (!d.empty()) dirs.push_back(d + "/applications");
	dirs.push_back("/var/lib/flatpak/exports/share/applications");
	for (const std::string &d : dirs) {
		std::error_code ec;
		if (fs::exists(d + "/" + id, ec)) return d + "/" + id;
		std::string sub = id;
		for (size_t i = 0; i < sub.size(); i++) {
			if (sub[i] != '-') continue;
			sub[i] = '/';
			if (fs::exists(d + "/" + sub, ec)) return d + "/" + sub;
		}
	}
	return {};
}

// Right-click on an app (or a favourite, or a file): its menu.
void Launcher::item_menu(int item, int fav, double lx, double ly) {
	std::vector<MenuItem> items;
	Server *srv = server_;
	const wlr_box at{static_cast<int>(lx), static_cast<int>(ly), 1, 1};
	if (item >= 0 && is_setting(item)) return;
	if (item >= 0 && is_file(item)) {
		const FileHit f = file_of(item);
		items.push_back(MenuItem::header(f.name));
		items.push_back(MenuItem::action("Open", [this, f] {
			server_->spawn("xdg-open " + shell_quote(f.path));
			close();
		}, f.dir ? "folder" : "file"));
		items.push_back(MenuItem::action("Show in its folder", [this, f] {
			server_->spawn("xdg-open " + shell_quote(std::filesystem::path(f.path).parent_path().string()));
			close();
		}, "folder"));
		items.push_back(MenuItem::action("Copy where it is", [srv, f] {
			srv->spawn("printf %s " + shell_quote(f.path) + " | wl-copy");
		}, "copy"));
		if (srv->desktop && f.path.rfind(srv->desktop->folder() + "/", 0) != 0) {
			// A link to it on the desktop (the file stays where it is).
			items.push_back(MenuItem::action("Add to desktop", [srv, f] {
				const std::string dir = srv->desktop->folder();
				srv->spawn("mkdir -p " + shell_quote(dir) + " && ln -s " + shell_quote(f.path) + " " +
					shell_quote(dir + "/" + f.name) + " 2>/dev/null");
			}, "monitor"));
		}
		srv->menu->show(output_, at, "point", std::move(items));
		return;
	}
	const int app_index = fav >= 0 ? favs_[static_cast<size_t>(fav)]
		: item >= 0 ? app_of(item) : -1;
	if (app_index < 0) return;
	const AppInfo app = server_->apps.apps()[static_cast<size_t>(app_index)];
	const auto &favs = server_->config.launcher_favorites;
	const bool is_fav = std::find(favs.begin(), favs.end(), app.id) != favs.end();
	items.push_back(MenuItem::header(app.name));
	items.push_back(MenuItem::action("Open", [this, app] {
		if (app.id.rfind("org.arqen.Settings", 0) == 0) server_->open_settings("");
		else server_->spawn(app.exec);
		close();
	}, "play"));
	items.push_back(MenuItem::action(is_fav ? "Remove from favourites" : "Add to favourites",
		[this, id = app.id] { toggle_favourite(id); }, is_fav ? "star-off" : "star"));
	// On the desktop: a copy of its launcher in the Desktop folder (as GNOME does).
	if (srv->desktop) {
		const std::string on_desktop = srv->desktop->folder() + "/" + app.id;
		std::error_code ec;
		if (std::filesystem::exists(on_desktop, ec)) {
			items.push_back(MenuItem::action("Remove from desktop", [srv, on_desktop] {
				srv->spawn("rm -f " + shell_quote(on_desktop));
			}, "minus"));
		} else if (const std::string src = desktop_file_of(app.id); !src.empty()) {
			items.push_back(MenuItem::action("Add to desktop", [srv, src, on_desktop] {
				const std::string dir = on_desktop.substr(0, on_desktop.rfind('/'));
				srv->spawn("mkdir -p " + shell_quote(dir) + " && cp " + shell_quote(src) + " " + shell_quote(on_desktop) +
					" && chmod +x " + shell_quote(on_desktop) +
					" && gio set " + shell_quote(on_desktop) + " metadata::trusted true 2>/dev/null");
			}, "monitor"));
		}
	}
	// The panel with app buttons: pin it there too.
	for (const PanelConfig &pc : server_->config.panels) {
		const auto &w = pc.widgets;
		if (std::find(w.begin(), w.end(), "tasks") == w.end() && std::find(w.begin(), w.end(), "pins") == w.end()) continue;
		std::vector<std::string> pins = pc.pins;
		const auto it = std::find(pins.begin(), pins.end(), app.id);
		const bool pinned = it != pins.end();
		if (pinned) pins.erase(it);
		else pins.push_back(app.id);
		items.push_back(MenuItem::action(pinned ? "Unpin from panel" : "Pin to panel",
			[srv, key = "panel." + pc.id + ".pins", list = join(pins)] { srv->write_setting(key, list); }, "pin"));
		break;
	}
	srv->menu->show(output_, at, "point", std::move(items));
}

// ---- Files ----------------------------------------------------------------------------

int Launcher::handle_search_timer(void *data) {
	static_cast<Launcher *>(data)->search_files();
	return 0;
}

// Files and folders in your home whose name has what you typed: from the
// file index (plocate / locate: everything, fast, as of its last update)
// and a quick look through your folders (new files), together.
void Launcher::search_files() {
	if (!open_ || query_.size() < 2) return;
	const unsigned gen = ++search_gen_;
	const std::string q = query_;
	std::string glob;
	for (char c : q) {
		if (c == '*' || c == '?' || c == '[' || c == ']' || c == '\\') glob += '\\';
		glob += c;
	}
	const std::string cmd =
		"{ if command -v plocate >/dev/null; then timeout 2 plocate -i -l 400 -- " + shell_quote(q) + "; "
		"elif command -v locate >/dev/null; then timeout 2 locate -i -l 400 -- " + shell_quote(q) + "; fi; "
		"timeout 1.5 find \"$HOME\" -maxdepth 5 -name '.*' -prune -o -iname " + shell_quote("*" + glob + "*") +
		" -print 2>/dev/null | head -n 200; } 2>/dev/null";
	server_->run_capture(cmd, [this, gen, q](const std::string &out) {
		if (gen != search_gen_ || q != query_ || !open_) return;
		const char *h = std::getenv("HOME");
		const std::string home = h ? h : "";
		const std::string lq = lower(q);
		struct Cand {
			std::string path, name;
			int rank;
		};
		std::vector<Cand> cands;
		std::istringstream in(out);
		std::string line;
		std::vector<std::string> seen;
		while (std::getline(in, line)) {
			if (line.empty() || line == home) continue;
			// Your own files only, not hidden ones (dot folders: settings, caches).
			if (!home.empty() && line.rfind(home + "/", 0) != 0) continue;
			if (line.find("/.", home.size()) != std::string::npos) continue;
			const std::string name = line.substr(line.find_last_of('/') + 1);
			const std::string ln = lower(name);
			const size_t at = ln.find(lq);
			if (at == std::string::npos) continue;   // the name itself, not just a folder on the way
			if (std::find(seen.begin(), seen.end(), line) != seen.end()) continue;
			seen.push_back(line);
			// Best first: names that start with it, then shallow ones.
			const int depth = static_cast<int>(std::count(line.begin(), line.end(), '/'));
			cands.push_back(Cand{line, name, (at == 0 ? 0 : 100) + depth});
		}
		std::stable_sort(cands.begin(), cands.end(), [](const Cand &a, const Cand &b) { return a.rank < b.rank; });
		files_.clear();
		std::error_code ec;
		for (const Cand &c : cands) {
			if (static_cast<int>(files_.size()) >= kMaxFiles) break;
			if (!std::filesystem::exists(c.path, ec)) continue;   // (the index can be out of date)
			files_.push_back(FileHit{c.path, c.name, std::filesystem::is_directory(c.path, ec)});
		}
		keep_selection_visible();
		redraw();
	});
}

Launcher::~Launcher() {
	if (avatar_) cairo_surface_destroy(avatar_);
	if (redraw_idle_) wl_event_source_remove(redraw_idle_);
	if (search_timer_) wl_event_source_remove(search_timer_);
	if (anim_) {
		server_->anim->cancel(anim_);
	}
}

void Launcher::filter() {
	const auto &apps = server_->apps.apps();
	shown_.clear();
	const std::string q = lower(query_);
	std::vector<int> starts, contains;
	for (int i = 0; i < static_cast<int>(apps.size()); i++) {
		const AppInfo &app = apps[static_cast<size_t>(i)];
		if (!app.visible) {
			continue;
		}
		const std::string name = lower(app.name);
		if (q.empty() || name.rfind(q, 0) == 0) {
			starts.push_back(i);
		} else if (name.find(q) != std::string::npos ||
				lower(app.comment).find(q) != std::string::npos ||
				lower(app.exec).find(q) != std::string::npos) {
			contains.push_back(i);
		}
	}
	if (q.empty()) {
		// All apps: A to Z.
		std::stable_sort(starts.begin(), starts.end(), [&apps](int a, int b) {
			return lower(apps[static_cast<size_t>(a)].name) < lower(apps[static_cast<size_t>(b)].name);
		});
	}
	shown_ = starts;
	shown_.insert(shown_.end(), contains.begin(), contains.end());
	// Favourites, in their order (while not searching; gone when there are none).
	favs_.clear();
	if (q.empty()) {
		// Only what the user pinned (nothing until they pin something).
		const std::vector<std::string> &pins = server_->config.launcher_favorites;
		for (const std::string &id : pins) {
			for (int i = 0; i < static_cast<int>(apps.size()); i++) {
				if (apps[static_cast<size_t>(i)].id == id) {
					favs_.push_back(i);
					break;
				}
			}
		}
	}
	// Settings pages, and the answer when it's a sum (Arqen's menu).
	settings_hits_.clear();
	calc_.clear();
	if (q.size() >= 2) {
		for (int k = 0; k < static_cast<int>(std::size(kSettingsPages)); k++) {
			const std::string words = lower(std::string(kSettingsPages[k].title) + " " + kSettingsPages[k].words);
			// Each word typed starts a word of the page's.
			bool all = true;
			std::istringstream in(q);
			std::string w;
			while (in >> w) {
				const size_t at = words.find(w);
				if (at == std::string::npos || (at > 0 && words[at - 1] != ' ')) { all = false; break; }
			}
			if (all && settings_hits_.size() < 3) settings_hits_.push_back(k);
		}
	}
	calc_ = sum_answer(query_);
	// Files: looked for a moment after you stop typing.
	files_.clear();
	search_gen_++;
	if (search_timer_) wl_event_source_timer_update(search_timer_, query_.size() >= 2 ? 220 : 0);
	hover_fav_ = -1;
	measure();
	selected_ = 0;
	first_row_ = 0;
	// A new list: no gliding from where the old one was.
	fx_.snap("scroll", 0);
}

int Launcher::visible_rows() const {
	return std::max(0, (h_ - list_top_ - kFooterHeight - 4) / kRowHeight);
}

int Launcher::hot_at(double px, double py) const {
	for (int k = static_cast<int>(hots_.size()) - 1; k >= 0; k--) {
		const wlr_box &b = hots_[static_cast<size_t>(k)].box;
		if (px >= b.x && px < b.x + b.width && py >= b.y && py < b.y + b.height) return k;
	}
	return -1;
}

void Launcher::hot_action(const std::string &id) {
	const char *h = std::getenv("HOME");
	const std::string home = h ? h : "";
	if (id.rfind("pinpage:", 0) == 0) {
		pin_page_ = std::atoi(id.c_str() + 8);
		hover_hot_ = -1;
		redraw();
		return;
	}
	if (id == "allapps" || id == "back") {
		all_apps_ = id == "allapps";
		hover_hot_ = -1;
		first_row_ = 0;
		selected_ = 0;
		fx_.snap("scroll", 0);
		measure();
		redraw();
	} else if (id == "settings") {
		close();
		server_->open_settings();
	} else if (id == "lock") {
		close();
		server_->power_action("lock");
	} else if (id == "power") {
		for (const Hot &t : hots_) {
			if (t.id != "power") continue;
			server_->show_power_menu(output_, wlr_box{box_.x + t.box.x, box_.y + t.box.y, t.box.width, t.box.height},
				"below");
		}
	} else if (id == "calc") {
		server_->spawn("printf %s " + shell_quote(calc_) + " | wl-copy");
		close();
	} else if (id == "me") {
		close();
		server_->open_settings("about");
	} else if (id.rfind("app:", 0) == 0) {
		const size_t k = std::stoul(id.substr(4));
		if (k < server_->apps.apps().size()) launch_app(server_->apps.apps()[k]);
	} else if (id.rfind("media:", 0) == 0) {
		if (server_->status) server_->status->media(id.c_str() + 6);
	} else if (id.rfind("place:", 0) == 0) {
		const std::string where = id.substr(6);
		server_->spawn(where == "trash" ? std::string("gio open trash:///")
			: "xdg-open " + shell_quote(where.empty() ? home : home + "/" + where));
		close();
	} else if (id.rfind("recent:", 0) == 0) {
		const size_t k = std::stoul(id.substr(7));
		if (k < recent_.size()) server_->spawn("xdg-open " + shell_quote(recent_[k].path));
		close();
	} else if (id.rfind("folder:", 0) == 0) {
		const size_t k = std::stoul(id.substr(7));
		if (k < recent_.size()) {
			server_->spawn("xdg-open " + shell_quote(std::filesystem::path(recent_[k].path).parent_path().string()));
		}
		close();
	}
}

// The files you opened lately (GTK's list, which most apps add to).
void Launcher::load_recent() {
	recent_.clear();
	const char *h = std::getenv("HOME");
	if (!h) return;
	const std::string home = h;
	std::ifstream f(home + "/.local/share/recently-used.xbel");
	if (!f) return;
	struct Item {
		std::string path, modified;
	};
	std::vector<Item> items;
	std::string line;
	auto attr = [](const std::string &l, const std::string &name) {
		const size_t a = l.find(" " + name + "=\"");
		if (a == std::string::npos) return std::string();
		const size_t b = a + name.size() + 3, e = l.find('"', b);
		return e == std::string::npos ? std::string() : l.substr(b, e - b);
	};
	while (std::getline(f, line)) {
		if (line.find("<bookmark ") == std::string::npos) continue;
		const std::string href = attr(line, "href");
		if (href.rfind("file://", 0) != 0) continue;
		std::string m = attr(line, "visited");
		const std::string mod = attr(line, "modified");
		if (mod > m) m = mod;
		items.push_back(Item{url_decode(href.substr(7)), m});
	}
	std::sort(items.begin(), items.end(), [](const Item &a, const Item &b) { return a.modified > b.modified; });
	std::error_code ec;
	for (const Item &it : items) {
		if (recent_.size() >= 3) break;
		if (it.path.find("/.") != std::string::npos) continue;   // (hidden files)
		if (!std::filesystem::is_regular_file(it.path, ec)) continue;
		std::string where = std::filesystem::path(it.path).parent_path().string();
		if (where.rfind(home, 0) == 0) where = "~" + where.substr(home.size());
		recent_.push_back(Recent{it.path, std::filesystem::path(it.path).filename().string(), where, ago(it.modified)});
	}
}

// Next to the menu button, on the side away from its panel's screen edge
// (or in the middle of the screen when opened from the keyboard with no
// panel). Slides a little while fading in/out.
void Launcher::place() {
	if (!output_) {
		return;
	}
	const wlr_box o = output_->box();
	const wlr_box u = output_->usable();
	const int gap = 8;
	int x, y;
	if (anchor_.width <= 0) {
		x = o.x + (o.width - w_) / 2;
		y = o.y + (o.height - h_) / 2;
	} else if (edge_ == "top" || edge_ == "bottom") {
		// Centred over the menu button.
		x = anchor_.x + anchor_.width / 2 - w_ / 2;
		y = edge_ == "top" ? anchor_.y + anchor_.height + gap + 6 : anchor_.y - h_ - gap - 6;
	} else {
		y = anchor_.y;
		x = edge_ == "left" ? anchor_.x + anchor_.width + gap + 6 : anchor_.x - w_ - gap - 6;
	}
	{
		x = std::clamp(x, u.x + gap, std::max(u.x + gap, u.x + u.width - w_ - gap));
		y = std::clamp(y, u.y + gap, std::max(u.y + gap, u.y + u.height - h_ - gap));
	}
	box_ = wlr_box{x, y, w_, h_};
	// It grows out of the corner nearest the menu button.
	double ox = w_ / 2.0, oy = h_ / 2.0;
	if (anchor_.width > 0) {
		ox = std::clamp<double>(anchor_.x + anchor_.width / 2.0 - x, 0, w_);
		oy = std::clamp<double>(anchor_.y + anchor_.height / 2.0 - y, 0, h_);
		if (edge_ == "bottom") oy = h_;
		else if (edge_ == "top") oy = 0;
		else if (edge_ == "left") ox = 0;
		else ox = w_;
	}
	const double t = std::clamp(alpha_, 0.0, 1.1);
	// Rises a few pixels as it fades in, barely growing.
	const int rise = static_cast<int>(std::lround((1.0 - std::min(1.0, t)) * 12 * (edge_ == "top" ? -1 : 1)));
	layer_.show(x, y + rise, std::min(1.0, t * 1.25), 0.97 + 0.03 * t, ox, oy);
}

void Launcher::open(Output *output, wlr_box anchor, const std::string &edge) {
	if (!output) {
		return;
	}
	output_ = output;
	anchor_ = anchor;
	edge_ = edge;
	open_ = true;
	pin_page_ = 0;
	home_first_ = 0;
	home_scroll_accum_ = 0;
	query_.clear();
	all_apps_ = false;
	hover_hot_ = -1;
	load_recent();
	hover_row_ = -1;
	measure();
	server_->apps.reload_if_changed();   // picks up newly installed apps
	filter();
	wlr_scene_node_reparent(&layer_.tree->node, server_->layer_menu);
	redraw_now();
	place();
	layer_.set_enabled(true);
	layer_.raise();

	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 1.0, c.animate(c.anim_menu) ? c.ms(230) : 0,
		[this] { place(); }, [this] { anim_ = 0; });
	server_->redraw_panels();   // menu button shows as pressed
}

void Launcher::close() {
	if (!open_) {
		return;
	}
	open_ = false;
	pin_press_ = -1;
	pin_moving_ = false;
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 0.0, c.animate(c.anim_menu) ? c.ms(160) : 0,
		[this] { place(); },
		[this] {
			anim_ = 0;
			if (!open_) {
				layer_.set_enabled(false);
			}
		});
	server_->redraw_panels();
}

void Launcher::toggle(Output *output, wlr_box anchor, const std::string &edge) {
	if (open_) {
		close();
	} else {
		open(output, anchor, edge);
	}
}

void Launcher::toggle(Output *output) {
	if (open_ || !output) {
		close();
		return;
	}
	for (const auto &panel : output->panels) {
		const auto &w = panel->config().widgets;
		if (std::find(w.begin(), w.end(), "menu") != w.end()) {
			open(output, panel->anchor("menu"), panel->config().edge);
			return;
		}
	}
	open(output, wlr_box{}, "bottom");
}

void Launcher::output_gone(Output *output) {
	if (output_ == output) {
		open_ = false;
		server_->anim->cancel(anim_);
		anim_ = 0;
		alpha_ = 0;
		layer_.set_enabled(false);
		output_ = nullptr;
	}
}

bool Launcher::contains(double lx, double ly) const {
	return open_ && lx >= box_.x && lx < box_.x + box_.width &&
		ly >= box_.y && ly < box_.y + box_.height;
}

int Launcher::row_at(double px, double py) const {
	if (home()) return -1;
	if (px < kPad || px >= w_ - kPad || py < list_top_) {
		return -1;
	}
	if (py >= list_top_ + visible_rows() * kRowHeight) {
		return -1;
	}
	// Rows as drawn, while the list may still be gliding.
	const double scroll = const_cast<Fades &>(fx_).get("scroll", first_row_ * kRowHeight);
	const int row = static_cast<int>(std::floor((py - list_top_ + scroll) / kRowHeight));
	return row >= 0 && row < count() ? row : -1;
}

void Launcher::motion(double lx, double ly) {
	const double px = lx - box_.x, py = ly - box_.y;
	last_px_ = px;
	last_py_ = py;
	const int row = row_at(px, py);
	const int fav = fav_at(px, py);
	const int hot = fav >= 0 ? -1 : hot_at(px, py);
	if (row != hover_row_ || fav != hover_fav_ || hot != hover_hot_) {
		hover_hot_ = hot;
		hover_row_ = row;
		hover_fav_ = fav;
		update_highlights();   // no redraw needed
	}
}

void Launcher::leave() {
	if (open_ && (hover_row_ != -1 || hover_fav_ != -1 || hover_hot_ != -1)) {
		hover_hot_ = -1;
		hover_row_ = -1;
		hover_fav_ = -1;
		update_highlights();
	}
}

// The selection and hover highlights, where the rows are drawn right now.
void Launcher::update_highlights() {
	const Color hover = with_alpha(theme::text, theme::dark ? 0.08 : 0.06);
	const double scroll = fx_.get("scroll", first_row_ * kRowHeight);
	const double row_r = inner_radius(theme::ui_radius, kPad);
	const int rh = kRowHeight - 4;
	const double list_bottom = list_top_ + visible_rows() * kRowHeight;
	auto row_box = [&](int row, wlr_box *out) {
		const double ry = list_top_ + row * kRowHeight - scroll;
		if (row < 0 || row >= count() || ry < list_top_ - rh / 2.0 ||
				ry + rh > list_bottom + rh / 2.0) {
			return false;
		}
		*out = wlr_box{kPad, static_cast<int>(std::lround(ry)), w_ - 2 * kPad, rh};
		return true;
	};
	wlr_box b;
	if (!home() && row_box(selected_, &b)) {
		sel_.show(b, row_r, with_alpha(theme::accent, theme::dark ? 0.22 : 0.16));
	} else {
		sel_.hide();
	}
	if (hover_fav_ >= 0) {
		const wlr_box fb = fav_box(hover_fav_);
		hl_.show(wlr_box{fb.x + 4, fb.y, fb.width - 8, fb.height}, std::min(16.0, row_r), hover);
	} else if (hover_hot_ >= 0 && hover_hot_ < static_cast<int>(hots_.size())) {
		const Hot &t = hots_[static_cast<size_t>(hover_hot_)];
		hl_.show(t.box, t.r, hover);
	} else if (hover_row_ >= 0 && hover_row_ != selected_ && row_box(hover_row_, &b)) {
		hl_.show(b, row_r, hover);
	} else {
		hl_.hide();
	}
}

// The scroll bar's track (a bit wider than it's drawn, so it's easy to hit).
bool Launcher::on_bar(double px, double py) const {
	const int rows = visible_rows();
	return !home() && count() > rows && px >= w_ - 18 && px < w_ &&
		py >= list_top_ && py < list_top_ + rows * kRowHeight;
}

void Launcher::drag_bar(double lx, double ly) {
	(void)lx;
	const int rows = visible_rows();
	const int total = count();
	if (total <= rows) return;
	const double track = rows * kRowHeight;
	const double thumb = std::max(24.0, track * rows / total);
	const double frac = std::clamp((ly - box_.y - list_top_ - thumb / 2) / std::max(1.0, track - thumb), 0.0, 1.0);
	const int first = static_cast<int>(std::lround(frac * (total - rows)));
	if (first != first_row_) {
		first_row_ = first;
		redraw();
	}
}

void Launcher::click(double lx, double ly, uint32_t button) {
	const double px = lx - box_.x, py = ly - box_.y;
	if (button == BTN_RIGHT) {
		const int fav = fav_at(px, py);
		const int row = fav >= 0 ? -1 : row_at(px, py);
		if (fav >= 0 || row >= 0) item_menu(row, fav, lx, ly);
		return;
	}
	if (button != BTN_LEFT) {
		return;
	}
	if (const int fav = fav_at(px, py); fav >= 0) {
		// Launched when let go, unless it's dragged into another place.
		pin_press_ = fav;
		pin_moving_ = false;
		pin_x_ = pin_px_ = px;
		pin_y_ = pin_py_ = py;
		return;
	}
	if (const int hot = hot_at(px, py); hot >= 0) {
		hot_action(hots_[static_cast<size_t>(hot)].id);
		return;
	}
	if (on_bar(px, py)) {
		bar_drag_ = true;
		drag_bar(lx, ly);
		return;
	}
	const int row = row_at(px, py);
	if (row >= 0) {
		launch(row);
	}
}

void Launcher::drag_pin(double lx, double ly) {
	if (pin_press_ < 0) return;
	const double px = lx - box_.x, py = ly - box_.y;
	if (!pin_moving_) {
		if (std::hypot(px - pin_x_, py - pin_y_) < 8 || favs_.size() < 2) return;   // still a click
		pin_moving_ = true;
	}
	pin_px_ = px;
	pin_py_ = py;
	// The pinned app under the pointer (on this page): ours takes its place.
	const int to = fav_at(px, py);
	if (to >= 0 && to != pin_press_ && to < static_cast<int>(favs_.size())) {
		const int moving = favs_[static_cast<size_t>(pin_press_)];
		favs_.erase(favs_.begin() + pin_press_);
		favs_.insert(favs_.begin() + to, moving);
		pin_press_ = to;
	}
	redraw();
}

void Launcher::release_pin(double lx, double ly) {
	const int at = pin_press_;
	const bool moved = pin_moving_;
	pin_press_ = -1;
	pin_moving_ = false;
	if (at < 0 || at >= static_cast<int>(favs_.size())) return;
	const auto &apps = server_->apps.apps();
	if (!moved) {
		launch_app(apps[static_cast<size_t>(favs_[static_cast<size_t>(at)])]);
		return;
	}
	// The new order, with any pins of apps not installed now kept at the end.
	std::vector<std::string> order;
	for (int i : favs_) order.push_back(apps[static_cast<size_t>(i)].id);
	for (const std::string &id : server_->config.launcher_favorites) {
		if (std::find(order.begin(), order.end(), id) == order.end()) order.push_back(id);
	}
	if (order != server_->config.launcher_favorites) {
		server_->config.launcher_favorites = order;
		server_->write_setting("launcher_favorites", join(order));
	}
	(void)lx;
	(void)ly;
	redraw();
}

void Launcher::scroll(double delta, bool wheel) {
	// A mouse wheel moves a row per notch (15 units, or a part of one for
	// high-resolution wheels); a touchpad moves with the fingers.
	const int unit = kRowHeight;
	if (home()) {
		// Over the pinned apps: their pages; anywhere else: the list of all apps.
		const bool on_pins = last_px_ >= favs_area_.x && last_px_ < favs_area_.x + favs_area_.width &&
			last_py_ >= favs_area_.y && last_py_ < favs_area_.y + favs_area_.height;
		home_scroll_accum_ += wheel ? delta * (unit / 15.0) : delta * 1.4;
		int steps = 0;
		while (home_scroll_accum_ >= unit * 0.75) { home_scroll_accum_ -= unit; steps++; }
		while (home_scroll_accum_ <= -unit * 0.75) { home_scroll_accum_ += unit; steps--; }
		if (steps == 0) return;
		if (on_pins && pin_pages() > 1) {
			pin_page_ = std::clamp(pin_page_ + (steps > 0 ? 1 : -1), 0, pin_pages() - 1);
			home_scroll_accum_ = 0;
		} else {
			home_first_ = std::clamp(home_first_ + steps, 0, std::max(0, static_cast<int>(shown_.size()) - home_fit_));
		}
		hover_hot_ = -1;
		redraw();
		return;
	}
	scroll_accum_ += wheel ? delta * (unit / 15.0) : delta * 1.4;
	int steps = 0;
	while (scroll_accum_ >= unit * 0.75) { scroll_accum_ -= unit; steps++; }
	while (scroll_accum_ <= -unit * 0.75) { scroll_accum_ += unit; steps--; }
	if (steps == 0) {
		return;
	}
	first_row_ = std::clamp(first_row_ + steps, 0, max_first());
	redraw();
}

void Launcher::keep_selection_visible() {
	if (selected_ < first_row_) {
		first_row_ = selected_;
	} else if (selected_ >= first_row_ + visible_rows()) {
		first_row_ = selected_ - visible_rows() + 1;
	}
}

bool Launcher::handle_key(xkb_keysym_t sym, const std::string &text) {
	const int count = this->count();
	switch (sym) {
	case XKB_KEY_Escape:
		if (query_.empty() && all_apps_) {
			hot_action("back");
			return true;
		}
		close();
		return true;
	case XKB_KEY_Return:
	case XKB_KEY_KP_Enter:
		if (!calc_.empty()) {
			hot_action("calc");   // a sum: Enter copies the answer
			return true;
		}
		if (home()) return true;
		if (count > 0) {
			launch(selected_);
		}
		return true;
	case XKB_KEY_Down:
		if (home()) {
			hot_action("allapps");   // the arrow keys work in the list of all apps
			return true;
		}
		if (count > 0) selected_ = std::min(selected_ + 1, count - 1);
		break;
	case XKB_KEY_Up:
		selected_ = std::max(selected_ - 1, 0);
		break;
	case XKB_KEY_Right:
	case XKB_KEY_Left:
		return true;
	case XKB_KEY_Page_Down:
		if (count > 0) selected_ = std::min(selected_ + visible_rows(), count - 1);
		break;
	case XKB_KEY_Page_Up:
		selected_ = std::max(selected_ - visible_rows(), 0);
		break;
	case XKB_KEY_BackSpace:
		if (!query_.empty()) {
			// Remove one whole UTF-8 character.
			size_t cut = query_.size() - 1;
			while (cut > 0 && (static_cast<unsigned char>(query_[cut]) & 0xc0) == 0x80) {
				cut--;
			}
			query_.erase(cut);
			filter();
		} else if (all_apps_) {
			hot_action("back");
			return true;
		}
		break;
	case XKB_KEY_Tab:
		break;
	default:
		if (!text.empty() && static_cast<unsigned char>(text[0]) >= 0x20 && text[0] != 0x7f) {
			query_ += text;
			filter();
		}
		break;
	}
	keep_selection_visible();
	redraw();
	return true;   // the menu takes all keys while open
}

void Launcher::launch(int row) {
	if (row < 0 || row >= count()) {
		return;
	}
	if (is_file(row)) {
		// A file or folder: opened with its app (a folder in the file manager).
		server_->spawn("xdg-open " + shell_quote(file_of(row).path));
		close();
		return;
	}
	if (is_setting(row)) {
		server_->open_settings(kSettingsPages[setting_of(row)].page);
		close();
		return;
	}
	launch_app(server_->apps.apps()[static_cast<size_t>(app_of(row))]);
}

void Launcher::launch_app(const AppInfo &app) {
	if (app.id.rfind("org.arqen.Settings", 0) == 0) {
		server_->open_settings("");   // the one that's open comes forward
	} else {
		server_->spawn(app.exec);
	}
	close();
}

// Drawn once when the event loop is next free, not every time something
// asks (the hover fades, the scroll, the files arriving, each key): a
// full-screen grid drawn several times a frame flickered, like the overview
// did before the same fix.
void Launcher::redraw() {
	if (!output_ || redraw_idle_) return;
	redraw_idle_ = wl_event_loop_add_idle(server_->loop, &Launcher::handle_redraw_idle, this);
}

void Launcher::handle_redraw_idle(void *data) {
	auto *self = static_cast<Launcher *>(data);
	self->redraw_idle_ = nullptr;
	self->redraw_now();
}

void Launcher::redraw_now() {
	if (!output_ || drawing_) {
		return;
	}
	drawing_ = true;
	const auto &apps = server_->apps.apps();
	const float scale = output_->output->scale;
	Canvas canvas(w_, h_, scale);
	cairo_t *cr = canvas.cr();
	const double radius = theme::ui_radius;
	ui_card(cr, 0, 0, w_, h_, radius, theme::menu_bg);

	hots_.clear();
	draw_header(cr, scale);

	if (home()) {
		draw_home(cr, scale);
		layer_.present(canvas, wlr_box{0, 0, w_, h_}, radius);
		drawing_ = false;
		update_highlights();
		return;
	}

	if (query_.empty()) {
		// Every app, A to Z, with the way back.
		const int by = kListTop;
		draw_named_icon(cr, server_->icons, "chevron-left", kPad + 6, by + 7, 16, theme::text, scale);
		draw_text(cr, "All apps", kPad + 26, by, 200, 30, theme::font_title, theme::text);
		hots_.push_back(Hot{"back", wlr_box{kPad, by, text_width("All apps", theme::font_title) + 38, 30}, 15});
		draw_text(cr, std::to_string(shown_.size()) + " apps", w_ - kPad - 160, by, 154, 30, theme::font_small,
			theme::text_dim, Align::Right);
	}
	if (!calc_.empty()) {
		// The answer to a sum, as a card (a click or Enter copies it).
		calc_box_ = wlr_box{kPad, kListTop, w_ - 2 * kPad, 60};
		fill_rounded(cr, calc_box_.x, calc_box_.y, calc_box_.width, calc_box_.height, inner_radius(radius, kPad),
			theme::card_bg);
		const double ix = calc_box_.x + 12, iy = calc_box_.y + 12;
		fill_rounded(cr, ix, iy, 36, 36, 10, with_alpha(theme::accent, 0.16));
		draw_named_icon(cr, server_->icons, "sparkles", ix + 9, iy + 9, 18, theme::accent, scale);
		draw_text(cr, "= " + calc_, ix + 48, calc_box_.y + 9, calc_box_.width - 72, 24, theme::font_heading, theme::text);
		draw_text(cr, "Calculation · Enter copies the answer", ix + 48, calc_box_.y + 33, calc_box_.width - 72, 18,
			theme::font_small, theme::text_dim);
		hots_.push_back(Hot{"calc", calc_box_, inner_radius(radius, kPad)});
	}

	// The list: it scrolls smoothly and the selection glides between rows.
	const int rows = visible_rows();
	if (count() == 0 && calc_.empty()) {
		draw_text(cr, apps.empty() ? "No apps found" : query_.size() >= 2 ? "Looking…" : "No matches", kPad, list_top_,
			w_ - 2 * kPad, kRowHeight * 2, theme::font, theme::text_dim, Align::Center);
	}
	fx_.set("scroll", first_row_ * kRowHeight, 0);
	const double scroll = fx_.get("scroll");
	const double list_h = rows * kRowHeight;
	cairo_save(cr);
	cairo_rectangle(cr, 0, list_top_ - 2, w_, list_h + 2);
	cairo_clip(cr);
	const double rh = kRowHeight - 4;
	const int first = std::max(0, static_cast<int>(scroll / kRowHeight));
	const int head = apps_head(), files_end = head + static_cast<int>(files_.size()), extras_end = head + extras();
	// "Apps", "Files", "Settings": where each part starts (on the right of the row).
	auto part = [&](int row) -> const char * {
		if (extras() == 0) return nullptr;
		if (row == 0 && head > 0) return "Apps";
		if (row == head && !files_.empty()) return "Files";
		if (row == files_end && !settings_hits_.empty()) return "Settings";
		if (row == extras_end && extras_end < count()) return "More apps";
		return nullptr;
	};
	const std::string home_dir = std::getenv("HOME") ? std::getenv("HOME") : "";
	for (int row = first; row < count() && row <= first + rows + 1; row++) {
		const double ry = list_top_ + row * kRowHeight - scroll;
		if (row > 0 && part(row)) {
			cairo_rectangle(cr, kPad + 12, ry - 1, w_ - 2 * kPad - 24, 1);
			set_color(cr, theme::divider);
			cairo_fill(cr);
		}
		if (const char *label = part(row)) {
			draw_text(cr, label, w_ - kPad - 110, ry, 98, rh, theme::font_small, with_alpha(theme::text_dim, 0.8),
				Align::Right);
		}
		const std::string name = item_name(row);
		const double tx = kPad + 50, tw = w_ - 2 * kPad - 60 - (part(row) ? 70 : 0);
		if (is_setting(row)) {
			fill_rounded(cr, kPad + 10, ry + (rh - 30) / 2.0, 30, 30, 9, with_alpha(theme::text, 0.07));
			draw_named_icon(cr, server_->icons, "gear", kPad + 17, ry + (rh - 16) / 2.0, 16, theme::text, scale);
			draw_text(cr, name, tx, ry + 3, tw, 20, theme::font, theme::text);
			draw_text(cr, "Settings", tx, ry + 21, tw, 16, theme::font_small, theme::text_dim);
			continue;
		}
		draw_icon(cr, server_->icons, item_icon(row), name, kPad + 10, ry + (rh - 30) / 2.0, 30, scale);
		if (is_file(row)) {
			// The name, and the folder it's in (from your home).
			const FileHit &f = file_of(row);
			std::string where = f.path.substr(0, f.path.find_last_of('/'));
			if (!home_dir.empty() && where.rfind(home_dir, 0) == 0) where = "~" + where.substr(home_dir.size());
			draw_text(cr, name, tx, ry + 3, tw, 20, theme::font, theme::text);
			draw_text(cr, where, tx, ry + 21, tw, 16, theme::font_small, theme::text_dim);
		} else {
			const AppInfo &app = apps[static_cast<size_t>(app_of(row))];
			if (!app.comment.empty() && !query_.empty()) {
				draw_text(cr, name, tx, ry + 3, tw, 20, theme::font, theme::text);
				draw_text(cr, app.comment, tx, ry + 21, tw, 16, theme::font_small, theme::text_dim);
			} else {
				draw_text(cr, name, tx, ry, tw, rh, theme::font, theme::text);
			}
		}
	}
	cairo_restore(cr);

	// Scroll indicator.
	const int total = count();
	if (total > rows && rows > 0) {
		const double track = rows * kRowHeight;
		const double thumb = std::max(24.0, track * rows / total);
		const double pos = (track - thumb) * (scroll / kRowHeight) / std::max(1, total - rows);
		fill_rounded(cr, w_ - 9, list_top_ + pos, 4, thumb, 2, with_alpha(theme::text, 0.25));
	}

	layer_.present(canvas, wlr_box{0, 0, w_, h_}, radius);
	drawing_ = false;
	update_highlights();
}

void Launcher::load_avatar() {
	const std::string path = user_picture_path();
	struct stat st{};
	const std::string key = path.empty() || stat(path.c_str(), &st) != 0 ? std::string()
		: path + "|" + std::to_string(st.st_mtime) + "|" + std::to_string(st.st_size);
	if (key == avatar_key_) return;
	avatar_key_ = key;
	if (avatar_) cairo_surface_destroy(avatar_);
	avatar_ = key.empty() ? nullptr : load_image_sized(path, 128, 128);
}

// Across the top: you, the search field, and Settings, lock and power.
void Launcher::draw_header(cairo_t *cr, float scale) {
	const double as = kSearchHeight;   // the avatar, as tall as the search field
	const double acx = kPad + as / 2, acy = kPad + as / 2;
	load_avatar();
	cairo_new_path(cr);
	cairo_arc(cr, acx, acy, as / 2, 0, 2 * M_PI);
	if (avatar_) {
		// Your picture, cropped round from the middle.
		cairo_save(cr);
		cairo_clip(cr);
		const double iw = cairo_image_surface_get_width(avatar_), ih = cairo_image_surface_get_height(avatar_);
		const double k = as / std::min(iw, ih);
		cairo_translate(cr, acx - iw * k / 2, acy - ih * k / 2);
		cairo_scale(cr, k, k);
		cairo_set_source_surface(cr, avatar_, 0, 0);
		cairo_pattern_set_filter(cairo_get_source(cr), CAIRO_FILTER_GOOD);
		cairo_paint(cr);
		cairo_restore(cr);
	} else {
		accent_gradient(cr, kPad, kPad, as, as);
		cairo_fill(cr);
		draw_text(cr, user_name_.substr(0, 1), kPad, kPad, as, as, theme::font_heading, theme::on_gradient, Align::Center);
	}
	const SystemStatus &st = *server_->status;
	std::string sub = "Up " + up_for();
	if (st.has_battery) sub += " · " + std::to_string(st.battery) + "%";
	const int name_w = 150;
	const double tx = kPad + as + 10;
	draw_text(cr, user_name_, tx, kPad + 2, name_w, 20, theme::font_bold, theme::text);
	draw_text(cr, sub, tx, kPad + 21, name_w, 17, theme::font_small, theme::text_dim);
	hots_.push_back(Hot{"me", wlr_box{kPad - 4, kPad - 2, static_cast<int>(as + 14 + name_w), kSearchHeight + 4}, 14});

	// The buttons on the right.
	std::vector<std::pair<const char *, const char *>> buttons = {{"settings", "gear"}, {"lock", "lock"}};
	if (server_->config.menu_power) buttons.push_back({"power", "power"});
	const int bs = 36;
	const int buttons_w = static_cast<int>(buttons.size()) * (bs + 6);
	int bx = w_ - kPad - buttons_w + 6;
	for (const auto &[id, icon] : buttons) {
		const int by = static_cast<int>(kPad + (kSearchHeight - bs) / 2.0);
		glass_disc(cr, bx + bs / 2.0, by + bs / 2.0, bs / 2.0, theme::field_bg);
		draw_named_icon(cr, server_->icons, icon, bx + (bs - 18) / 2.0, by + (bs - 18) / 2.0, 18, theme::text, scale);
		hots_.push_back(Hot{id, wlr_box{bx, by, bs, bs}, bs / 2.0});
		bx += bs + 6;
	}

	// The search field: a frosted pill between the two.
	const int sx = static_cast<int>(tx + name_w + 12);
	const int sw = std::max(120, w_ - kPad - buttons_w - 10 - sx);
	const double field_r = kSearchHeight / 2.0;
	fill_rounded(cr, sx, kPad, sw, kSearchHeight, field_r, theme::field_bg);
	if (!query_.empty()) {
		rounded_rect(cr, sx + 0.5, kPad + 0.5, sw - 1, kSearchHeight - 1, field_r);
		set_color(cr, with_alpha(theme::accent, 0.6));
		cairo_set_line_width(cr, 1.2);
		cairo_stroke(cr);
	}
	draw_named_icon(cr, server_->icons, "search", sx + 14, kPad + kSearchHeight / 2.0 - 9, 18, theme::text_dim, scale);
	const int text_x = sx + 42;
	if (query_.empty()) {
		draw_text(cr, "Search anything", text_x + 4, kPad, sw - 56, kSearchHeight, theme::font, theme::text_dim);
	} else {
		draw_text(cr, query_, text_x, kPad, sw - 56, kSearchHeight, theme::font_large, theme::text);
	}
	const int caret_x = text_x + (query_.empty() ? 0 : text_width(query_, theme::font_large)) + 1;
	if (caret_x < sx + sw - 16) {
		cairo_rectangle(cr, caret_x, kPad + 12, 2, kSearchHeight - 24);
		set_color(cr, theme::accent);
		cairo_fill(cr);
	}
}

// The menu before you type: pinned apps and widgets on the left, recent
// files and your apps on the right.
void Launcher::draw_home(cairo_t *cr, float scale) {
	const auto &apps = server_->apps.apps();
	const double r = 14;
	const int lw = left_width();

	// Pinned apps.
	int y = favs_area_.y;
	draw_text(cr, "Pinned apps", kPad + 2, y, 200, 22, theme::font_title, theme::text);
	if (favs_.empty()) {
		draw_text(cr, "Right-click an app to pin it here", kPad + 2, y + 30, lw, 30, theme::font_small, theme::text_dim);
	}
	// More than a page: dots beside the heading to change page (or the wheel over them).
	pin_page_ = std::clamp(pin_page_, 0, pin_pages() - 1);
	if (pin_pages() > 1) {
		const int n = pin_pages(), dot = 8, gap = 10;
		const int dx0 = kPad + lw - n * (dot + gap) + gap;
		for (int p = 0; p < n; p++) {
			const double cx = dx0 + p * (dot + gap) + dot / 2.0, cy = y + 11;
			cairo_new_path(cr);
			if (p == pin_page_) {
				rounded_rect(cr, cx - dot, cy - dot / 2.0, 2 * dot, dot, dot / 2.0);
				set_color(cr, theme::accent);
			} else {
				cairo_arc(cr, cx, cy, dot / 2.0, 0, 2 * M_PI);
				set_color(cr, with_alpha(theme::text, 0.25));
			}
			cairo_fill(cr);
			hots_.push_back(Hot{"pinpage:" + std::to_string(p),
				wlr_box{static_cast<int>(cx - dot - 2), static_cast<int>(cy - 10), 2 * dot + 4, 20}, 10});
		}
	}
	const int from = pin_page_ * kPinPage;
	const int to = std::min(static_cast<int>(favs_.size()), from + kPinPage);
	for (int k = from; k < to; k++) {
		const AppInfo &app = apps[static_cast<size_t>(favs_[static_cast<size_t>(k)])];
		const wlr_box b = fav_box(k);
		const double is = 40;
		if (pin_moving_ && k == pin_press_) {
			// Its place, kept open (the app itself rides on the pointer, below).
			fill_rounded(cr, b.x + 4, b.y + 2, b.width - 8, b.height - 4, 14, with_alpha(theme::accent, 0.12));
			continue;
		}
		draw_icon(cr, server_->icons, app.icon, app.name, b.x + (b.width - is) / 2.0, b.y + 6, is, scale);
		draw_text(cr, app.name, b.x + 2, b.y + 6 + is + 6, b.width - 4, 18, theme::font_small, theme::text, Align::Center);
	}
	if (pin_moving_ && pin_press_ >= 0 && pin_press_ < static_cast<int>(favs_.size())) {
		// The one being moved, lifted under the pointer.
		const AppInfo &app = apps[static_cast<size_t>(favs_[static_cast<size_t>(pin_press_)])];
		const double is = 46, cx = pin_px_, cy = pin_py_;
		fill_rounded(cr, cx - is / 2 - 8, cy - is / 2 - 8, is + 16, is + 16, 16, with_alpha(theme::card_bg, 0.92));
		draw_icon(cr, server_->icons, app.icon, app.name, cx - is / 2, cy - is / 2, is, scale);
	}

	// The connected devices (Bluetooth and KDE Connect), each a ring with its battery.
	y = favs_area_.y + favs_area_.height + 6;
	draw_text(cr, "Devices", kPad + 2, y, 200, 22, theme::font_title, theme::text);
	draw_devices(cr, y + 30, scale);

	// The right column.
	const int x1 = kPad + lw + kGutter, rw = w_ - kPad - x1;
	y = favs_area_.y;
	draw_text(cr, "Recent", x1 + 2, y, 200, 22, theme::font_title, theme::text);
	y += 30;
	if (recent_.empty()) {
		draw_text(cr, "Files you open show up here", x1 + 2, y, rw, 22, theme::font_small, theme::text_dim);
		y += 30;
	}
	for (size_t k = 0; k < recent_.size() && k < 3; k++) {
		const Recent &rc = recent_[k];
		const int rh = 46;
		fill_rounded(cr, x1 + 6, y + 6, 34, 34, 11, theme::card_bg);
		draw_icon(cr, server_->icons, file_icon(rc.name, false), rc.name, x1 + 13, y + 13, 20, scale);
		const double tx = x1 + 50, tw = rw - 56;
		draw_text(cr, rc.name, tx, y + 5, tw, 20, theme::font, theme::text);
		draw_text(cr, rc.where + (rc.when.empty() ? "" : " · " + rc.when), tx, y + 24, tw, 17, theme::font_small,
			theme::text_dim);
		hots_.push_back(Hot{"recent:" + std::to_string(k), wlr_box{x1, y, rw, rh}, r});
		y += rh + 2;
	}

	// Every app, A to Z, as far as there's room ("See all" for the rest).
	y += 10;
	draw_text(cr, "All apps", x1 + 2, y, 200, 22, theme::font_title, theme::text);
	{
		const std::string all = "See all";
		const int aw = text_width(all, theme::font_small) + 34;
		const int ax = w_ - kPad - aw;
		fill_rounded(cr, ax, y - 2, aw, 26, 13, theme::field_bg);
		draw_text(cr, all, ax + 12, y - 2, aw - 26, 26, theme::font_small, theme::text);
		draw_named_icon(cr, server_->icons, "chevron-right", ax + aw - 22, y + 4, 14, theme::text_dim, scale);
		hots_.push_back(Hot{"allapps", wlr_box{ax, y - 2, aw, 26}, 13});
	}
	y += 30;
	// As many as fit; the wheel scrolls through the rest.
	const int rh = 40;
	const int total = static_cast<int>(shown_.size());
	home_fit_ = std::max(1, (h_ - kPad - y) / rh);
	home_first_ = std::clamp(home_first_, 0, std::max(0, total - home_fit_));
	home_list_ = wlr_box{x1, y, rw, home_fit_ * rh};
	const bool more = total > home_fit_;
	const int lw2 = more ? rw - 10 : rw;   // room for the scroll bar
	for (int k = home_first_; k < total && y + rh <= h_ - kPad; k++) {
		const AppInfo &app = apps[static_cast<size_t>(shown_[static_cast<size_t>(k)])];
		draw_icon(cr, server_->icons, app.icon, app.name, x1 + 8, y + (rh - 28) / 2.0, 28, scale);
		draw_text(cr, app.name, x1 + 48, y, lw2 - 54, rh, theme::font, theme::text);
		hots_.push_back(Hot{"app:" + std::to_string(shown_[static_cast<size_t>(k)]), wlr_box{x1, y, lw2, rh}, 12});
		y += rh;
	}
	if (more) {
		// A thin scroll bar: where in the list this is.
		const double track = home_list_.height - 8;
		const double thumb = std::max(24.0, track * home_fit_ / total);
		const double ty = home_list_.y + 4 + (track - thumb) * home_first_ / std::max(1, total - home_fit_);
		fill_rounded(cr, x1 + rw - 4, home_list_.y + 4, 4, track, 2, with_alpha(theme::text, 0.06));
		fill_rounded(cr, x1 + rw - 4, ty, 4, thumb, 2, with_alpha(theme::text, 0.28));
	}
}

// Under the pinned apps: the connected devices, Bluetooth and KDE Connect
// together, each as a ring (its picture inside, its battery around it)
// with the percentage under it, the same as the control centre's devices
// tile when it's small. As many as fit in the room the old widgets had;
// the last one says how many more.
void Launcher::draw_devices(cairo_t *cr, int y, float scale) {
	const int lw = left_width();
	const double r = 18;
	const SystemStatus &st = *server_->status;
	std::vector<const LinkedDevice *> list;
	for (const LinkedDevice &d : st.devices) list.push_back(&d);
	for (const LinkedDevice &d : st.phones) list.push_back(&d);

	const int max_h = 2 * kWidgetH + 10;
	if (list.empty()) {
		ui_card(cr, kPad, y, lw, kWidgetH, r, theme::card_bg);
		draw_device_ring(cr, server_, kPad + 18 + 22, y + kWidgetH / 2.0, 44, nullptr, "bluetooth", scale);
		draw_text(cr, "No devices connected", kPad + 76, y + kWidgetH / 2.0 - 20, lw - 92, 20, theme::font_bold, theme::text);
		draw_text(cr, "Bluetooth and KDE Connect devices show up here", kPad + 76, y + kWidgetH / 2.0, lw - 92, 18,
			theme::font_small, theme::text_dim);
		return;
	}
	// Under each ring its name (short: "S23 Ultra"), so two phones can be told
	// apart, and its battery under that.
	const double ip = 12, slot_w = 84, ring = 52, label = 16, slot_h = ring + 2 * label + 8;
	const int cols = std::max(1, static_cast<int>((lw - 2 * ip) / slot_w));
	const int n = static_cast<int>(list.size());
	const int rows_fit = std::max(1, static_cast<int>((max_h - 2 * ip) / slot_h));
	const int shown = std::min(n, cols * rows_fit);
	const int rows = (shown + cols - 1) / cols;
	const double h = std::min<double>(max_h, rows * slot_h + 2 * ip);
	ui_card(cr, kPad, y, lw, h, r, theme::card_bg);
	const double sw = (lw - 2 * ip) / cols;
	for (int k = 0; k < shown; k++) {
		const LinkedDevice &dv = *list[static_cast<size_t>(k)];
		const double sx = kPad + ip + (k % cols) * sw, sy = y + ip + (k / cols) * slot_h;
		const double cx = sx + sw / 2, cy = sy + 4 + ring / 2;
		draw_device_ring(cr, server_, cx, cy, ring, &dv, "bluetooth", scale);
		draw_text(cr, device_short_name(dv.name), sx + 2, cy + ring / 2 + 4, sw - 4, label, theme::font_small,
			theme::text, Align::Center);
		std::string txt = dv.battery >= 0 ? std::to_string(dv.battery) + "%" : std::string();
		if (k == shown - 1 && n > shown) txt += (txt.empty() ? "+" : " +") + std::to_string(n - shown);
		if (!txt.empty()) {
			const bool low = dv.battery >= 0 && dv.battery <= 15 && !dv.charging;
			draw_text(cr, txt, sx, cy + ring / 2 + 4 + label, sw, label, theme::font_small,
				low ? theme::danger : theme::text_dim, Align::Center);
		}
	}
}

} // namespace arqen
