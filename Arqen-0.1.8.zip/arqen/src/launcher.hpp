// The app menu: lists installed apps (from .desktop files), type to search.
#pragma once

#include <string>
#include <vector>

#include "server.hpp"
#include "ui.hpp"

namespace arqen {

class Launcher {
public:
	explicit Launcher(Server *server);
	~Launcher();
	Launcher(const Launcher &) = delete;
	Launcher &operator=(const Launcher &) = delete;

	bool is_open() const { return open_; }
	bool is_open_on(const Output *output) const { return open_ && output_ == output; }
	// Opens next to `anchor` (the menu button) on a panel at `edge`.
	void open(Output *output, wlr_box anchor, const std::string &edge);
	void close();
	void toggle(Output *output, wlr_box anchor, const std::string &edge);
	// From the keyboard: next to the first menu button on that screen.
	void toggle(Output *output);
	void output_gone(Output *output);

	bool contains(double lx, double ly) const;
	void motion(double lx, double ly);
	void leave();
	void click(double lx, double ly, uint32_t button);
	void scroll(double delta, bool wheel = true);
	// The scroll bar: press on it and drag (or click the track to jump there).
	bool dragging_bar() const { return bar_drag_; }
	void drag_bar(double lx, double ly);
	void end_drag() { bar_drag_ = false; }
	// A pinned app pressed: a click launches it when let go, a drag moves it
	// among the others (saved in that order).
	bool pressing_pin() const { return pin_press_ >= 0; }
	void drag_pin(double lx, double ly);
	void release_pin(double lx, double ly);
	// Returns true if the key was used by the menu.
	bool handle_key(xkb_keysym_t sym, const std::string &text);

	NodeTag tag{NodeTag::Kind::Launcher, this};

private:
	struct FileHit {
		std::string path, name;
		bool dir = false;
	};
	void measure();               // sizes and places of everything
	int left_width() const;       // the home's left column (pinned apps, devices)
	// What's listed: the best few apps, then (when searching) files and
	// folders, then the rest of the apps (so a file isn't buried under a
	// long list of loosely matching apps).
	// The rows: the best few apps, the files, the settings pages, then the
	// rest of the apps (all apps when there are no files or settings).
	int count() const { return static_cast<int>(shown_.size() + files_.size() + settings_hits_.size()); }
	int extras() const { return static_cast<int>(files_.size() + settings_hits_.size()); }
	int apps_head() const {
		return extras() == 0 ? static_cast<int>(shown_.size()) : std::min(5, static_cast<int>(shown_.size()));
	}
	bool is_file(int i) const { return i >= apps_head() && i < apps_head() + static_cast<int>(files_.size()); }
	bool is_setting(int i) const {
		return i >= apps_head() + static_cast<int>(files_.size()) && i < apps_head() + extras();
	}
	const FileHit &file_of(int i) const { return files_[static_cast<size_t>(i - apps_head())]; }
	int setting_of(int i) const {
		return settings_hits_[static_cast<size_t>(i - apps_head() - static_cast<int>(files_.size()))];
	}
	int app_of(int i) const {
		return shown_[static_cast<size_t>(i < apps_head() ? i : i - extras())];
	}

	// The menu while nothing is typed: pinned apps and widgets, recent files
	// and every app (or the full list, A to Z, after "All apps").
	bool home() const { return query_.empty() && !all_apps_; }
	bool all_apps_ = false;
	struct Hot {
		std::string id;
		wlr_box box;
		double r;
	};
	std::vector<Hot> hots_;     // the home's chips, recent files, links and footer buttons
	int hover_hot_ = -1;
	int hot_at(double px, double py) const;
	void hot_action(const std::string &id);
	struct Recent {
		std::string path, name, where, when;
	};
	std::vector<Recent> recent_;
	void load_recent();
	std::vector<int> settings_hits_;   // Settings pages that match (indexes into the table)
	std::string calc_;                 // the answer, when what's typed is a sum
	wlr_box calc_box_{};
	void draw_header(cairo_t *cr, float scale);
	void draw_home(cairo_t *cr, float scale);
	void draw_devices(cairo_t *cr, int y, float scale);   // the connected devices' batteries
	int pinned_ = 0;
	std::string item_name(int i) const;
	std::string item_icon(int i) const;
	// Favourites (pinned in the app menu): a row above the list.
	int fav_at(double px, double py) const;
	wlr_box fav_box(int k) const;
	void item_menu(int item, int fav, double lx, double ly);
	void toggle_favourite(const std::string &id);
	// Files: searched for in the background as you type.
	void search_files();
	static int handle_search_timer(void *data);
	int max_first() const;
	void filter();
	void redraw();            // soon (once, however often it's asked for before then)
	void redraw_now();
	static void handle_redraw_idle(void *data);
	wl_event_source *redraw_idle_ = nullptr;
	void place();
	void launch(int row);
	void launch_app(const AppInfo &app);
	void keep_selection_visible();
	int visible_rows() const;
	int row_at(double px, double py) const;

	Server *server_;
	UiLayer layer_;
	Fades fx_;
	Highlight sel_;    // the selected row (keyboard)
	Highlight hl_;     // under the pointer
	void update_highlights();
	bool drawing_ = false;
	Output *output_ = nullptr;
	bool open_ = false;
	wlr_box box_{};
	wlr_box anchor_{};
	std::string edge_ = "bottom";
	uint64_t anim_ = 0;
	double alpha_ = 0.0;

	int w_ = 700, h_ = 620;
	std::string user_name_;
	// Your picture (the login screen's), read again when the file changes.
	cairo_surface_t *avatar_ = nullptr;
	std::string avatar_key_;   // path and time it was read from
	void load_avatar();

	std::vector<int> shown_;   // indexes into server_->apps.apps()
	std::vector<FileHit> files_;
	std::vector<int> favs_;    // the favourite apps (indexes into apps), shown while not searching
	wlr_box favs_area_{};      // where they're drawn (header and row)
	int list_top_ = 0;         // the list: where the rows start
	int hover_fav_ = -1;
	wl_event_source *search_timer_ = nullptr;
	unsigned search_gen_ = 0;
	std::string query_;
	int selected_ = 0;
	int first_row_ = 0;
	int hover_row_ = -1;
	double scroll_accum_ = 0;
	bool bar_drag_ = false;
	int pin_press_ = -1;            // the pinned app pressed (its index in favs_ now)
	bool pin_moving_ = false;       // dragged past a click's wobble
	double pin_x_ = 0, pin_y_ = 0;  // where it was pressed (local)
	double pin_px_ = 0, pin_py_ = 0;   // the pointer now (local), while moving
	bool on_bar(double px, double py) const;
	// The home: pinned apps a page (12) at a time, and the list of all apps
	// scrolled with the wheel (without going to "See all").
	int pin_page_ = 0;
	int pin_pages() const;
	int home_first_ = 0;           // the first app shown in the home's list
	int home_fit_ = 0;             // how many fit (as last drawn)
	wlr_box home_list_{};          // where the list is (as last drawn)
	double home_scroll_accum_ = 0;
	double last_px_ = -1, last_py_ = -1;   // the pointer (card coords), for the wheel
};

} // namespace arqen
