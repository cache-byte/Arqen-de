#include "ccentre.hpp"

#include <algorithm>
#include <cmath>
#include <ctime>
#include <fstream>
#include <map>
#include <sstream>
#include <tuple>
#include <pwd.h>
#include <unistd.h>
#include <linux/input-event-codes.h>

#include "apps.hpp"
#include "clipboard.hpp"
#include "draw.hpp"
#include "glyphs.hpp"
#include "launcher.hpp"
#include "lyrics.hpp"
#include "notify.hpp"
#include "panel.hpp"
#include "popover.hpp"
#include "system.hpp"

namespace arqen {

namespace {

constexpr int kWidth = 392;
constexpr int kPad = 16;
constexpr int kMargin = 10;      // from the screen edge / panel
constexpr int kCols = 6;         // the tile grid
constexpr int kGap = 8;
constexpr int kMaxRows = 14;

bool inside(const wlr_box &b, double x, double y) {
	return x >= b.x && y >= b.y && x < b.x + b.width && y < b.y + b.height;
}

// Which side of the screen a sidebar opens on: the side of its panel
// button (on a left or right panel, that edge). Without a button (the
// keyboard) it keeps its usual side.
bool opens_left(Server *server, Output *output, const wlr_box &anchor, const std::string &edge, bool usual) {
	if (edge == "left") return true;
	if (edge == "right") return false;
	if (!output || anchor.width <= 0 || anchor.height <= 0) return usual;
	(void)server;
	const wlr_box ob = output->box();
	return anchor.x + anchor.width / 2.0 < ob.x + ob.width / 2.0;
}

std::string ago(std::time_t when) {
	const long d = static_cast<long>(std::time(nullptr) - when);
	if (d < 60) return "now";
	if (d < 3600) return std::to_string(d / 60) + " min ago";
	if (d < 86400) return std::to_string(d / 3600) + " h ago";
	return std::to_string(d / 86400) + " d ago";
}

// An on/off switch; `t` goes 0 -> 1 as it turns on. Half way the knob
// stretches into a pill, so it looks like it's being pulled across.
void draw_switch(cairo_t *cr, double x, double y, double t) {
	t = std::clamp(t, 0.0, 1.0);
	fill_rounded(cr, x, y, 44, 24, 12, mix(theme::tile_off, theme::accent, t));
	const double stretch = 9 * std::sin(M_PI * t);
	const double kx = x + 3 + t * 20 - stretch * t;
	fill_rounded(cr, kx, y + 3, 18 + stretch, 18, 9, mix(rgb(0xffffff), theme::on_accent, t));
}

// ---- what can be a tile ------------------------------------------------------

struct TileDef {
	const char *id, *name, *kind;   // kind: toggle, slider, info, action
	int w, h;                        // size when added
};
const TileDef kTiles[] = {
	{"wifi", "Wi-Fi", "toggle", 3, 1},
	{"bluetooth", "Bluetooth", "toggle", 3, 1},
	{"dnd", "Do not disturb", "toggle", 1, 1},
	{"dark", "Dark mode", "toggle", 1, 1},
	{"nightlight", "Night light", "toggle", 1, 1},
	{"screenshot", "Screenshot", "action", 1, 1},
	{"airplane", "Airplane mode", "toggle", 1, 1},
	{"caffeine", "Caffeine", "toggle", 2, 1},
	{"power", "Power mode", "toggle", 1, 1},
	{"brightness", "Brightness", "slider", 1, 3},
	{"volume", "Volume", "slider", 1, 3},
	{"mic", "Microphone", "slider", 1, 3},
	{"battery", "Battery", "info", 3, 1},
	{"devices", "Connected devices", "info", 3, 2},
	{"kdeconnect", "KDE Connect", "info", 3, 2},
	{"sysmon", "System monitor", "info", 3, 2},
};

const TileDef *tile_def(const std::string &id) {
	for (const TileDef &d : kTiles) {
		if (id == d.id) return &d;
	}
	return nullptr;
}

// Tiles that make no sense on this computer are left out.
bool tile_available(Server *server, const std::string &id) {
	const SystemStatus &st = *server->status;
	if (id == "brightness") return st.has_brightness;
	// Without a battery (a desktop, or a dead one) the battery tile is just
	// the power mode selector, the same design.
	if (id == "battery") return st.has_battery || !st.power_profile.empty();
	if (id == "mic") return st.has_audio;
	// With a battery, its tile is the power mode tile too (one tile, not two).
	if (id == "power") return !st.power_profile.empty() && !st.has_battery;
	if (id == "kdeconnect") return st.kdeconnect_installed || !st.phones.empty();
	return tile_def(id) != nullptr;
}

// Two columns of square toggles on the left; brightness, volume, the
// microphone and the battery (with the power modes) as upright bars beside
// them; the system monitor under the bars; KDE Connect under the toggles;
// the connected Bluetooth devices full width at the bottom.
std::vector<CcTile> default_layout(Server *server) {
	std::vector<CcTile> l;
	// The toggles, two to a row, top to bottom.
	int n = 0;
	for (const char *id : {"wifi", "bluetooth", "caffeine", "nightlight", "dnd", "screenshot", "airplane", "dark"}) {
		if (!tile_available(server, id)) continue;
		l.push_back({id, n % 2, n / 2, 1, 1});
		n++;
	}
	// The bars, three rows tall; the battery is the power mode tile on a
	// computer without one (and is left out with neither).
	int col = 2;
	const char *power = tile_available(server, "battery") ? "battery" : tile_available(server, "power") ? "power" : nullptr;
	for (const char *id : {"brightness", "volume", "mic", power}) {
		if (!id || !tile_available(server, id)) continue;
		l.push_back({id, col++, 0, 1, 3});
	}
	// The system monitor under the bars, three rows tall, beside the last
	// toggles; the KDE Connect phone as a 2x2 ring under the toggles; then
	// the connected devices full width underneath (three rows: the device
	// large, with its name). Without KDE Connect the devices take its place.
	// (The toggles only ever take the first two columns.)
	const int below = std::max(3, (n + 1) / 2);
	if (tile_available(server, "sysmon")) l.push_back({"sysmon", 2, 3, kCols - 2, 3});
	const bool kdc = tile_available(server, "kdeconnect");
	if (kdc) l.push_back({"kdeconnect", 0, below, 2, 2});
	if (tile_available(server, "devices")) {
		if (kdc) l.push_back({"devices", 0, std::max(6, below + 2), kCols, 3});
		else l.push_back({"devices", 0, below, 2, 2});
	}
	// (No media card: what's playing is on the panel's now-playing chip.)
	return l;
}

void lyrics_note(Server *srv);

bool overlaps(const CcTile &a, const CcTile &b) {
	return a.c < b.c + b.w && b.c < a.c + a.w && a.r < b.r + b.h && b.r < a.r + a.h;
}

// Does `t` fit in `l` (not counting the tiles named)?
bool fits(const std::vector<CcTile> &l, const CcTile &t, const std::string &skip1,
		const std::string &skip2 = "") {
	if (t.c < 0 || t.r < 0 || t.w < 1 || t.h < 1 || t.c + t.w > kCols || t.r + t.h > kMaxRows) {
		return false;
	}
	for (const CcTile &o : l) {
		if (o.id != skip1 && o.id != skip2 && overlaps(o, t)) return false;
	}
	return true;
}

struct TileState {
	std::string icon, title, subtitle;
	bool on = false;
	bool usable = true;   // e.g. no Wi-Fi adapter
	int value = 0;        // sliders, 0..100
	bool muted = false;   // sliders
};

TileState tile_state(Server *server, const std::string &id) {
	const SystemStatus &st = *server->status;
	const Config &c = server->config;
	TileState i;
	if (id == "wifi") {
		i.title = "Wi-Fi";
		i.on = st.wifi_enabled && !st.airplane;
		i.usable = st.wifi_available;
		i.icon = !i.on ? "offline" : st.ssid.empty() ? "wifi-0" : wifi_icon(st.wifi_signal);
		i.subtitle = !i.usable ? "No adapter" : !i.on ? "Off"
			: st.net_kind == "ethernet" && st.ssid.empty() ? "Wired" : st.ssid.empty() ? "Not connected" : st.ssid;
	} else if (id == "bluetooth") {
		i.title = "Bluetooth";
		i.on = st.bt_powered;
		i.usable = st.bt_available;
		i.icon = i.on ? "bluetooth" : "bluetooth-off";
		i.subtitle = !i.usable ? "No adapter" : !st.bt_tool ? "Needs bluez" : !st.bt_service ? "Service off"
			: !i.on ? "Off" : st.bt_device.empty() ? "On" : st.bt_device;
	} else if (id == "sound") {
		i.title = "Sound";
		i.on = !st.muted;
		i.usable = st.has_audio;
		i.icon = speaker_icon(st.volume, st.muted);
		i.subtitle = st.muted ? "Muted" : std::to_string(st.volume) + "%";
	} else if (id == "dark") {
		i.title = "Dark mode";
		i.on = c.dark;
		i.icon = "moon";
		i.subtitle = c.dark ? "Dark" : "Light";
	} else if (id == "nightlight") {
		i.title = "Night light";
		i.on = c.night_light;
		i.icon = "nightlight";
		i.subtitle = c.night_light ? std::to_string(c.night_light_temp) + " K" : "Off";
	} else if (id == "dnd") {
		i.title = "Do not disturb";
		i.on = c.dnd;
		i.icon = c.dnd ? "bell-off" : "bell";
		i.subtitle = c.dnd ? "On" : "Off";
	} else if (id == "airplane") {
		i.title = "Airplane mode";
		i.on = st.airplane;
		i.icon = "airplane";
		i.subtitle = st.airplane ? "On" : "Off";
	} else if (id == "caffeine") {
		i.title = "Caffeine";
		i.on = st.caffeine;
		i.icon = "coffee";
		i.subtitle = st.caffeine ? "Staying awake" : "Off";
	} else if (id == "power") {
		i.title = "Power mode";
		i.usable = !st.power_profile.empty();
		i.on = i.usable && st.power_profile != "balanced";
		i.icon = "gauge-" + st.power_profile;
		i.subtitle = st.power_profile == "power-saver" ? "Power saver"
			: st.power_profile == "performance" ? "Performance" : i.usable ? "Balanced" : "Unavailable";
	} else if (id == "screenshot") {
		i.title = "Screenshot";
		i.icon = "screenshot";
		i.subtitle = "Area, window, screen";
	} else if (id == "brightness") {
		i.title = "Brightness";
		i.icon = "sun";
		i.value = st.brightness;
		i.usable = st.has_brightness;
	} else if (id == "volume") {
		i.title = "Volume";
		i.icon = speaker_icon(st.volume, st.muted);
		i.value = st.volume;
		i.muted = st.muted;
		i.usable = st.has_audio;
	} else if (id == "mic") {
		i.title = "Microphone";
		i.icon = st.mic_muted ? "mic-off" : "mic";
		i.value = st.mic_volume;
		i.muted = st.mic_muted;
		i.usable = st.has_audio;
	} else if (id == "battery") {
		// The battery and the power mode in one: click to change the mode.
		i.title = !st.has_battery ? std::string("Power mode")
			: std::to_string(st.battery) + "%" + (st.battery_state == "Charging" ? " · charging" : "");
		i.icon = st.has_battery ? battery_icon(st.battery, st.charging) : "gauge-" + st.power_profile;
		i.on = !st.power_profile.empty() && st.power_profile != "balanced";
		i.subtitle = st.power_profile.empty() ? "Battery"
			: std::string("Power mode: ") + (st.power_profile == "power-saver" ? "Power saver"
				: st.power_profile == "performance" ? "Performance" : "Balanced");
	} else if (id == "devices") {
		i.title = "Connected devices";
		i.icon = "bluetooth";
		i.subtitle = st.devices.empty() ? "None connected" : st.devices.front().name;
	} else if (id == "kdeconnect") {
		i.title = "KDE Connect";
		i.icon = "smartphone";
		i.subtitle = st.phones.empty() ? "No phone connected" : st.phones.front().name;
	} else if (id == "media") {
		i.title = st.media_available ? (st.media_title.empty() ? "Playing" : st.media_title) : "Nothing playing";
		i.subtitle = st.media_available ? st.media_artist : "";
		i.on = st.media_playing;
		i.icon = st.media_playing ? "pause" : "play";
	}
	return i;
}

std::string serialise(const std::vector<CcTile> &l) {
	std::string out;
	for (const CcTile &t : l) {
		out += (out.empty() ? "" : ",") + t.id + ":" + std::to_string(t.c) + ":" + std::to_string(t.r) + ":" +
			std::to_string(t.w) + ":" + std::to_string(t.h);
	}
	return out;
}


} // namespace

ControlCentre::ControlCentre(Server *server)
		: server_(server), layer_(server->layer_menu, &tag),
		fx_(server->anim.get(), [this] { if (open_ || alpha_ > 0) redraw(); }),
		hl_(layer_, server->anim.get()) {
	layer_.set_enabled(false);
	timer_ = wl_event_loop_add_timer(server->loop, &ControlCentre::handle_timer, this);
	redraw_timer_ = wl_event_loop_add_timer(server->loop, &ControlCentre::handle_redraw_timer, this);
	media_ = std::make_unique<MediaView>(server);
	busy_ = std::make_unique<BusyBar>(server->anim.get(), &layer_);
	live_ = wlr_scene_buffer_create(layer_.tree, nullptr);
	wlr_scene_node_place_above(&live_->node, &layer_.buffer->node);
	wlr_scene_node_set_enabled(&live_->node, false);
	// Your name: the full name from your account, else the login name.
	if (const passwd *pw = getpwuid(getuid())) {
		std::string gecos = pw->pw_gecos ? pw->pw_gecos : "";
		gecos = gecos.substr(0, gecos.find(','));
		user_name_ = gecos.empty() ? pw->pw_name : gecos;
		if (!user_name_.empty()) user_name_[0] = static_cast<char>(std::toupper(user_name_[0]));
	}
}

ControlCentre::~ControlCentre() {
	server_->anim->cancel(anim_);
	busy_.reset();
	if (media_ticker_) server_->anim->remove_ticker(media_ticker_);
	wl_event_source_remove(timer_);
	wl_event_source_remove(redraw_timer_);
	media_.reset();
	if (avatar_) cairo_surface_destroy(avatar_);
}

int ControlCentre::handle_timer(void *data) {
	auto *self = static_cast<ControlCentre *>(data);
	if (!self->open_) {
		return 0;
	}
	self->server_->status->refresh_media();
	// The connected devices' batteries change slowly: every third tick.
	if (++self->timer_ticks_ % 3 == 0 && self->shows_devices()) self->server_->status->refresh_devices();
	// The system monitor: drawn again with each reading (every two seconds).
	const bool mon = self->shows_sysmon() && !self->notes_only_;
	self->sysmon_.want(mon);
	if (mon && self->edit_tile_.empty()) self->redraw();
	wl_event_source_timer_update(self->timer_, mon ? 2000 : 3000);
	return 0;
}

bool ControlCentre::shows_sysmon() const {
	for (const CcTile &t : layout_) {
		if (t.id == "sysmon") return true;
	}
	return false;
}

bool ControlCentre::shows_devices() const {
	for (const CcTile &t : layout_) {
		if (t.id == "devices" || t.id == "kdeconnect") return true;
	}
	return editing_;
}

// ---- opening and closing ----------------------------------------------------

void ControlCentre::open_notes(Output *output, wlr_box anchor, const std::string &edge) {
	open(output, anchor, edge);
	left_side_ = opens_left(server_, output, anchor, edge, true);
	cal_offset_ = 0;
	notes_anchor_ = anchor;
	notes_edge_ = edge;
	notes_only_ = true;
	if (server_->notifications && server_->notifications->unseen) {
		server_->notifications->unseen = 0;
		server_->redraw_panels();
	}
	redraw();
	place();
}

void ControlCentre::toggle_notes(Output *output, wlr_box anchor, const std::string &edge) {
	if (notes_open_on(output)) close();
	else open_notes(output, anchor, edge);
}

void ControlCentre::open(Output *output, wlr_box anchor, const std::string &edge) {
	notes_only_ = false;
	// Seen now: the panel's bell goes (unless they have a centre of their own).
	if (server_->notifications && server_->notifications->unseen && !server_->config.separate_notes()) {
		server_->notifications->unseen = 0;
		server_->redraw_panels();
	}
	if (!output) {
		return;
	}
	output_ = output;
	// It opens on the side its panel button is on (usually the right; the
	// notifications usually the left).
	left_side_ = opens_left(server_, output, anchor, edge, false);
	open_ = true;
	page_ = Page::Tiles;
	editing_ = false;
	typing_ = false;
	notes_scroll_ = 0;
	open_groups_.clear();
	server_->status->refresh();
	server_->status->refresh_media();
	server_->status->refresh_devices();   // (also tells whether KDE Connect is there, for the edit tray)
	fx_.snap("notes", 0);
	redraw();
	place();
	layer_.set_enabled(true);
	layer_.raise();
	wl_event_source_timer_update(timer_, 3000);

	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 1.0, c.animate(c.anim_menu) ? c.ms(280) : 0,
		[this] { place(); }, [this] { anim_ = 0; });
	server_->redraw_panels();
}

void ControlCentre::close() {
	if (!open_) {
		return;
	}
	open_ = false;
	typing_ = false;
	editing_ = false;
	edit_tile_.clear();
	dragging_.clear();
	server_->cc_grab = false;
	if (media_->dragging()) media_->end_drag();
	media_->set_shown(false);
	sysmon_.want(false);
	wl_event_source_timer_update(timer_, 0);
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 0.0, c.animate(c.anim_menu) ? c.ms(200) : 0,
		[this] { place(); },
		[this] {
			anim_ = 0;
			if (!open_) {
				busy_->hide();
				layer_.set_enabled(false);
			}
		});
	server_->redraw_panels();
}

void ControlCentre::toggle(Output *output, wlr_box anchor, const std::string &edge) {
	if (open_ && output_ == output) {
		close();
	} else {
		open(output, anchor, edge);
	}
}

void ControlCentre::toggle(Output *output) {
	if (open_ || !output) {
		close();
		return;
	}
	for (const auto &panel : output->panels) {
		const auto &w = panel->config().widgets;
		if (std::find(w.begin(), w.end(), "status") != w.end()) {
			open(output, panel->anchor("status"), panel->config().edge);
			return;
		}
	}
	open(output, wlr_box{}, "right");
}

void ControlCentre::output_gone(Output *output) {
	if (output_ == output) {
		open_ = false;
		server_->anim->cancel(anim_);
		anim_ = 0;
		alpha_ = 0;
		busy_->hide();
		layer_.set_enabled(false);
		media_->set_shown(false);
		output_ = nullptr;
	}
}

void ControlCentre::refresh() {
	if (open_ || alpha_ > 0) {
		queue_redraw();   // (at most once a frame: status changes come in bursts)
	}
}

// A tall card along the side of the screen; slides in from that side, with
// a small spring at the end (like Arqen's).
void ControlCentre::place() {
	if (!output_) {
		return;
	}
	const wlr_box u = output_->usable();
	const double t = std::clamp(alpha_, 0.0, 1.1);
	const int x = left_side_ ? u.x + kMargin : u.x + u.width - width_ - kMargin;
	// From off the screen's edge, unless another screen is on that side (it
	// would show there): then a short slide while it fades.
	const wlr_box ob = output_->box();
	const double edge_x = left_side_ ? ob.x - 1.0 : ob.x + ob.width + 1.0;
	const bool neighbour = wlr_output_layout_output_at(server_->layout, edge_x, ob.y + ob.height / 2.0) != nullptr;
	// A short slide in from its side while it fades (not all the way from off the screen).
	(void)neighbour;
	const int reach = 40;
	const int slide = static_cast<int>(std::lround((1.0 - t) * reach));
	box_.x = x;
	// Sliding off the screen it can stay a little visible (it's gone past the
	// edge by the end); with the short slide it fades out completely, or
	// it would be left standing faintly and then vanish.
	const double alpha = std::min(1.0, t * t * (3 - 2 * std::min(1.0, t)));
	layer_.show(left_side_ ? x - slide : x + slide, box_.y, alpha, 1.0, 0, 0);
	place_live();
}

// Hover is drawn by the GPU highlight (no redraws while the mouse moves).
double ControlCentre::hv(const std::string &) {
	return 0.0;
}

// Cards inside follow the sidebar's corners: outer radius = inner + padding.
int ControlCentre::card_radius() const {
	return std::max(4, theme::ui_radius - 2);
}

bool ControlCentre::contains(double lx, double ly) const {
	return open_ && inside(box_, lx, ly);
}

// ---- drawing ------------------------------------------------------------------

void ControlCentre::add_hot(const std::string &id, double x, double y, double w, double h,
		double radius, wlr_box vis) {
	const wlr_box box{static_cast<int>(x), static_cast<int>(y), static_cast<int>(w),
		static_cast<int>(h)};
	hots_.push_back(Hot{id, box, vis.width > 0 ? vis : box,
		radius == -1 ? static_cast<double>(card_radius()) : radius});
}

void ControlCentre::update_highlight() {
	for (const Hot &h : hots_) {
		if (h.id == hover_ && h.radius >= 0) {
			hl_.show(h.vis, h.radius, with_alpha(theme::text, theme::dark ? 0.09 : 0.07));
			return;
		}
	}
	hl_.hide();
}

std::string ControlCentre::hot_at(double px, double py) const {
	for (auto it = hots_.rbegin(); it != hots_.rend(); ++it) {
		if (inside(it->box, px, py)) {
			return it->id;
		}
	}
	return "";
}

wlr_box ControlCentre::tile_box(const CcTile &t) const {
	const double step = cell_ + kGap, vstep = row_h_ + kGap;
	return wlr_box{static_cast<int>(std::lround(kPad + t.c * step)),
		static_cast<int>(std::lround(grid_top_ + t.r * vstep)),
		static_cast<int>(std::lround(t.w * cell_ + (t.w - 1) * kGap)),
		static_cast<int>(std::lround(t.h * row_h_ + (t.h - 1) * kGap))};
}

void ControlCentre::redraw() {
	if (!output_ || drawing_) {
		return;
	}
	drawing_ = true;
	const wlr_box u = output_->usable();
	// A tile can only be held while the pointer holds it.
	if (!edit_tile_.empty() && !server_->cc_grab) {
		edit_tile_.clear();
		edit_resize_ = false;
	}
	if (notes_only_) {
		redraw_notes();
		drawing_ = false;
		place();
		update_highlight();
		return;
	}
	width_ = kWidth;
	box_.width = width_;
	box_.x = left_side_ ? u.x + kMargin : u.x + u.width - width_ - kMargin;
	media_box_ = wlr_box{};

	// The layout: saved, or the default; only tiles that work here.
	if (edit_tile_.empty()) {
		const Config &cfg = server_->config;
		const auto &saved = cfg.cc_layout;
		layout_.clear();
		for (const CcTile &t : saved.empty() ? default_layout(server_) : saved) {
			if (tile_available(server_, t.id) && fits(layout_, t, "")) {
				layout_.push_back(t);
			}
		}
	}
	// A sidebar the height of the screen: what's playing (the last tile)
	// takes whatever room the others leave.
	box_.height = std::max(300, u.height - 2 * kMargin);
	if (!editing_) {
		const double cell = (kWidth - 2 * kPad - (kCols - 1) * kGap) / static_cast<double>(kCols);
		const int grid_top = kPad + 60;   // under the header
		const int fit_rows = static_cast<int>((box_.height - kPad - grid_top + kGap) / (cell + kGap));
		for (CcTile &t : layout_) {
			if (t.id != "media") continue;
			const bool below = std::any_of(layout_.begin(), layout_.end(),
				[&t](const CcTile &o) { return o.r >= t.r + t.h; });
			if (!below) t.h = std::clamp(fit_rows - t.r, 1, kMaxRows - t.r);
		}
	}

	const float scale = output_->output->scale;
	const double outer = card_radius() + kPad;
	const double slide = fx_.get("page");

	box_.y = u.y + kMargin;
	Canvas canvas(width_, box_.height, scale);
	cairo_t *cr = canvas.cr();
	hots_.clear();
	busy_box_ = wlr_box{};
	ui_card(cr, 0, 0, width_, box_.height, outer, with_alpha(theme::bg_alt, theme::ui_opacity));

	int y = kPad;
	draw_header(cr, y, scale);
	const int bottom = box_.height - kPad;

	// Changing page: the new one slides in and fades up.
	cairo_save(cr);
	cairo_rectangle(cr, 0, y - 4, width_, bottom - y + 4 + kPad);
	cairo_clip(cr);
	const double dx = slide * 60 * (page_ == Page::Tiles ? -1 : 1);
	cairo_translate(cr, dx, 0);
	cairo_push_group(cr);
	const size_t hots_before = hots_.size();
	if (page_ == Page::Tiles) {
		draw_grid(cr, y, scale);
		if (editing_) {
			draw_edit_tray(cr, y, scale);
		}
	} else if (page_ == Page::Options) {
		draw_options(cr, y, bottom, scale);
	} else if (page_ == Page::Sound) {
		draw_sound(cr, y, bottom, scale);
	} else {
		draw_detail(cr, y, bottom, scale);
	}
	cairo_pop_group_to_source(cr);
	cairo_paint_with_alpha(cr, 1.0 - 0.8 * std::fabs(slide));
	cairo_restore(cr);
	for (size_t i = hots_before; i < hots_.size(); i++) {
		hots_[i].box.x += static_cast<int>(std::lround(dx));
		hots_[i].vis.x += static_cast<int>(std::lround(dx));
	}
	media_live_ = page_ == Page::Tiles && !editing_ && media_box_.width > 0 && std::fabs(slide) < 0.01 &&
		media_box_.y + media_box_.height <= bottom;
	layer_.present(canvas, wlr_box{0, 0, width_, box_.height}, outer);
	if (busy_box_.width > 0 && std::fabs(slide) < 0.01 && open_) {
		busy_->show(busy_box_.x, busy_box_.y, busy_box_.width, busy_box_.height);
	} else {
		busy_->hide();
	}
	drawing_ = false;
	place();
	update_highlight();
	run_media();
}

// The notification sidebar on the left: the month, then the notifications,
// and Clear all at the bottom.
void ControlCentre::redraw_notes() {
	const wlr_box u = output_->usable();
	const float scale = output_->output->scale;
	width_ = 400;
	box_.width = width_;
	box_.x = left_side_ ? u.x + kMargin : u.x + u.width - width_ - kMargin;
	box_.y = u.y + kMargin;
	box_.height = std::max(300, u.height - 2 * kMargin);
	media_box_ = wlr_box{};
	media_live_ = false;
	wlr_scene_node_set_enabled(&live_->node, false);
	size_t count = 0;
	if (const Notifications *n = server_->notifications.get()) {
		for (const Notification &x : n->list()) count += !x.transient;
	}
	const double outer = card_radius() + kPad;
	Canvas canvas(width_, box_.height, scale);
	cairo_t *cr = canvas.cr();
	hots_.clear();
	ui_card(cr, 0, 0, width_, box_.height, outer, with_alpha(theme::bg_alt, theme::ui_opacity));

	// The calendar: the month and its arrows, the days of the week, the days.
	int y = kPad + 4;
	{
		const time_t now = time(nullptr);
		tm today{};
		localtime_r(&now, &today);
		tm first{};
		first.tm_year = today.tm_year;
		first.tm_mon = today.tm_mon + cal_offset_;
		first.tm_mday = 1;
		first.tm_hour = 12;
		mktime(&first);   // (normalises the month and year, fills in the weekday)
		char title[64];
		strftime(title, sizeof title, "%B %Y", &first);
		const int bs = 32;
		draw_text(cr, title, kPad, y, width_ - 2 * kPad, bs, theme::font_heading, theme::text, Align::Center);
		for (int k = 0; k < 2; k++) {
			const int bx = k == 0 ? kPad + 4 : width_ - kPad - 4 - bs;
			draw_named_icon(cr, server_->icons, k == 0 ? "chevron-left" : "chevron-right", bx + bs / 2.0 - 8, y + bs / 2.0 - 8,
				16, theme::text_dim, scale);
			add_hot(k == 0 ? "cal:prev" : "cal:next", bx, y, bs, bs, bs / 2.0);
		}
		y += bs + 10;
		const bool monday = server_->config.week_monday;
		static const char *kSun[] = {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};
		static const char *kMon[] = {"Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"};
		const double cw = (width_ - 2 * kPad - 16) / 7.0, gx = kPad + 8;
		for (int i = 0; i < 7; i++) {
			draw_text(cr, monday ? kMon[i] : kSun[i], gx + i * cw, y, cw, 20, theme::font_small, theme::text_dim,
				Align::Center);
		}
		y += 26;
		const int lead = monday ? (first.tm_wday + 6) % 7 : first.tm_wday;
		tm last = first;
		last.tm_mon += 1;
		last.tm_mday = 0;
		mktime(&last);
		const int days = last.tm_mday;
		const double rh = 36;
		const bool this_month = cal_offset_ == 0;
		for (int d = 1; d <= days; d++) {
			const int cell = lead + d - 1;
			const double cx = gx + (cell % 7) * cw + cw / 2, cy = y + (cell / 7) * rh + rh / 2;
			const bool is_today = this_month && d == today.tm_mday;
			if (is_today) {
				const double rr = 15;
				cairo_new_path(cr);
				chip_path(cr, cx, cy, rr);
				accent_gradient(cr, cx - rr, cy - rr, 2 * rr, 2 * rr);
				cairo_fill(cr);
			}
			draw_text(cr, std::to_string(d), cx - cw / 2, cy - rh / 2, cw, rh, is_today ? theme::font_bold : theme::font,
				is_today ? theme::on_gradient : theme::text, Align::Center);
		}
		y += static_cast<int>(((lead + days + 6) / 7) * rh) + 12;
	}

	// The notifications, under a line, in a card of their own.
	const int kFoot = 58;
	const int foot_y = box_.height - kFoot;
	{
		// Two tabs: the notifications and the clipboard history.
		const Clipboard *cb = server_->clipboard.get();
		const size_t clips = cb && server_->config.clipboard_history ? cb->history().size() : 0;
		const int th = 32;
		int tx = kPad;
		auto tab = [&](const char *hot, const std::string &label, bool on) {
			const int tw = text_width(label, theme::font_bold) + 30;
			fill_rounded(cr, tx, y - 2, tw, th, th / 2.0, on ? theme::accent : theme::tile_off);
			draw_text(cr, label, tx, y - 2, tw, th, theme::font_bold, on ? theme::on_accent : theme::text,
				Align::Center);
			add_hot(hot, tx, y - 2, tw, th, th / 2.0);
			tx += tw + 6;
		};
		tab("tab:notes", std::string("Notifications") + (count ? "  " + std::to_string(count) : ""), !clip_tab_);
		tab("tab:clips", std::string("Clipboard") + (clips ? "  " + std::to_string(clips) : ""), clip_tab_);
		if (!clip_tab_) {
			const bool dnd = server_->config.dnd;
			const int bs = 30, bx = width_ - kPad - bs;
			cairo_new_path(cr);
			chip_path(cr, bx + bs / 2.0, y + 14, bs / 2.0);
			set_color(cr, dnd ? theme::accent : theme::tile_off);
			cairo_fill(cr);
			draw_named_icon(cr, server_->icons, dnd ? "bell-off" : "bell", bx + bs / 2.0 - 8, y + 6, 16,
				dnd ? theme::on_accent : theme::text, scale);
			add_hot("ti:dnd", bx, y - 1, bs, bs, bs / 2.0);
		}
		y += 42;
	}
	if (clip_tab_) {
		draw_clips(cr, y, foot_y - 6, scale);
	} else {
		draw_notifications(cr, y, foot_y - 6, scale);
	}

	// Along the bottom: the settings, and Clear all.
	{
		const double fc = foot_y + kFoot / 2.0;
		const int bs = 36, gx = kPad;
		cairo_new_path(cr);
		chip_path(cr, gx + bs / 2.0, fc, bs / 2.0);
		set_color(cr, theme::tile_off);
		cairo_fill(cr);
		draw_named_icon(cr, server_->icons, "gear", gx + bs / 2.0 - 9, fc - 9, 18, theme::text, scale);
		add_hot("note-settings", gx, static_cast<int>(fc - bs / 2.0), bs, bs, bs / 2.0);
		const bool any_clips = server_->clipboard && !server_->clipboard->history().empty();
		if (clip_tab_ ? any_clips : count > 0) {
			const std::string label = "Clear all";
			const int cw = text_width(label, theme::font_bold) + 36, ch = 36;
			const int cx = width_ - kPad - cw;
			fill_rounded(cr, cx, fc - ch / 2.0, cw, ch, ch / 2.0, theme::tile_off);
			draw_text(cr, label, cx, fc - ch / 2.0, cw, ch, theme::font_bold, theme::text, Align::Center);
			add_hot("clear", cx, static_cast<int>(fc - ch / 2.0), cw, ch, ch / 2.0);
		}
	}
	layer_.present(canvas, wlr_box{0, 0, width_, box_.height}, outer);
}

// ---- What's playing -----------------------------------------------------------------

// The media card at `b`; its buttons become the control centre's.
void ControlCentre::draw_media(cairo_t *cr, const wlr_box &b, double radius, float scale, MediaView::Look look,
		bool hot) {
	std::vector<MediaHot> hots;
	media_->draw(cr, b.x, b.y, b.width, b.height, radius, scale, look, hot ? &hots : nullptr);
	media_box_ = b;
	media_look_ = look;
	media_radius_ = radius;
	for (const MediaHot &h : hots) {
		add_hot(h.id, h.box.x, h.box.y, h.box.width, h.box.height, h.radius);
	}
}

// Keeps the media card moving while it's on screen and something plays.
void ControlCentre::run_media() {
	const bool shown = open_ && media_box_.width > 0 && page_ == Page::Tiles;
	media_->set_shown(shown);
	if (!media_live_ || !shown) {
		wlr_scene_node_set_enabled(&live_->node, false);
		return;
	}
	redraw_live();
	if (!media_ticker_ && media_->moving()) {
		live_wait_ = 0;
		media_ticker_ = server_->anim->add_ticker([this](double dt) {
			const bool more = open_ && media_live_ && media_->step(dt);
			live_wait_ += dt;
			if (live_wait_ >= 33 || !more) {   // ~30 times a second is smooth for this
				live_wait_ = 0;
				redraw_live();
			}
			if (!more) media_ticker_ = 0;
			return more;
		});
	}
}

void ControlCentre::redraw_live() {
	if (!output_ || !media_live_ || media_box_.width <= 0) {
		wlr_scene_node_set_enabled(&live_->node, false);
		return;
	}
	const float scale = output_->output->scale;
	Canvas canvas(media_box_.width, media_box_.height, scale);
	media_->draw(canvas.cr(), 0, 0, media_box_.width, media_box_.height, media_radius_, scale, media_look_, nullptr);
	canvas.present(live_);
	wlr_scene_node_set_enabled(&live_->node, true);
	place_live();
}

void ControlCentre::place_live() {
	if (!live_ || media_box_.width <= 0) return;
	const double k = layer_.scale();
	wlr_scene_node_set_position(&live_->node, static_cast<int>(std::lround(layer_.map_x(media_box_.x))),
		static_cast<int>(std::lround(layer_.map_y(media_box_.y))));
	wlr_scene_buffer_set_dest_size(live_, std::max(1, static_cast<int>(std::lround(media_box_.width * k))),
		std::max(1, static_cast<int>(std::lround(media_box_.height * k))));
	wlr_scene_buffer_set_opacity(live_, static_cast<float>(layer_.alpha()));
}

// You (picture, name, how long the computer has been on) and round buttons:
// edit the tiles, Settings, power.
void ControlCentre::draw_header(cairo_t *cr, int &y, float scale) {
	// The day and date on the left; edit, Settings and power on the right.
	const int h = 48;
	const int buttons = 3, bsize = 40, bgap = 8;
	const int me_w = width_ - 2 * kPad - buttons * (bsize + bgap);
	{
		const time_t now = time(nullptr);
		tm lt{};
		localtime_r(&now, &lt);
		char day[32], date[48];
		strftime(day, sizeof day, "%A", &lt);
		strftime(date, sizeof date, "%-d %B", &lt);
		draw_text(cr, day, kPad + 4, y + 3, me_w - 6, 24, theme::font_heading, theme::text);
		draw_text(cr, date, kPad + 4, y + 26, me_w - 6, 18, theme::font_small, theme::text_dim);
	}
	(void)avatar_tried_;
	const struct {
		const char *id, *icon;
	} kButtons[] = {{"edit", "edit"}, {"settings", "gear"}, {"power", "power"}};
	int bx = kPad + me_w + bgap;
	for (const auto &b : kButtons) {
		const bool lit = std::string(b.id) == "edit" && editing_;
		cairo_new_path(cr);
		chip_path(cr, bx + bsize / 2.0, y + h / 2.0, bsize / 2.0);
		set_color(cr, lit ? theme::accent : theme::tile_off);
		cairo_fill(cr);
		draw_named_icon(cr, server_->icons, b.icon, bx + bsize / 2.0 - 9, y + h / 2.0 - 9, 18,
			lit ? theme::on_accent : theme::text, scale);
		add_hot(b.id, bx, y + (h - bsize) / 2, bsize, bsize, bsize / 2.0);
		bx += bsize + bgap;
	}
	y += h + 12;
}

namespace {

// What the battery is doing, in words.
std::string battery_words(const SystemStatus &st) {
	if (st.battery_state == "Charging") return "Charging";
	if (st.battery_state == "Full") return "Full";
	if (st.battery_state == "Not charging") return "Plugged in, not charging";
	return "On battery";
}

// Each power mode has its colour, made from the accent: warmer for
// Performance, greener for Power saver, the accent itself for Balanced.
Color power_mode_color(const std::string &mode) {
	if (mode == "performance") return mix(theme::accent, theme::warning, 0.6);
	if (mode == "power-saver") return mix(theme::accent, theme::success, 0.6);
	return theme::accent;
}

// Dark or white, whichever reads on `bg`.
Color readable_on(const Color &bg) {
	const double lum = 0.299 * bg.r + 0.587 * bg.g + 0.114 * bg.b;
	return lum > 0.62 ? rgb(0x1c1c1c) : rgb(0xffffff);
}

} // namespace

namespace {
// A device's picture, by what it is.
std::string device_glyph(const std::string &kind) {
	if (kind == "mouse") return "mouse";
	if (kind == "keyboard") return "keyboard";
	if (kind == "headphones") return "headphones";
	if (kind == "gamepad") return "gamepad-2";
	if (kind == "phone") return "smartphone";
	if (kind == "tablet") return "tablet-smartphone";
	if (kind == "speaker") return "speaker";
	if (kind == "computer") return "monitor-smartphone";
	return "bluetooth";
}

// "55% · charging · Bluetooth", or just how it's connected.
std::string device_line(const LinkedDevice &d) {
	std::string s;
	if (d.battery >= 0) s = std::to_string(d.battery) + "%" + (d.charging ? " · charging" : "");
	return s.empty() ? d.via : s + " · " + d.via;
}
} // namespace

// A device's picture on a soft disc, inside a ring that fills (clockwise
// from the top) with its battery; a green bolt badge while it charges.
// (The control centre's devices tiles and the app menu's devices.)
void draw_device_ring(cairo_t *cr, Server *server, double cx, double cy, double d, const LinkedDevice *dev,
		const std::string &empty_icon, float scale) {
	const double lw = std::max(3.0, d * 0.075);
	const double rr = d / 2 - lw / 2;
	cairo_save(cr);
	cairo_set_line_width(cr, lw);
	cairo_new_path(cr);
	cairo_arc(cr, cx, cy, rr, 0, 2 * M_PI);
	set_color(cr, with_alpha(theme::text, theme::dark ? 0.12 : 0.10));
	cairo_stroke(cr);
	if (dev && dev->battery >= 0) {
		const double f = std::clamp(dev->battery / 100.0, 0.0, 1.0);
		const bool low = dev->battery <= 15 && !dev->charging;
		cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
		cairo_new_path(cr);
		cairo_arc(cr, cx, cy, rr, -M_PI / 2, -M_PI / 2 + 2 * M_PI * std::max(0.01, f));
		set_color(cr, low ? theme::danger : dev->charging ? theme::success : theme::accent);
		cairo_stroke(cr);
	}
	cairo_restore(cr);
	cairo_new_path(cr);
	cairo_arc(cr, cx, cy, rr - lw * 1.1, 0, 2 * M_PI);
	set_color(cr, dev ? with_alpha(theme::accent, theme::dark ? 0.22 : 0.14) : with_alpha(theme::text, 0.06));
	cairo_fill(cr);
	const double is = std::round(d * 0.42);
	draw_named_icon(cr, server->icons, dev ? device_glyph(dev->kind) : empty_icon,
		cx - is / 2, cy - is / 2, is, dev ? theme::text : theme::text_dim, scale);
	if (dev && dev->charging && d >= 40) {
		const double zr = std::max(7.0, d * 0.13), zx = cx + rr * 0.72, zy = cy + rr * 0.72;
		cairo_new_path(cr);
		cairo_arc(cr, zx, zy, zr, 0, 2 * M_PI);
		set_color(cr, theme::success);
		cairo_fill(cr);
		draw_named_icon(cr, server->icons, "zap", zx - zr * 0.6, zy - zr * 0.6, zr * 1.2, readable_on(theme::success), scale);
	}
}

std::string device_short_name(const std::string &name) {
	// "Joseph's S23 Ultra", "Joseph’s Pixel": what comes after the owner.
	for (const char *mark : {"'s ", "\u2019s "}) {
		const size_t at = name.find(mark);
		if (at != std::string::npos && at > 0 && name.find(' ') >= at) {
			const std::string rest = name.substr(at + std::string(mark).size());
			if (!rest.empty()) return rest;
		}
	}
	return name;
}

void ControlCentre::draw_devices_tile(cairo_t *cr, const CcTile &t, const wlr_box &b, double radius, float scale,
		bool floating) {
	const SystemStatus &st = *server_->status;
	const bool kdc = t.id == "kdeconnect";
	const std::vector<LinkedDevice> &list = kdc ? st.phones : st.devices;
	const bool edit = editing_;
	fill_rounded(cr, b.x, b.y, b.width, b.height, radius, theme::tile_off);
	if (!edit && !floating) add_hot("tm:" + t.id, b.x, b.y, b.width, b.height, radius);

	// The picture: the device's icon on a soft disc, inside a ring that
	// fills (clockwise from the top) with its battery.
	auto picture = [&](double cx, double cy, double d, const LinkedDevice *dev) {
		draw_device_ring(cr, server_, cx, cy, d, dev, kdc ? "smartphone" : "bluetooth", scale);
	};
	const double pad = 10;
	const bool tiny = b.width < 1.6 * cell_ || b.height < 0.8 * row_h_;
	const bool tall = b.height >= 1.6 * row_h_;

	if (list.empty()) {
		if (tiny || !tall) {
			const double d = std::min(b.width, b.height) - 2 * pad;
			if (tiny) {
				picture(b.x + b.width / 2.0, b.y + b.height / 2.0, d, nullptr);
				return;
			}
			picture(b.x + pad + d / 2, b.y + b.height / 2.0, d, nullptr);
			const double tx = b.x + 2 * pad + d, tw = b.x + b.width - tx - pad;
			draw_text(cr, kdc ? "KDE Connect" : "Devices", tx, b.y + b.height / 2.0 - 19, tw, 20, theme::font_bold, theme::text);
			draw_text(cr, kdc ? "No phone connected" : "None connected", tx, b.y + b.height / 2.0 + 1, tw, 17,
				theme::font_small, theme::text_dim);
			return;
		}
		const double d = std::min({56.0, b.height - 56.0, b.width - 2 * pad});
		picture(b.x + b.width / 2.0, b.y + pad + 6 + d / 2, d, nullptr);
		draw_text(cr, kdc ? "No phone connected" : "No devices connected", b.x + pad, b.y + pad + 14 + d, b.width - 2 * pad,
			20, theme::font_small, theme::text_dim, Align::Center);
		return;
	}

	const LinkedDevice &first = list.front();
	const int n = static_cast<int>(list.size());
	// Its battery in numbers ("" when the device doesn't say).
	auto percent = [](const LinkedDevice &dv) {
		return dv.battery >= 0 ? std::to_string(dv.battery) + "%" : std::string();
	};

	// Every device as a small ring (its picture inside, its battery around
	// it) with the percentage under it, spread over the tile: the
	// arrangement that fits them all with the biggest rings. Used when the
	// tile is too small for names, at any size (1x1, 1 wide and tall, 2x1...),
	// the same as the system monitor's rings.
	auto rings = [&](bool all_or_nothing) {
		const double ip = 4, aw = b.width - 2 * ip, ah = b.height - 2 * ip;
		const bool need_label = true;   // the name, and the battery
		const double lh = 15;                 // the percentage's line
		const double min_w = 30, min_d = 20;  // smaller than this can't be read
		int best_cols = 0;
		double best_d = 0;
		for (int cols = 1; cols <= n; cols++) {
			const int rws = (n + cols - 1) / cols;
			const double sw = aw / cols, sh = ah / rws;
			const double d = std::min({sw - 2, sh - (need_label ? lh : 0.0) - 2, 64.0});
			if (sw < min_w || d < min_d) continue;
			if (d > best_d + 0.5) {
				best_d = d;
				best_cols = cols;
			}
		}
		int shown = n, cols = best_cols;
		bool label = need_label;
		if (!best_cols) {
			if (all_or_nothing) return false;
			// Not room for them all: as many as fit, the last one saying how many more.
			cols = std::max(1, static_cast<int>(aw / min_w));
			const int rws = std::max(1, static_cast<int>(ah / (min_d + lh + 2)));
			shown = std::min(n, cols * rws);
			cols = std::min(cols, shown);
			label = true;
		}
		const int rws = (shown + cols - 1) / cols;
		// A slot no wider than the app menu's, the rings grouped in the middle.
		const double sw = std::min(aw / cols, 116.0), sh = ah / rws;   // room for "S23 Ultra · 20%"
		const double d = std::max(16.0, std::min({sw - 2, sh - (label ? lh : 0.0) - 2, 64.0}));
		const double x0 = b.x + ip + (aw - cols * sw) / 2;
		for (int k = 0; k < shown; k++) {
			const LinkedDevice &dv = list[static_cast<size_t>(k)];
			// The last row, when it isn't full, is centred.
			const int row = k / cols, in_row = std::min(cols, shown - row * cols);
			const double off = (cols - in_row) * sw / 2;
			const double sx = x0 + off + (k % cols) * sw, sy = b.y + ip + row * sh;
			const double block = d + (label ? lh : 0);
			const double cy = sy + (sh - block) / 2 + d / 2;
			const bool last_more = k == shown - 1 && n > shown;
			picture(sx + sw / 2, cy, d, &dv);
			if (label) {
				// Which device it is and its battery ("S23 Ultra · 20%"), so two
				// phones can be told apart; just the battery when the name won't
				// fit. The last one shown says how many more there are.
				const std::string more = last_more ? "+" + std::to_string(n - shown) : std::string();
				const std::string pc = percent(dv).empty() ? more : more.empty() ? percent(dv) : percent(dv) + " " + more;
				const std::string nm = device_short_name(dv.name);
				const std::string full = pc.empty() ? nm : nm + " · " + pc;
				const double room = sw - 4;
				const std::string txt = text_width(full, theme::font_small) <= room ? full
					: room >= 56 && !last_more ? nm   // ellipsised; the ring still shows the battery
					: pc;
				if (!txt.empty()) {
					const bool low = dv.battery >= 0 && dv.battery <= 15 && !dv.charging && !last_more;
					draw_text(cr, txt, sx + 2, cy + d / 2 + 1, sw - 4, lh, theme::font_small,
						low ? theme::danger : theme::text, Align::Center);
				}
			}
		}
		return true;
	};

	// A device with its name: the ring, the name, and "55% · Bluetooth".
	auto named = [&](const LinkedDevice &dv, double x, double y, double w, double h, const std::string &extra) {
		const double d = std::min(h - 14, 44.0);
		picture(x + pad + d / 2, y + h / 2, d, &dv);
		const double tx = x + 2 * pad + d, tw = x + w - tx - pad;
		draw_text(cr, dv.name, tx, y + h / 2 - 19, tw, 20, theme::font_bold, theme::text);
		draw_text(cr, device_line(dv) + extra, tx, y + h / 2 + 1, tw, 17, theme::font_small, theme::text_dim);
	};

	// The room each named device needs.
	const double named_w = 2.6 * cell_, named_h = 44;
	const int name_cols = std::max(1, static_cast<int>((b.width + kGap) / (named_w + kGap)));
	const bool names_fit = b.width >= named_w && b.height >= 0.8 * row_h_;

	// One row tall (6x1, 3x1...): every device as a small ring with its
	// picture and battery, the same as the app menu's devices, rather than
	// names that only leave room for one or two.
	if (!names_fit || !tall) {
		rings(false);
		return;
	}
	if (tall && n == 1) {
		// One device, room to show it: the picture large, its name and battery underneath.
		const double d = std::min({96.0, b.height - 62.0, b.width - 2 * pad});
		const double cy = b.y + pad + 4 + d / 2;
		picture(b.x + b.width / 2.0, cy, d, &first);
		draw_text(cr, first.name, b.x + pad, cy + d / 2 + 6, b.width - 2 * pad, 20, theme::font_bold, theme::text,
			Align::Center);
		draw_text(cr, device_line(first), b.x + pad, cy + d / 2 + 26, b.width - 2 * pad, 17, theme::font_small,
			theme::text_dim, Align::Center);
		return;
	}
	// Named devices as a list, one under another with the whole width for
	// the name; a second column only once the rows run out.
	const int name_rows = std::max(1, static_cast<int>((b.height - (tall ? 12 : 0)) / named_h));
	const int cap = name_cols * name_rows;
	if (cap < n && rings(true)) return;   // all of them as rings rather than "+2 more"
	const int shown = std::min(n, cap);
	const int cols = std::min(name_cols, (shown + name_rows - 1) / name_rows), rws = (shown + cols - 1) / cols;
	const double cw = b.width / cols;
	const double rh = tall ? std::min(58.0, (b.height - 12.0) / rws) : b.height / rws;
	const double top = b.y + (b.height - rws * rh) / 2.0;
	for (int k = 0; k < shown; k++) {
		const LinkedDevice &dv = list[static_cast<size_t>(k)];
		const int more = n - shown;
		const std::string extra = k == shown - 1 && more > 0 ? " · +" + std::to_string(more) + " more" : "";
		named(dv, b.x + (k % cols) * cw, top + (k / cols) * rh, cw, rh, extra);
	}
}

// The System monitor tile: CPU, graphics, memory as bars with their share
// (wide), or as rings with the number inside (narrow); what it shows is
// chosen in its options.
void ControlCentre::draw_sysmon_tile(cairo_t *cr, const CcTile &t, const wlr_box &b, double radius, float scale,
		bool floating) {
	(void)scale;
	fill_rounded(cr, b.x, b.y, b.width, b.height, radius, theme::tile_off);
	if (!editing_ && !floating) add_hot("tm:" + t.id, b.x, b.y, b.width, b.height, radius);
	const SysSample s = sysmon_.sample();
	struct Row {
		std::string label;
		double v;
		std::string extra;
		bool off;
	};
	std::vector<Row> rows;
	char gb[64];
	for (const std::string &k : split_list(server_->config.cc_sysmon)) {
		if (k == "cpu") rows.push_back({"CPU", s.cpu, "", false});
		else if (k == "igpu" && s.has_igpu) rows.push_back({s.has_gpu ? "iGPU" : "GPU", s.igpu, "", false});
		else if (k == "gpu" && s.has_gpu) rows.push_back({"GPU", s.gpu, "", s.gpu_asleep});
		else if (k == "ram") {
			std::snprintf(gb, sizeof gb, "%.1f / %.0f GB", s.ram_used_gb, s.ram_total_gb);
			rows.push_back({"RAM", s.ram, gb, false});
		} else if (k == "swap" && s.has_swap) {
			std::snprintf(gb, sizeof gb, "%.1f / %.0f GB", s.swap_used_gb, s.swap_total_gb);
			rows.push_back({"Swap", s.swap, gb, false});
		}
	}
	if (rows.empty()) rows.push_back({"CPU", s.cpu, "", false});
	auto pct = [](const Row &r) {
		if (r.off) return std::string("Off");
		if (r.v < 0) return std::string("–");
		return std::to_string(static_cast<int>(std::lround(r.v * 100))) + "%";
	};
	auto colour = [](const Row &r) {
		return r.v >= 0.9 ? theme::danger : r.v >= 0.75 ? mix(theme::accent, theme::warning, 0.5) : theme::accent;
	};
	const double pad = 12;
	// Rings when narrow, and when one row tall (6x1...): bars that short only fit two.
	const bool narrow = b.width < 2.6 * cell_ || b.height < 1.6 * row_h_;

	if (!narrow) {
		// A row each: the name, a bar, the share (and the gigabytes when there's room).
		const double ah = b.height - 2 * pad;
		const int fit = std::max(1, static_cast<int>(ah / 24.0));
		const int n = std::min<int>(fit, static_cast<int>(rows.size()));
		const double rh = std::min(40.0, ah / n);
		const double top = b.y + (b.height - rh * n) / 2.0;
		const bool gbs = b.width >= 5 * cell_;
		const double label_w = 42, value_w = gbs ? 128 : 44;
		for (int i = 0; i < n; i++) {
			const Row &r = rows[static_cast<size_t>(i)];
			const double cy = top + i * rh + rh / 2;
			draw_text(cr, r.label, b.x + pad, cy - 10, label_w, 20, theme::font_bold, theme::text);
			const double bx = b.x + pad + label_w + 6, bw = b.width - 2 * pad - label_w - 6 - value_w - 8;
			const double bh = std::clamp(rh * 0.28, 6.0, 10.0);
			fill_rounded(cr, bx, cy - bh / 2, bw, bh, bh / 2, with_alpha(theme::text, theme::dark ? 0.14 : 0.10));
			if (r.v > 0 && !r.off) {
				fill_rounded(cr, bx, cy - bh / 2, std::max(bh, bw * std::clamp(r.v, 0.0, 1.0)), bh, bh / 2, colour(r));
			}
			const std::string val = gbs && !r.extra.empty() ? pct(r) + "  " + r.extra : pct(r);
			draw_text(cr, val, b.x + b.width - pad - value_w, cy - 10, value_w, 20, theme::font_small,
				r.off ? theme::text_dim : theme::text, Align::Right);
		}
		return;
	}

	// Narrow: rings, the share inside and the name under, over the whole tile.
	const double ip = 4, aw = b.width - 2 * ip, ah = b.height - 2 * ip;
	const int cols = std::max(1, static_cast<int>(aw / 46.0));
	const int rows_fit = std::max(1, static_cast<int>(ah / 62.0));
	const int shown = std::min<int>(static_cast<int>(rows.size()), cols * rows_fit);
	const int uc = std::min(cols, shown), ur = (shown + uc - 1) / uc;
	const double sw = aw / uc, sh = ah / ur;
	const bool label = sh >= 44;
	const double d = std::max(18.0, std::min({sw - 2 * ip, sh - (label ? 16.0 : 0.0) - 2, 72.0}));
	for (int k = 0; k < shown; k++) {
		const Row &r = rows[static_cast<size_t>(k)];
		const double sx = b.x + ip + (k % uc) * sw, sy = b.y + ip + (k / uc) * sh;
		const double block = d + (label ? 16 : 0);
		const double cx = sx + sw / 2, cy = sy + (sh - block) / 2 + d / 2;
		const double lw = std::max(3.0, d * 0.09), rr = d / 2 - lw / 2;
		cairo_save(cr);
		cairo_set_line_width(cr, lw);
		cairo_new_path(cr);
		cairo_arc(cr, cx, cy, rr, 0, 2 * M_PI);
		set_color(cr, with_alpha(theme::text, theme::dark ? 0.14 : 0.10));
		cairo_stroke(cr);
		if (r.v > 0 && !r.off) {
			cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
			cairo_new_path(cr);
			cairo_arc(cr, cx, cy, rr, -M_PI / 2, -M_PI / 2 + 2 * M_PI * std::clamp(r.v, 0.01, 1.0));
			set_color(cr, colour(r));
			cairo_stroke(cr);
		}
		cairo_restore(cr);
		draw_text(cr, pct(r), cx - d / 2, cy - 9, d, 18, d >= 40 ? theme::font_bold : theme::font_small,
			r.off ? theme::text_dim : theme::text, Align::Center);
		if (label) {
			draw_text(cr, r.label, sx, cy + d / 2 + 1, sw, 15, theme::font_small, theme::text_dim, Align::Center);
		}
	}
}

void ControlCentre::draw_tile(cairo_t *cr, const CcTile &t, const wlr_box &b, float scale,
		bool floating) {
	const TileDef *def = tile_def(t.id);
	if (!def) return;
	const TileState s = tile_state(server_, t.id);
	const std::string kind = def->kind;
	const double r_tile = std::min<double>(card_radius(), std::min(b.width, b.height) / 2.0);
	const double r = r_tile;
	const std::string id = t.id;
	const bool edit = editing_;
	if (kind == "slider") {
		// A bar that fills from the bottom (upright) or from the left.
		const bool vertical = b.height > b.width;
		const std::string vkey = "val:" + id;
		if (dragging_ == "sl:" + id) fx_.snap(vkey, s.value);
		else fx_.set(vkey, s.value, s.value);
		const double v = std::clamp(fx_.get(vkey), 0.0, 100.0) / 100.0;
		// Samsung's: a pill, filled from the start by a pill of the accent colour.
		const double pr = std::min(b.width, b.height) / 2.0;
		fill_rounded(cr, b.x, b.y, b.width, b.height, pr, theme::tile_off);
		cairo_save(cr);
		rounded_rect(cr, b.x, b.y, b.width, b.height, pr);
		cairo_clip(cr);
		const Color fill = s.muted ? theme::text_dim : theme::accent;
		if (vertical) {
			const double fh = std::max<double>(b.width, b.height * v);
			rounded_rect(cr, b.x, b.y + b.height - fh, b.width, fh, pr);
		} else {
			const double fw = std::max<double>(b.height, b.width * v);
			rounded_rect(cr, b.x, b.y, fw, b.height, pr);
		}
		if (s.muted) set_color(cr, fill);
		else accent_gradient(cr, b.x, b.y, b.width, b.height);
		cairo_fill(cr);
		cairo_restore(cr);
		const double isz = 20;
		double ix, iy;
		if (vertical) {
			ix = b.x + b.width / 2.0 - isz / 2;
			iy = b.y + b.height - isz - 12;
		} else {
			ix = b.x + b.height / 2.0 - isz / 2;
			iy = b.y + b.height / 2.0 - isz / 2;
		}
		const bool icon_on_fill = true;   // the fill always covers the icon's end
		draw_named_icon(cr, server_->icons, s.icon, ix, iy, isz,
			icon_on_fill ? theme::on_accent : theme::text, scale);
		if (vertical) {
			// The number at the top, small and quiet (brighter while dragged).
			draw_text(cr, std::to_string(s.value), b.x, b.y + 10, b.width, 18,
				dragging_ == "sl:" + id ? theme::font_bold : theme::font_small,
				v > 0.88 ? theme::on_accent : dragging_ == "sl:" + id ? theme::text : theme::text_dim, Align::Center);
		} else if (!vertical && dragging_ == "sl:" + id && b.width >= 3 * cell_) {
			draw_text(cr, std::to_string(s.value) + "%", b.x + b.width - 60, b.y, 44, b.height,
				theme::font_bold, v > 0.86 ? theme::on_accent : theme::text, Align::Right);
		}
		if (!edit && !floating) {
			add_hot("sl:" + id, b.x, b.y, b.width, b.height, -2);
			if (dragging_ == "sl:" + id) {
				drag_track_ = b;
				drag_vertical_ = vertical;
			}
		}
		return;
	}

	if (id == "media") {
		// Samsung's media card (see mediaview.cpp).
		draw_media(cr, b, r, scale, MediaView::Look::Samsung, !edit && !floating);
		if (floating || edit) media_box_ = wlr_box{};
		return;
	}

	if (id == "devices" || id == "kdeconnect") {
		draw_devices_tile(cr, t, b, r_tile, scale, floating);
		return;
	}
	if (id == "sysmon") {
		draw_sysmon_tile(cr, t, b, r_tile, scale, floating);
		return;
	}

	if (id == "battery") {
		// The charge fills the tile like a gauge, in the power mode's colour
		// (red when it's running low); the three modes sit at the right end.
		const SystemStatus &st = *server_->status;
		const std::string &mode = st.power_profile;
		const bool has_bat = st.has_battery;
		const bool low = has_bat && st.battery <= 15 && st.battery_state == "Discharging";
		const Color mc = low ? theme::danger : power_mode_color(mode);
		// Smooth changes: the level, and the colour from one mode to the next.
		fx_.set("bat:level", has_bat ? st.battery : 0, has_bat ? st.battery : 0);
		const double level = std::clamp(fx_.get("bat:level"), 0.0, 100.0) / 100.0;
		// When the mode (or low battery) changes the colour, it eases across.
		const std::string ck = "bat:col";
		static Color from = mc, target = mc;
		if (mc.r != target.r || mc.g != target.g || mc.b != target.b) {
			from = mix(from, target, 1.0 - std::clamp(fx_.get(ck), 0.0, 1.0));
			target = mc;
			fx_.snap(ck, 1);
			fx_.set(ck, 0);
		}
		const Color col = mix(from, target, 1.0 - std::clamp(fx_.get(ck), 0.0, 1.0));
		// Its shape decides the layout: a bar lying down, or a gauge standing up.
		const bool upright = b.height > b.width * 1.2;
		// (macOS: a module like the others, not a pill.)
		const double r = t.h == 1 || upright ? std::min(b.width, b.height) / 2.0 : r_tile;
		fill_rounded(cr, b.x, b.y, b.width, b.height, r, with_alpha(col, theme::dark ? 0.20 : 0.16));
		cairo_save(cr);
		rounded_rect(cr, b.x, b.y, b.width, b.height, r);
		cairo_clip(cr);
		if (upright) cairo_rectangle(cr, b.x, b.y + b.height * (1 - level), b.width, b.height * level);
		else cairo_rectangle(cr, b.x, b.y, b.width * level, b.height);
		set_color(cr, with_alpha(col, theme::dark ? 0.55 : 0.45));
		cairo_fill(cr);
		cairo_restore(cr);
		if (!edit && !floating) add_hot("tm:battery", b.x, b.y, b.width, b.height, r);

		const bool modes = !mode.empty();
		const std::string pct = has_bat ? std::to_string(st.battery) + "%" : std::string("Power mode");
		static const char *kModes[] = {"power-saver", "balanced", "performance"};
		// The three modes as round buttons on a soft pill, in a row or a column.
		auto mode_buttons = [&](double gx, double gy, int bs, bool column) {
			const double gw = column ? bs + 8 : 3 * bs + 2 * 3 + 8, gh = column ? 3 * bs + 2 * 3 + 8 : bs + 8;
			// (Windows 11: square-cornered, like its buttons.)
			const bool square = false;
			const double sr = square ? theme::small_radius() : 0;
			fill_rounded(cr, gx, gy, gw, gh, square ? sr : std::min(gw, gh) / 2.0, with_alpha(theme::card_bg, 0.75));
			for (int m = 0; m < 3; m++) {
				const std::string pm = kModes[m];
				const double cx = column ? gx + 4 + bs / 2.0 : gx + 4 + bs / 2.0 + m * (bs + 3);
				const double cy = column ? gy + 4 + bs / 2.0 + m * (bs + 3) : gy + 4 + bs / 2.0;
				const bool chosen = pm == mode;
				const double is = std::min(16, bs - 8);
				if (chosen) {
					const Color pc = power_mode_color(pm);
					cairo_new_path(cr);
					if (square) rounded_rect(cr, cx - bs / 2.0, cy - bs / 2.0, bs, bs, std::max(1.5, sr - 2));
					else cairo_arc(cr, cx, cy, bs / 2.0, 0, 2 * M_PI);
					set_color(cr, pc);
					cairo_fill(cr);
					draw_named_icon(cr, server_->icons, "gauge-" + pm, cx - is / 2, cy - is / 2, is, readable_on(pc), scale);
				} else {
					draw_named_icon(cr, server_->icons, "gauge-" + pm, cx - is / 2, cy - is / 2, is, theme::text_dim, scale);
				}
				if (!edit && !floating) {
					add_hot("pp:" + pm, static_cast<int>(cx - bs / 2.0), static_cast<int>(cy - bs / 2.0), bs, bs,
						square ? std::max(1.5, sr - 2) : bs / 2.0);
				}
			}
		};
		if (upright) {
			// Standing: the number on top, the modes in a column underneath (if they fit).
			draw_text(cr, pct, b.x, b.y + 10, b.width, 22, theme::font_bold, theme::text, Align::Center);
			if (has_bat && st.battery_state == "Charging") {
				draw_named_icon(cr, server_->icons, "zap", b.x + b.width / 2.0 - 7, b.y + 32, 14, theme::text, scale);
			}
			const int bs = std::min(26, b.width - 16);
			if (modes && bs >= 18 && b.height >= 3 * bs + 70) {
				mode_buttons(b.x + (b.width - bs - 8) / 2.0, b.y + b.height - (3 * bs + 2 * 3 + 8) - 8, bs, true);
			}
			return;
		}
		// (Windows' rows are short: a tighter two lines, and the buttons nearly its height.)
		const bool tight = false;
		const int bs = std::min(26, b.height - (tight ? 12 : 18));
		const bool row = modes && b.width >= 3 * bs + 2 * 3 + 8 + 80;
		const int group_w = row ? 3 * bs + 2 * 3 + 8 : 0;
		const double tx = b.x + std::max(10.0, r * 0.6) + (tight ? 4 : 0), tw = b.x + b.width - tx - group_w - 10;
		const bool two_lines = b.height >= (tight ? 34 : 44);
		const double l1 = tight ? 18 : 22, top = tight ? b.y + b.height / 2.0 - 17 : b.y + b.height / 2.0 - 20;
		draw_text(cr, pct, tx, two_lines ? top : b.y, tw, two_lines ? l1 : b.height,
			two_lines && !tight ? theme::font_large : theme::font_bold, theme::text);
		if (has_bat && st.battery_state == "Charging") {
			const double gx = tx + text_width(pct, two_lines && !tight ? theme::font_large : theme::font_bold) + 6;
			if (gx + 14 < tx + tw) {
				draw_named_icon(cr, server_->icons, "zap", gx,
					two_lines ? top + (l1 - 14) / 2 + (tight ? 0 : 3) : b.y + b.height / 2.0 - 7, 14, theme::text, scale);
			}
		}
		if (two_lines) {
			const std::string sub = !modes ? battery_words(st)
				: mode == "performance" ? "Performance" : mode == "power-saver" ? "Power saver" : "Balanced";
			draw_text(cr, sub, tx, tight ? top + l1 : b.y + b.height / 2.0 + 2, tw, tight ? 16 : 17, theme::font_small,
				with_alpha(theme::text, 0.75));
		}
		if (row) mode_buttons(b.x + b.width - group_w - 6, b.y + (b.height - bs - 8) / 2.0, bs, false);
		return;
	}

	// Toggles, screenshot.
	const std::string on_key = "on:" + id;
	const bool on = s.on && s.usable;
	fx_.set(on_key, on ? 1.0 : 0.0, on ? 1.0 : 0.0);
	const double onv = std::clamp(fx_.get(on_key), 0.0, 1.0);
	const double press = fx_.get("press:" + id);
	const Color off_fill = !s.usable ? with_alpha(theme::tile_off, theme::tile_off.a * 0.5) : theme::tile_off;
	const Color fill = mix(off_fill, theme::accent, onv);
	const Color fg = !s.usable ? theme::text_dim : mix(theme::text, theme::on_accent, onv);
	cairo_save(cr);
	{
		const double cx = b.x + b.width / 2.0, cy = b.y + b.height / 2.0, k = 1.0 - 0.06 * press;
		cairo_translate(cr, cx, cy);
		cairo_scale(cr, k, k);
		cairo_translate(cr, -cx, -cy);
	}
	if (t.w == 1 && t.h == 1) {
		// Samsung's quick toggles: round buttons.
		const double d = std::min(b.width, b.height) - 2;
		const double cx = b.x + b.width / 2.0, cy = b.y + b.height / 2.0;
		cairo_new_path(cr);
		chip_path(cr, cx, cy, d / 2);
		set_color(cr, fill);
		cairo_fill(cr);
		draw_named_icon(cr, server_->icons, s.icon, cx - 11, cy - 11, 22, fg, scale);
		if (!edit && !floating) {
			add_hot("ti:" + id, cx - d / 2, cy - d / 2, d, d, d / 2);
		}
		cairo_restore(cr);
		return;
	}
	if (t.w == 1) {
		// One cell wide, taller: a standing pill, the round icon at the top and
		// the name at the bottom (when it fits).
		const double pr = b.width / 2.0;
		fill_rounded(cr, b.x, b.y, b.width, b.height, pr, fill);
		const double d = b.width - 10, cx = b.x + b.width / 2.0, cy = b.y + 5 + d / 2;
		cairo_new_path(cr);
		chip_path(cr, cx, cy, d / 2);
		set_color(cr, onv > 0.5 ? with_alpha(theme::on_accent, 0.22) : with_alpha(theme::text, 0.08));
		cairo_fill(cr);
		draw_named_icon(cr, server_->icons, s.icon, cx - 10, cy - 10, 20, fg, scale);
		if (b.height >= d + 40) {
			std::string label = s.title;
			for (const std::string &cand : {s.title, s.title.substr(0, s.title.find(' '))}) {
				if (text_width(cand, theme::font_small) <= b.width - 8) {
					label = cand;
					break;
				}
				label.clear();
			}
			if (!label.empty()) {
				draw_text(cr, label, b.x + 2, b.y + b.height - 26, b.width - 4, 18, theme::font_small, fg, Align::Center);
			}
		}
		if (!edit && !floating) {
			add_hot("tm:" + id, b.x, b.y, b.width, b.height, pr);
			add_hot("ti:" + id, cx - d / 2, cy - d / 2, d, d, d / 2);
		}
		cairo_restore(cr);
		return;
	}
	const double rr = t.h == 1 ? b.height / 2.0 : r;   // wide tiles: pills
	// Calm: a wide tile that's on is a soft tint of the accent, its round
	// button the solid accent; the words stay in the text colour.
	const bool calm_pill = t.w >= 3 && t.h == 1;
	if (calm_pill) {
		fill_rounded(cr, b.x, b.y, b.width, b.height, rr,
			mix(off_fill, with_alpha(theme::accent, theme::dark ? 0.24 : 0.16), onv));
		const double d = b.height - 12, cx = b.x + 6 + d / 2, cy = b.y + b.height / 2.0;
		cairo_new_path(cr);
		chip_path(cr, cx, cy, d / 2);
		set_color(cr, mix(with_alpha(theme::text, 0.08), theme::accent, onv));
		cairo_fill(cr);
		const Color ifg = !s.usable ? theme::text_dim : mix(theme::text, theme::on_accent, onv);
		draw_named_icon(cr, server_->icons, s.icon, cx - 10, cy - 10, 20, ifg, scale);
		const double tx = b.x + 14 + d, tw = b.x + b.width - tx - 30;
		draw_text(cr, s.title, tx, cy - 19, tw, 20, theme::font_bold, theme::text);
		draw_text(cr, s.subtitle, tx, cy + 1, tw, 17, theme::font_small, theme::text_dim);
		draw_named_icon(cr, server_->icons, "chevron-right", b.x + b.width - 28, cy - 8, 16, theme::text_dim, scale);
		if (!edit && !floating) {
			const int ir = static_cast<int>(d / 2);
			add_hot("tm:" + id, b.x, b.y, b.width, b.height, rr);
			add_hot("ti:" + id, cx - ir - 2, cy - ir - 2, 2 * ir + 4, 2 * ir + 4, ir);
		}
		cairo_restore(cr);
		return;
	}
	fill_rounded(cr, b.x, b.y, b.width, b.height, rr, fill);
	if (false) {
	} else if (t.w <= 2 && t.h == 1) {
		// Two cells wide: no room for the round button, so a plain icon and
		// the title beside it (the icon's end still switches it).
		const double isz = 18, ix = b.x + 12, iy = b.y + b.height / 2.0 - isz / 2;
		draw_named_icon(cr, server_->icons, s.icon, ix, iy, isz, fg, scale);
		const double tx = ix + isz + 9, tw = b.x + b.width - tx - 8;
		draw_text(cr, s.title, tx, b.y + b.height / 2.0 - 18, tw, 19, theme::font_bold, fg);
		draw_text(cr, s.subtitle, tx, b.y + b.height / 2.0 + 1, tw, 17, theme::font_small, with_alpha(fg, 0.8));
		if (!edit && !floating) {
			add_hot("tm:" + id, b.x, b.y, b.width, b.height, rr);
			add_hot("ti:" + id, b.x, b.y, static_cast<int>(isz + 20), b.height, rr,
				wlr_box{b.x, b.y, b.width, b.height});
		}
	} else {
		// A round icon you click to switch it; the rest opens its list or options.
		const double d = std::min<double>(b.height, cell_) - 12;
		const double cx = b.x + 6 + d / 2, cy = t.h == 1 ? b.y + b.height / 2.0 : b.y + 6 + d / 2;
		cairo_new_path(cr);
		chip_path(cr, cx, cy, d / 2);
		set_color(cr, onv > 0.5 ? with_alpha(theme::on_accent, 0.22) : with_alpha(theme::text, 0.08));
		cairo_fill(cr);
		draw_named_icon(cr, server_->icons, s.icon, cx - 10, cy - 10, 20, fg, scale);
		double tx, ty, tw;
		if (t.h == 1) {
			tx = b.x + 12 + d;
			ty = b.y + b.height / 2.0 - 19;
			tw = b.x + b.width - tx - 10;
		} else {
			tx = b.x + 12;
			ty = b.y + b.height - 46;
			tw = b.width - 24;
		}
		draw_text(cr, s.title, tx, ty, tw, 20, theme::font_bold, fg);
		draw_text(cr, s.subtitle, tx, ty + 20, tw, 18, theme::font_small, with_alpha(fg, 0.8));
		if (!edit && !floating) {
			const int ir = static_cast<int>(d / 2);
			add_hot("tm:" + id, b.x, b.y, b.width, b.height, rr);
			add_hot("ti:" + id, cx - ir - 2, cy - ir - 2, 2 * ir + 4, 2 * ir + 4, ir);
		}
	}
	cairo_restore(cr);
}

void ControlCentre::draw_grid(cairo_t *cr, int &y, float scale) {
	if (editing_) {
		// The edit bar: a hint, Reset and Done.
		draw_text(cr, "Drag tiles, pull a corner to resize", kPad + 4, y, width_ - 2 * kPad - 150, 30,
			theme::font_small, theme::text_dim);
		const struct {
			const char *id, *label;
			int w;
			bool primary;
		} kButtons[] = {{"edit-reset", "Reset", 64, false}, {"edit-done", "Done", 64, true}};
		int bx = width_ - kPad - 64 - 6 - 64;
		for (const auto &b : kButtons) {
			fill_rounded(cr, bx, y + 2, b.w, 26, 13, b.primary ? theme::accent : theme::tile_off);
			draw_text(cr, b.label, bx, y + 2, b.w, 26, b.primary ? theme::font_bold : theme::font_small,
				b.primary ? theme::on_accent : theme::text, Align::Center);
			add_hot(b.id, bx, y + 2, b.w, 26, 13);
			bx += b.w + 6;
		}
		y += 38;
	}
	cell_ = (width_ - 2 * kPad - (kCols - 1) * kGap) / static_cast<double>(kCols);
	// Windows 11's rows are short: a 2x2 tile is a wide button with its name under it.
	row_h_ = cell_;
	grid_top_ = y;
	int rows = 0;
	for (const CcTile &t : layout_) rows = std::max(rows, t.r + t.h);
	if (editing_) rows = std::min(kMaxRows, rows + 1);   // room to drop tiles below

	if (editing_) {
		// The free cells: faint filled squares (no outlines) where a tile can go.
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < kCols; c++) {
				const bool taken = std::any_of(layout_.begin(), layout_.end(), [&](const CcTile &t) {
					return t.id != edit_tile_ && c >= t.c && c < t.c + t.w && r >= t.r && r < t.r + t.h;
				});
				if (taken) continue;
				const wlr_box cb = tile_box(CcTile{"", c, r, 1, 1});
				fill_rounded(cr, cb.x + 3, cb.y + 3, cb.width - 6, cb.height - 6,
					std::min<double>(card_radius(), cb.width / 2.0) - 3, with_alpha(theme::text, 0.05));
			}
		}
	}
	for (const CcTile &t : layout_) {
		if (t.id == edit_tile_ && !edit_resize_) continue;   // drawn under the pointer below
		const wlr_box b = tile_box(t);
		draw_tile(cr, t, b, scale, false);
		if (editing_) {
			add_hot("mv:" + t.id, b.x, b.y, b.width, b.height, -2);
			// Hide: a small minus badge inside the top corner (OneUI-like).
			const double hx = b.x + b.width - 13, hy = b.y + 13;
			cairo_new_path(cr);
			cairo_arc(cr, hx, hy, 9, 0, 2 * M_PI);
			set_color(cr, theme::close_hover);
			cairo_fill(cr);
			set_color(cr, rgb(0xffffff));
			cairo_set_line_width(cr, 1.8);
			cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
			cairo_move_to(cr, hx - 3.5, hy);
			cairo_line_to(cr, hx + 3.5, hy);
			cairo_stroke(cr);
			add_hot("rm:" + t.id, hx - 12, hy - 12, 24, 24, 12);
			// Resize: a short rounded arc following the bottom corner.
			const double cr_r = std::min<double>(card_radius(), std::min(b.width, b.height) / 2.0);
			const double inset = 5, ar = std::max(6.0, cr_r - inset);
			const double rx = b.x + b.width - inset - ar, ry = b.y + b.height - inset - ar;
			set_color(cr, with_alpha(theme::text, 0.5));
			cairo_set_line_width(cr, 3);
			cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
			cairo_new_path(cr);
			cairo_arc(cr, rx, ry, ar, M_PI * 0.08, M_PI * 0.42);
			cairo_stroke(cr);
			const double rx2 = b.x + b.width - 5, ry2 = b.y + b.height - 5;
			add_hot("rs:" + t.id, rx2 - 22, ry2 - 22, 26, 26, -2);
		}
	}
	// A tile being moved: where it would land, and the tile under the pointer.
	if (editing_ && !edit_tile_.empty()) {
		const wlr_box tb = tile_box(edit_target_);
		rounded_rect(cr, tb.x + 1, tb.y + 1, tb.width - 2, tb.height - 2, card_radius());
		set_color(cr, with_alpha(edit_target_ok_ ? theme::accent : theme::danger, 0.25));
		cairo_fill_preserve(cr);
		set_color(cr, edit_target_ok_ ? theme::accent : theme::danger);
		cairo_set_line_width(cr, 2);
		cairo_stroke(cr);
		if (!edit_resize_) {
			for (const CcTile &t : layout_) {
				if (t.id != edit_tile_) continue;
				wlr_box b = tile_box(t);
				b.x = static_cast<int>(std::lround(edit_px_ - grab_dx_));
				b.y = static_cast<int>(std::lround(edit_py_ - grab_dy_));
				cairo_push_group(cr);
				draw_tile(cr, t, b, scale, true);
				cairo_pop_group_to_source(cr);
				cairo_paint_with_alpha(cr, 0.85);
			}
		}
	}
	y = grid_top_ + (rows > 0 ? static_cast<int>(std::lround(rows * row_h_ + (rows - 1) * kGap)) : 0) + 16;
}

// In edit mode, under the grid: the tiles you hid, to add back.
void ControlCentre::draw_edit_tray(cairo_t *cr, int &y, float) {
	std::vector<const TileDef *> hidden;
	for (const TileDef &d : kTiles) {
		const bool shown = std::any_of(layout_.begin(), layout_.end(),
			[&d](const CcTile &t) { return t.id == d.id; });
		if (!shown && tile_available(server_, d.id)) hidden.push_back(&d);
	}
	draw_text(cr, hidden.empty() ? "Every tile is on the grid" : "Add a tile", kPad + 4, y, 300, 22,
		theme::font_small, theme::text_dim);
	y += 26;
	int x = kPad;
	for (const TileDef *d : hidden) {
		const std::string label = std::string("+  ") + d->name;
		const int w = text_width(label, theme::font_small) + 24;
		if (x + w > width_ - kPad) {
			x = kPad;
			y += 36;
		}
		fill_rounded(cr, x, y, w, 30, 15, theme::tile_off);
		draw_text(cr, label, x, y, w, 30, theme::font_small, theme::text, Align::Center);
		add_hot(std::string("add:") + d->id, x, y, w, 30, 15);
		x += w + 8;
	}
	y += 40;
}

void ControlCentre::draw_detail(cairo_t *cr, int &y, int bottom, float scale) {
	SystemStatus &st = *server_->status;
	const bool wifi = page_ == Page::Wifi;

	// Header: back, title, rescan, on/off switch.
	if (const double h = hv("back"); h > 0.01) {
		cairo_new_path(cr);
		cairo_arc(cr, kPad + 18, y + 18, 18, 0, 2 * M_PI);
		set_color(cr, with_alpha(theme::text, 0.12 * h));
		cairo_fill(cr);
	}
	draw_named_icon(cr, server_->icons, "chevron-left", kPad + 9, y + 9, 18, theme::text, scale);
	add_hot("back", kPad, y, 36, 36, 18);
	draw_text(cr, wifi ? "Wi-Fi" : "Bluetooth", kPad + 44, y, 200, 36, theme::font_large, theme::text);
	const bool on = wifi ? st.wifi_enabled && !st.airplane : st.bt_powered;
	fx_.set("switch", on ? 1.0 : 0.0, on ? 1.0 : 0.0);
	draw_switch(cr, width_ - kPad - 48, y + 6, fx_.get("switch"));
	add_hot("detail-switch", width_ - kPad - 52, y, 52, 36, -2);
	// Scan: a pill in the tiles' colours (the accent gradient while it's
	// scanning), Arqen's own glyph, and a word, not a bare theme icon.
	{
		const bool busy = st.scanning;
		const std::string label = busy ? "Scanning" : "Scan";
		const int pw = text_width(label, theme::font_small) + 44, ph = 32;
		const int px = width_ - kPad - 48 - 12 - pw, py = y + 2;
		const double h = hv("rescan");
		if (busy) {
			rounded_rect(cr, px, py, pw, ph, chip_radius(ph));
			accent_gradient(cr, px, py, pw, ph, 0.08 * h);
			cairo_fill(cr);
		} else {
			fill_rounded(cr, px, py, pw, ph, chip_radius(ph), mix(theme::tile_off, theme::text, 0.08 * h));
		}
		const Color fg = busy ? theme::on_gradient : theme::text;
		draw_glyph(cr, "refresh-cw", px + 20, py + ph / 2.0, 15, busy ? fg : theme::accent);
		draw_text(cr, label, px + 32, py, pw - 36, ph, theme::font_small, fg);
		add_hot("rescan", px, py, pw, ph, chip_radius(ph));
	}
	y += 48;
	// Working on it (scanning, connecting): the line that sweeps back and forth.
	if (on && (st.scanning || connecting_)) busy_box_ = wlr_box{kPad + 6, y - 9, width_ - 2 * kPad - 12, 3};

	// Password entry for a new secured network.
	if (wifi && !password_for_.empty()) {
		const int w = width_ - 2 * kPad;
		fill_rounded(cr, kPad, y, w, 104, 20, theme::card_bg);
		draw_text(cr, "Password for " + password_for_, kPad + 14, y + 8, w - 28, 22, theme::font_small,
			theme::text_dim);
		fill_rounded(cr, kPad + 12, y + 32, w - 24, 36, 18, theme::field_bg);
		std::string dots;
		for (size_t i = 0; i < password_.size(); i++) {
			dots += "•";
		}
		draw_text(cr, dots.empty() ? "Type the password" : dots, kPad + 26, y + 32, w - 120, 36,
			theme::font, dots.empty() ? theme::text_dim : theme::text);
		if (typing_) {
			const int cx = kPad + 26 + (dots.empty() ? 0 : text_width(dots, theme::font)) + 1;
			cairo_rectangle(cr, cx, y + 41, 2, 18);
			set_color(cr, theme::accent);
			cairo_fill(cr);
		}
		add_hot("password", kPad + 12, y + 32, w - 24, 36, -2);
		const int bw = 90;
		fill_rounded(cr, kPad + w - 12 - bw, y + 72, bw, 26, 13,
			connecting_ ? theme::tile_off : theme::accent);
		draw_text(cr, connecting_ ? "Connecting…" : "Connect", kPad + w - 12 - bw, y + 72, bw, 26,
			theme::font_small, connecting_ ? theme::text_dim : theme::on_accent, Align::Center);
		add_hot("connect", kPad + w - 12 - bw, y + 72, bw, 26, 13);
		if (!wifi_message_.empty()) {
			draw_text(cr, wifi_message_, kPad + 14, y + 72, w - bw - 36, 26, theme::font_small,
				theme::danger);
		}
		y += 116;
	} else if (!wifi_message_.empty()) {
		draw_text(cr, wifi_message_, kPad + 4, y, width_ - 2 * kPad, 22, theme::font_small,
			theme::text_dim);
		y += 26;
	} else if (!wifi && !st.bt_message.empty()) {
		y += draw_paragraph(cr, st.bt_message, kPad + 4, y, width_ - 2 * kPad, 2, theme::font_small,
			theme::danger) + 8;
	}

	// The list.
	list_area_ = wlr_box{kPad, y, width_ - 2 * kPad, bottom - y};
	const int row_h = 52;
	const int count = wifi ? static_cast<int>(st.networks.size()) : static_cast<int>(st.bt_devices.size());
	if (!on) {
		draw_text(cr, wifi ? "Wi-Fi is off" : "Bluetooth is off", kPad, y + 20, width_ - 2 * kPad, 24,
			theme::font, theme::text_dim, Align::Center);
		return;
	}
	if (count == 0) {
		draw_text(cr, st.scanning ? "Searching…" : wifi ? "No networks found"
			: "No devices found. Put yours in pairing mode, then press refresh.",
			kPad, y + 20, width_ - 2 * kPad, 40, theme::font_small, theme::text_dim, Align::Center);
		return;
	}
	cairo_save(cr);
	cairo_rectangle(cr, list_area_.x, list_area_.y, list_area_.width, list_area_.height);
	cairo_clip(cr);
	fx_.set("list", list_scroll_, 0);
	int ry = y - static_cast<int>(std::lround(fx_.get("list")));
	for (int i = 0; i < count; i++, ry += row_h + 6) {
		if (ry + row_h < list_area_.y || ry > list_area_.y + list_area_.height) {
			continue;
		}
		const std::string id = (wifi ? "net:" : "bt:") + std::to_string(i);
		std::string name, sub, icon;
		bool active = false;
		if (wifi) {
			const WifiNetwork &n = st.networks[static_cast<size_t>(i)];
			name = n.ssid;
			active = n.active;
			sub = n.active ? "Connected" : n.saved ? "Saved" : n.secure ? "Secured" : "Open";
			icon = wifi_icon(n.signal);
		} else {
			const BtDevice &d = st.bt_devices[static_cast<size_t>(i)];
			name = d.name;
			active = d.connected;
			const bool busy = st.bt_busy == d.address;
			sub = busy ? (d.paired ? (d.connected ? "Disconnecting…" : "Connecting…") : "Pairing…")
				: d.connected ? "Connected" : d.paired ? "Paired" : "Nearby · click to pair";
			icon = "bluetooth";
			// A line above the first nearby device.
			if (!d.paired && (i == 0 || st.bt_devices[static_cast<size_t>(i - 1)].paired)) {
				draw_text(cr, "NEARBY", kPad + 4, ry - 2, 200, 16, theme::font_small, theme::text_dim);
				ry += 18;
			}
		}
		fill_rounded(cr, kPad, ry, width_ - 2 * kPad, row_h, card_radius(),
			active ? with_alpha(theme::accent, 0.22) : theme::card_bg);
		if (const double h = hv(id); h > 0.01) {
			fill_rounded(cr, kPad, ry, width_ - 2 * kPad, row_h, card_radius(),
				with_alpha(theme::text, 0.06 * h));
		}
		draw_named_icon(cr, server_->icons, icon, kPad + 16, ry + row_h / 2.0 - 9, 18, theme::text, scale);
		draw_text(cr, name, kPad + 48, ry + 7, width_ - 2 * kPad - 90, 20, theme::font, theme::text);
		draw_text(cr, sub, kPad + 48, ry + 27, width_ - 2 * kPad - 90, 18, theme::font_small,
			active ? theme::accent : theme::text_dim);
		if (wifi && st.networks[static_cast<size_t>(i)].secure) {
			draw_named_icon(cr, server_->icons, "lock", width_ - kPad - 34, ry + row_h / 2.0 - 7, 14,
				theme::text_dim, scale);
		}
		const int top = std::max(ry, list_area_.y);
		const int bot = std::min(ry + row_h, list_area_.y + list_area_.height);
		add_hot(id, kPad, top, width_ - 2 * kPad, bot - top);
	}
	cairo_restore(cr);
	const bool nearby = !wifi && std::any_of(st.bt_devices.begin(), st.bt_devices.end(),
		[](const BtDevice &d) { return !d.paired; });
	list_max_scroll_ = std::max(0, count * (row_h + 6) - 6 + (nearby ? 18 : 0) - list_area_.height);
	list_scroll_ = std::clamp(list_scroll_, 0, list_max_scroll_);
}

// Notifications under the tiles, stacked by app like a phone (or one card
// each). Click a stack's count to open it up; hover a card for its ✕.
void ControlCentre::draw_notifications(cairo_t *cr, int y, int bottom, float scale) {
	if (bottom - y < 60) {
		return;
	}
	const Notifications *notes = server_->notifications.get();
	std::vector<const Notification *> items;
	if (notes) {
		for (const Notification &n : notes->list()) {
			if (!n.transient) items.push_back(&n);
		}
	}
	// Header: "Notifications · 3", then Settings and Clear (the notification
	// centre has its own header).
	if (!notes_only_) {
	const std::string title = std::string("Notifications") +
		(items.empty() ? std::string() : "  ·  " + std::to_string(items.size()));
	draw_text(cr, title, kPad + 6, y, 220, 28, theme::font_bold, theme::text_dim);
	{
		int bx = width_ - kPad;
		auto button = [&](const char *id, const char *label) {
			const int w = text_width(label, theme::font_small) + 22;
			bx -= w;
			fill_rounded(cr, bx, y + 1, w, 26, 13, theme::card_bg);
			draw_text(cr, label, bx, y + 1, w, 26, theme::font_small, theme::text, Align::Center);
			add_hot(id, bx, y + 1, w, 26, 13);
			bx -= 6;
		};
		if (!items.empty()) button("clear", "Clear");
		button("note-settings", "Settings");
	}
	y += 36;
	}
	notes_area_ = wlr_box{kPad, y, width_ - 2 * kPad, bottom - y};

	if (!notes || !notes->running()) {
		draw_text(cr, "Another app is showing notifications", kPad, y, width_ - 2 * kPad, 40,
			theme::font_small, theme::text_dim, Align::Center);
		return;
	}
	if (items.empty()) {
		draw_named_icon(cr, server_->icons, "bell", width_ / 2.0 - 14, y + 30, 28,
			with_alpha(theme::text_dim, 0.6), scale);
		draw_text(cr, "No notifications", kPad, y + 64, width_ - 2 * kPad, 20, theme::font,
			theme::text_dim, Align::Center);
		return;
	}

	// Stacks: one per app, newest first.
	struct Group {
		std::string app;
		std::vector<const Notification *> notes;
	};
	std::vector<Group> groups;
	for (const Notification *n : items) {
		const std::string app = n->app.empty() ? "Notification" : n->app;
		auto it = std::find_if(groups.begin(), groups.end(), [&](const Group &g) { return g.app == app; });
		if (!server_->config.notif_group || it == groups.end()) {
			groups.push_back(Group{app, {n}});
		} else {
			it->notes.push_back(n);
		}
	}

	cairo_save(cr);
	cairo_rectangle(cr, notes_area_.x, notes_area_.y - 2, notes_area_.width, notes_area_.height + 2);
	cairo_clip(cr);
	const int w = width_ - 2 * kPad;
	const int text_w = w - 24 - 40;
	fx_.set("notes", notes_scroll_, 0);
	int cy = y - static_cast<int>(std::lround(fx_.get("notes")));
	int total = 0;
	auto visible = [&](int top, int h) { return top + h > notes_area_.y && top < notes_area_.y + notes_area_.height; };
	auto hit = [&](const std::string &id, int top, int h, double radius) {
		const int t = std::max(top, notes_area_.y);
		const int b = std::min(top + h, notes_area_.y + notes_area_.height);
		if (b > t) add_hot(id, kPad, t, w, b - t, radius);
	};

	for (const Group &g : groups) {
		const bool stacked = g.notes.size() > 1;
		const bool opened = stacked && open_groups_.count(g.app);
		const size_t shown = opened ? g.notes.size() : 1;
		if (opened) {
			// The open stack's header: app, count, "Show less", ✕ all.
			if (visible(cy, 26)) {
				draw_text(cr, g.app + "  ·  " + std::to_string(g.notes.size()), kPad + 6, cy, w - 140, 26,
					theme::font_small, theme::text_dim);
				const int lw = 82;
				fill_rounded(cr, kPad + w - lw - 32, cy + 1, lw, 24, 12, theme::card_bg);
				draw_text(cr, "Show less", kPad + w - lw - 32, cy + 1, lw, 24, theme::font_small, theme::text,
					Align::Center);
				add_hot("grp:" + g.app, kPad + w - lw - 32, cy + 1, lw, 24, 12);
				cairo_new_path(cr);
				cairo_arc(cr, kPad + w - 12, cy + 13, 12, 0, 2 * M_PI);
				set_color(cr, theme::card_bg);
				cairo_fill(cr);
				draw_named_icon(cr, server_->icons, "close", kPad + w - 19, cy + 6, 14, theme::text, scale);
				add_hot("grpclose:" + g.app, kPad + w - 24, cy + 1, 24, 24, 12);
			}
			cy += 32;
			total += 32;
		}
		for (size_t i = 0; i < shown; i++) {
			const Notification *n = g.notes[i];
			const int sh = std::max(18, draw_paragraph(cr, n->summary, 0, 0, text_w, 2, theme::font_bold,
				theme::text, false));
			// Opened: all of its text, and its options in a row (or two) under it,
			// the card growing downward to fit them.
			const bool is_open = n->id == open_note_;
			const std::string okey = "nopen:" + std::to_string(n->id);
			fx_.set(okey, is_open ? 1.0 : 0.0);
			const double grow = fx_.get(okey);
			if (!is_open && grow < 0.01) fx_.forget(okey);
			const int body_lines = grow > 0.01 ? 12 : 3;
			const int bh = draw_paragraph(cr, n->body, 0, 0, text_w, body_lines, theme::font, theme::text, false);
			struct Chip {
				std::string label, icon;
				bool danger;
				int x, y, w;
			};
			std::vector<Chip> chips;
			int opts_h = 0;
			if (grow > 0.01) {
				const int chip_h = 32, gap = 6, inner = w - 24;
				int x = 0, row = 0;
				for (const NoteOption &o : note_options(n->id)) {
					const int cw = std::min(inner, text_width(o.label, theme::font_small) + 46);
					if (x > 0 && x + cw > inner) {
						x = 0;
						row++;
					}
					chips.push_back({o.label, o.icon, o.danger, x, row * (chip_h + gap), cw});
					x += cw + gap;
				}
				opts_h = static_cast<int>(std::lround(((row + 1) * (chip_h + gap) + 4) * grow));
			}
			const int base_h = 12 + 18 + 4 + sh + (bh ? 2 + bh : 0) + 12;
			const int h = base_h + opts_h;
			const std::string id = "note:" + std::to_string(n->id);
			const std::string xid = "noteclose:" + std::to_string(n->id);
			const bool closed_stack = stacked && !opened;
			const int under = closed_stack ? std::min<int>(2, static_cast<int>(g.notes.size()) - 1) : 0;
			if (visible(cy, h + under * 6)) {
				// A closed stack shows the cards behind as edges peeking out.
				for (int k = under; k >= 1; k--) {
					fill_rounded(cr, kPad + 8 * k, cy + h - 20 + 6 * k, w - 16 * k, 20, card_radius() - 2,
						mix(theme::card_bg, theme::bg_alt, 0.35 * k));
				}
				fill_rounded(cr, kPad, cy, w, h, card_radius(), theme::card_bg);
				draw_notification_icon(cr, server_->icons, *n, kPad + 12, cy + 34, 30, scale);
				draw_text(cr, g.app + " · " + ago(n->time), kPad + 12, cy + 10, w - 100, 18, theme::font_small,
					theme::text_dim);
				draw_paragraph(cr, n->summary, kPad + 52, cy + 34, text_w, 2, theme::font_bold, theme::text);
				if (bh) {
					draw_paragraph(cr, n->body, kPad + 52, cy + 34 + sh + 2, text_w, body_lines, theme::font,
						theme::text_dim);
				}
				hit(id, cy, h, card_radius());
				if (!chips.empty()) {
					// The options, revealed as the card grows (clipped to it).
					cairo_save(cr);
					cairo_rectangle(cr, kPad, cy + base_h - 4, w, opts_h + 4);
					cairo_clip(cr);
					const int oy = cy + base_h - 4;
					for (size_t k = 0; k < chips.size(); k++) {
						const Chip &c = chips[k];
						const int cx = kPad + 12 + c.x, chy = oy + c.y;
						const bool first = k == 0 && !c.danger;
						const std::string cid = "nact:" + std::to_string(n->id) + ":" + std::to_string(k);
						const Color bg = first ? theme::accent : theme::tile_off;
						const Color fg = first ? theme::on_accent : c.danger ? theme::danger : theme::text;
						fill_rounded(cr, cx, chy, c.w, 32, 16, bg);
						draw_named_icon(cr, server_->icons, c.icon, cx + 12, chy + 8, 16, fg, scale);
						draw_text(cr, c.label, cx + 34, chy, c.w - 44, 32, theme::font_small, fg);
						if (grow > 0.9 && chy + 32 <= notes_area_.y + notes_area_.height && chy >= notes_area_.y) {
							add_hot(cid, cx, chy, c.w, 32, 16);
						}
					}
					cairo_restore(cr);
				}
				int right = kPad + w - 10;
				if (closed_stack) {
					// The count: click to open the stack.
					const std::string count = "+" + std::to_string(g.notes.size() - 1);
					const int cw = text_width(count, theme::font_small) + 16;
					right -= cw;
					fill_rounded(cr, right, cy + 8, cw, 22, 11, with_alpha(theme::accent, 0.22));
					draw_text(cr, count, right, cy + 8, cw, 22, theme::font_small, theme::text, Align::Center);
					if (cy + 8 >= notes_area_.y) add_hot("grp:" + g.app, right, cy + 8, cw, 22, 11);
					right -= 6;
				}
				if (hover_ == id || hover_ == xid || hover_ == "grp:" + g.app) {
					const int bx = right - 24, by = cy + 7;
					cairo_new_path(cr);
					cairo_arc(cr, bx + 12, by + 12, 12, 0, 2 * M_PI);
					set_color(cr, theme::tile_off);
					cairo_fill(cr);
					draw_named_icon(cr, server_->icons, "close", bx + 5, by + 5, 14, theme::text, scale);
					// A closed stack's ✕ clears the whole stack.
					if (by >= notes_area_.y) {
						add_hot(closed_stack ? "grpclose:" + g.app : xid, bx, by, 24, 24, 12);
					}
				}
			}
			const int step = h + under * 6 + 8;
			cy += step;
			total += step;
		}
	}
	cairo_restore(cr);
	notes_total_ = total;
	notes_max_scroll_ = std::max(0, total - 8 - notes_area_.height);
	notes_scroll_ = std::clamp(notes_scroll_, 0, notes_max_scroll_);
}

// The clipboard history, in the notification centre's second tab: click an
// entry to put it back in the clipboard, its ✕ forgets it.
void ControlCentre::draw_clips(cairo_t *cr, int y, int bottom, float scale) {
	notes_area_ = wlr_box{kPad, y, width_ - 2 * kPad, std::max(0, bottom - y)};
	const Clipboard *cb = server_->clipboard.get();
	const bool on = server_->config.clipboard_history;
	if (!cb || !on || cb->history().empty()) {
		draw_named_icon(cr, server_->icons, "clipboard", width_ / 2.0 - 14, y + 30, 28,
			with_alpha(theme::text_dim, 0.6), scale);
		draw_text(cr, on ? "Nothing copied yet" : "Clipboard history is off", kPad, y + 64, width_ - 2 * kPad, 20,
			theme::font, theme::text_dim, Align::Center);
		if (!on) {
			const int bw = 120;
			fill_rounded(cr, (width_ - bw) / 2.0, y + 96, bw, 30, 15, theme::accent);
			draw_text(cr, "Turn it on", (width_ - bw) / 2.0, y + 96, bw, 30, theme::font_small, theme::on_accent,
				Align::Center);
			add_hot("clipon", (width_ - bw) / 2.0, y + 96, bw, 30, 15);
		}
		notes_max_scroll_ = 0;
		notes_scroll_ = 0;
		return;
	}
	cairo_save(cr);
	cairo_rectangle(cr, notes_area_.x - 2, notes_area_.y - 2, notes_area_.width + 4, notes_area_.height + 2);
	cairo_clip(cr);
	const int w = notes_area_.width;
	fx_.set("notes", notes_scroll_, 0);
	int cy = y - static_cast<int>(std::lround(fx_.get("notes")));
	int total = 0;
	for (const ClipEntry &e : cb->history()) {
		const int rh = clip_row_height(e);
		const std::string row = "clip:" + std::to_string(e.id);
		const std::string del = "clipx:" + std::to_string(e.id);
		if (cy + rh > notes_area_.y && cy < notes_area_.y + notes_area_.height) {
			const bool now = e.id == cb->current();
			fill_rounded(cr, kPad, cy, w, rh, card_radius(), now ? with_alpha(theme::accent, 0.18) : theme::card_bg);
			if (now) fill_rounded(cr, kPad + 3, cy + 10, 3, rh - 20, 1.5, theme::accent);
			draw_clip_entry(cr, server_, e, kPad, cy, w, rh, scale, now);
			const int top = std::max(cy, notes_area_.y);
			const int bot = std::min(cy + rh, notes_area_.y + notes_area_.height);
			if (bot > top) add_hot(row, kPad, top, w, bot - top, card_radius());
			if ((hover_ == row || hover_ == del) && cy + 8 >= notes_area_.y) {
				const double bx = kPad + w - 22, by = cy + 20;
				cairo_new_path(cr);
				cairo_arc(cr, bx, by, 12, 0, 2 * M_PI);
				set_color(cr, theme::tile_off);
				cairo_fill(cr);
				draw_named_icon(cr, server_->icons, "close", bx - 6, by - 6, 12, theme::text, scale);
				add_hot(del, bx - 12, by - 12, 24, 24, 12);
			}
		}
		cy += rh + 8;
		total += rh + 8;
	}
	cairo_restore(cr);
	notes_total_ = total;
	notes_max_scroll_ = std::max(0, total - 8 - notes_area_.height);
	notes_scroll_ = std::clamp(notes_scroll_, 0, notes_max_scroll_);
}

// ---- input ----------------------------------------------------------------------

void ControlCentre::motion(double lx, double ly) {
	if (!edit_tile_.empty()) {
		drag_edit(lx - box_.x, ly - box_.y);
		return;
	}
	if (dragging_ == "mp:seek") {
		media_->drag(lx - box_.x - media_box_.x);
		if (media_live_) redraw_live();
		else redraw();
		return;
	}
	if (!dragging_.empty()) {
		drag_slider(lx, ly);
		return;
	}
	const std::string now = hot_at(lx - box_.x, ly - box_.y);
	if (now != hover_) {
		// A notification shows its close button while pointed at; that needs
		// a redraw. Everything else is just the GPU highlight moving.
		auto noteish = [](const std::string &s) {
			return s.rfind("note", 0) == 0 || s.rfind("grp", 0) == 0 || s.rfind("clip", 0) == 0;
		};
		const bool notes = noteish(now) || noteish(hover_);
		hover_ = now;
		if (notes) {
			redraw();
		} else {
			update_highlight();
		}
	}
}

void ControlCentre::leave() {
	if (!hover_.empty() && dragging_.empty() && edit_tile_.empty()) {
		const bool notes = hover_.rfind("note", 0) == 0 || hover_.rfind("grp", 0) == 0 || hover_.rfind("clip", 0) == 0;
		hover_.clear();
		if (notes) {
			redraw();
		} else {
			update_highlight();
		}
	}
}

void ControlCentre::drag_slider(double lx, double ly) {
	const wlr_box &t = drag_track_;
	if (t.width <= 0 || t.height <= 0) {
		return;
	}
	const double px = lx - box_.x, py = ly - box_.y;
	const double f = drag_vertical_ ? 1.0 - (py - t.y) / t.height : (px - t.x) / t.width;
	const int value = static_cast<int>(std::lround(std::clamp(f, 0.0, 1.0) * 100));
	// Only when it changes (a mouse reports far more moves than there are
	// steps), and quietly: just this card is redrawn, at most once a frame;
	// the panels and the rest catch up when it's let go.
	if (value == drag_value_) return;
	drag_value_ = value;
	SystemStatus &st = *server_->status;
	if (dragging_ == "sl:volume") st.set_volume(value, true);
	else if (dragging_ == "sl:brightness") st.set_brightness(std::max(1, value), true);
	else if (dragging_ == "sl:mic") st.set_mic_volume(value, true);
	queue_redraw();
	(void)st;
}

// ---- edit mode: moving and resizing tiles ----

void ControlCentre::drag_edit(double px, double py) {
	edit_px_ = px;
	edit_py_ = py;
	auto self = std::find_if(layout_.begin(), layout_.end(), [this](const CcTile &t) { return t.id == edit_tile_; });
	if (self == layout_.end()) {
		return;
	}
	const double step = cell_ + kGap, vstep = row_h_ + kGap;
	CcTile target = *self;
	if (edit_resize_) {
		// The corner follows the pointer, as far as the free cells allow.
		const wlr_box b = tile_box(*self);
		target.w = std::clamp(static_cast<int>(std::lround((px - b.x + kGap) / step)), 1, kCols - self->c);
		target.h = std::clamp(static_cast<int>(std::lround((py - b.y + kGap) / vstep)), 1,
			std::min(6, kMaxRows - self->r));
		// The largest size towards the pointer that fits: a tile in the way
		// stops only the side it blocks, rather than freezing the resize.
		CcTile best = *self;
		int best_area = -1;
		for (int w = 1; w <= target.w; w++) {
			for (int h = 1; h <= target.h; h++) {
				CcTile c = *self;
				c.w = w;
				c.h = h;
				if (!fits(layout_, c, self->id)) continue;
				const int area = w * h;
				if (area > best_area) {
					best = c;
					best_area = area;
				}
			}
		}
		if (best_area > 0) {
			self->w = best.w;
			self->h = best.h;
		}
		edit_target_ = *self;
		edit_target_ok_ = true;
	} else {
		target.c = std::clamp(static_cast<int>(std::lround((px - grab_dx_ - kPad) / step)), 0, kCols - self->w);
		target.r = std::clamp(static_cast<int>(std::lround((py - grab_dy_ - grid_top_) / vstep)), 0,
			kMaxRows - self->h);
		edit_target_ = target;
		edit_target_ok_ = fits(layout_, target, self->id);
		if (!edit_target_ok_) {
			// Onto one tile that can take this one's old place: they swap.
			const CcTile *other = nullptr;
			int count = 0;
			for (const CcTile &o : layout_) {
				if (o.id != self->id && overlaps(o, target)) {
					other = &o;
					count++;
				}
			}
			if (count == 1) {
				CcTile moved = *other;
				moved.c = self->c;
				moved.r = self->r;
				edit_target_ok_ = fits(layout_, moved, self->id, other->id) &&
					fits(layout_, target, self->id, other->id) && !overlaps(moved, target);
			}
		}
	}
	queue_redraw();
}

// While a tile is dragged the pointer moves far more often than the screen
// refreshes: draw at most once a frame (~60 times a second).
void ControlCentre::queue_redraw() {
	if (!redraw_queued_) {
		redraw_queued_ = true;
		wl_event_source_timer_update(redraw_timer_, 14);
	}
}

int ControlCentre::handle_redraw_timer(void *data) {
	auto *self = static_cast<ControlCentre *>(data);
	if (self->redraw_queued_) {
		self->redraw_queued_ = false;
		self->redraw();
	}
	return 0;
}

void ControlCentre::end_edit_drag() {
	auto self = std::find_if(layout_.begin(), layout_.end(), [this](const CcTile &t) { return t.id == edit_tile_; });
	if (self != layout_.end() && !edit_resize_ && edit_target_ok_) {
		const CcTile target = edit_target_;
		for (CcTile &o : layout_) {
			if (o.id != self->id && overlaps(o, target)) {
				o.c = self->c;   // the swap
				o.r = self->r;
			}
		}
		self->c = target.c;
		self->r = target.r;
	}
	edit_tile_.clear();
	edit_resize_ = false;
	server_->cc_grab = false;
	redraw_queued_ = false;
	save_layout();
	redraw();
}

void ControlCentre::save_layout() {
	server_->write_setting(layout_key(), serialise(layout_));
}

// Each look keeps its own arrangement.
std::string ControlCentre::layout_key() const {
	return "cc_layout";
}

void ControlCentre::press(double lx, double ly, uint32_t button) {
	const double px = lx - box_.x, py = ly - box_.y;
	const std::string id = hot_at(px, py);
	auto starts = [&](const char *p) { return id.rfind(p, 0) == 0; };
	if (button == BTN_RIGHT) {
		if (starts("mp:")) {
			open_options("Media", [this] { media_menu(0, 0); });
			return;
		}
		if (starts("ti:") || starts("tm:") || starts("sl:")) {
			tile_more(id.substr(3), lx, ly);
		} else if (starts("note:")) {
			// Opens downward with its options (the same as a click).
			const uint32_t nid = static_cast<uint32_t>(std::strtoul(id.c_str() + 5, nullptr, 10));
			open_note_ = open_note_ == nid ? 0 : nid;
			redraw();
		} else if (starts("bt:")) {
			// A paired device: connect or disconnect, or forget it (a page of its own).
			SystemStatus &st = *server_->status;
			const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 3));
			if (i < st.bt_devices.size() && st.bt_devices[i].paired) {
				const std::string address = st.bt_devices[i].address;
				Server *srv = server_;
				open_options(st.bt_devices[i].name, [this, srv, address] {
					const BtDevice *found = nullptr;
					for (const BtDevice &x : srv->status->bt_devices) if (x.address == address) found = &x;
					if (!found) return;
					const BtDevice d = *found;
					std::vector<MenuItem> items;
					items.push_back(MenuItem::action(d.connected ? "Disconnect" : "Connect",
						[srv, d] { srv->status->connect_bluetooth(d); }, "bluetooth"));
					MenuItem forget = MenuItem::action("Forget this device", [this, srv, d] {
						srv->status->forget_bluetooth(d);
						page_ = Page::Bluetooth;
					}, "trash");
					forget.danger = true;
					items.push_back(forget);
					srv->menu->show(output_, wlr_box{0, 0, 1, 1}, "point", std::move(items));
				});
			}
		} else if (page_ == Page::Tiles) {
			show_menu(lx, ly);
		}
		return;
	}
	if (button != BTN_LEFT) {
		return;
	}
	if (starts("sl:")) {
		dragging_ = id;
		drag_value_ = -1;
		server_->cc_grab = true;
		for (const Hot &h : hots_) {
			if (h.id == id) {
				drag_track_ = h.box;
				drag_vertical_ = h.box.height > h.box.width;
			}
		}
		drag_slider(lx, ly);
		return;
	}
	if (starts("snd:app:")) {
		dragging_ = id;
		drag_value_ = -1;
		server_->cc_grab = true;
		for (const Hot &h : hots_) {
			if (h.id == id) {
				drag_track_ = wlr_box{h.box.x + 6, h.box.y, h.box.width - 12, h.box.height};
				drag_vertical_ = false;
			}
		}
		drag_slider(lx, ly);
		return;
	}
	if (id == "mp:seek") {
		dragging_ = id;
		server_->cc_grab = true;
		media_->drag(px - media_box_.x);
		if (media_live_) redraw_live();
		else redraw();
		return;
	}
	if (starts("mv:") || starts("rs:")) {
		edit_tile_ = id.substr(3);
		edit_resize_ = starts("rs:");
		for (const CcTile &t : layout_) {
			if (t.id == edit_tile_) {
				const wlr_box b = tile_box(t);
				grab_dx_ = px - b.x;
				grab_dy_ = py - b.y;
				edit_target_ = t;
				edit_target_ok_ = true;
			}
		}
		server_->cc_grab = true;
		drag_edit(px, py);
		return;
	}
	if (id != "password" && typing_) {
		typing_ = false;
	}
	if (!id.empty()) {
		hl_.flash();
	}
	if (starts("note:")) {
		// A notification opens downward, its options under it (click again to close it).
		const uint32_t nid = static_cast<uint32_t>(std::strtoul(id.c_str() + 5, nullptr, 10));
		open_note_ = open_note_ == nid ? 0 : nid;
		redraw();
		return;
	}
	if (starts("nact:")) {
		// One of an opened notification's options: "nact:<id>:<index>".
		const std::string rest = id.substr(5);
		const size_t colon = rest.find(':');
		if (colon != std::string::npos) {
			const uint32_t nid = static_cast<uint32_t>(std::strtoul(rest.c_str(), nullptr, 10));
			const size_t k = static_cast<size_t>(std::strtoul(rest.c_str() + colon + 1, nullptr, 10));
			std::vector<NoteOption> opts = note_options(nid);
			open_note_ = 0;
			if (k < opts.size() && opts[k].run) opts[k].run();
		}
		redraw();
		return;
	}
	activate(id);
}

// What can be done with a notification, shown under it when it's opened
// (clicked): open it (or its app), the app's own buttons, and dismiss.
std::vector<ControlCentre::NoteOption> ControlCentre::note_options(uint32_t nid) {
	std::vector<NoteOption> out;
	Server *srv = server_;
	if (!srv->notifications) return out;
	const Notification *found = srv->notifications->get(nid);
	if (!found) return out;
	const Notification n = *found;   // (it may be gone by the time one is picked)
	bool has_default = false;
	for (const auto &a : n.actions) has_default = has_default || a.first == "default";
	const AppInfo *app = nullptr;
	auto lower = [](std::string t) {
		for (char &c : t) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
		return t;
	};
	for (const AppInfo &a : srv->apps.apps()) {
		std::string id = a.id;
		if (id.size() > 8 && id.compare(id.size() - 8, 8, ".desktop") == 0) id.resize(id.size() - 8);
		if ((!n.desktop_entry.empty() && lower(id) == lower(n.desktop_entry)) ||
				(!n.app.empty() && lower(a.name) == lower(n.app))) {
			app = &a;
			break;
		}
	}
	if (has_default) {
		out.push_back({"Open", "external-link", [srv, nid] { srv->notifications->run_action(nid, "default"); }, false});
	} else if (app) {
		out.push_back({"Open " + app->name, "external-link", [srv, exec = app->exec, nid] {
			srv->spawn(exec);
			srv->notifications->dismiss(nid);
		}, false});
	}
	// The app's own buttons, each with an icon that says what it does.
	auto icon_for = [&lower](const std::string &label) -> std::string {
		const std::string l = lower(label);
		auto has = [&l](const char *w) { return l.find(w) != std::string::npos; };
		if (has("reply") || has("answer") || has("respond")) return "message-square";
		if (has("read") || has("done") || has("ok") || has("accept") || has("confirm")) return "check";
		if (has("mute") || has("silence") || has("snooze")) return "bell-off";
		if (has("delete") || has("remove") || has("trash")) return "trash";
		if (has("call")) return "smartphone";
		if (has("download") || has("save")) return "download";
		if (has("show") || has("view") || has("see")) return "eye";
		if (has("copy")) return "copy";
		if (has("open")) return "external-link";
		if (has("cancel") || has("decline") || has("reject") || has("stop")) return "circle-x";
		return "circle-dot";
	};
	for (const auto &[key, label] : n.actions) {
		if (key == "default" || label.empty()) continue;
		out.push_back({label, icon_for(label), [srv, nid, k = key] { srv->notifications->run_action(nid, k); }, false});
	}
	out.push_back({"Dismiss", "close", [srv, nid] { srv->notifications->dismiss(nid); }, true});
	return out;
}

void ControlCentre::release() {
	if (!edit_tile_.empty()) {
		end_edit_drag();
		return;
	}
	if (dragging_ == "mp:seek") media_->end_drag();
	if (dragging_.rfind("snd:app:", 0) == 0 && drag_value_ >= 0) {
		const size_t i = static_cast<size_t>(std::atoi(dragging_.c_str() + 8));
		if (i < sound_apps_.size()) {
			sound_apps_[i].volume = drag_value_;
			sound_action("--app-volume " + shell_quote(sound_apps_[i].index) + " " + std::to_string(drag_value_));
		}
	}
	const bool slider = dragging_.rfind("sl:", 0) == 0;
	dragging_.clear();
	drag_value_ = -1;
	server_->cc_grab = false;
	if (slider && server_->status->changed) server_->status->changed();   // the panels catch up
	redraw();
}

void ControlCentre::scroll(double lx, double ly, double delta) {
	const double px = lx - box_.x, py = ly - box_.y;
	const int step = static_cast<int>(std::lround(delta * 3));
	if (page_ == Page::Tiles && inside(notes_area_, px, py)) {
		notes_scroll_ = std::clamp(notes_scroll_ + step, 0, notes_max_scroll_);
		redraw();
	} else if (page_ != Page::Tiles && inside(list_area_, px, py)) {
		list_scroll_ = std::clamp(list_scroll_ + step, 0, list_max_scroll_);
		redraw();
	} else {
		// Over a slider tile: the wheel changes it.
		std::string id = hot_at(px, py);
		if (id.rfind("si:", 0) == 0) id = "sl:" + id.substr(3);   // (its icon)
		const int change = delta < 0 ? 5 : -5;
		SystemStatus &st = *server_->status;
		if (id == "sl:volume") st.set_volume(st.volume + change);
		else if (id == "sl:brightness") st.set_brightness(st.brightness + change);
		else if (id == "sl:mic") st.set_mic_volume(st.mic_volume + change);
	}
}

void ControlCentre::open_page(Page page) {
	SystemStatus &st = *server_->status;
	page_ = page;
	list_scroll_ = 0;
	fx_.snap("list", 0);
	fx_.snap("page", 1);
	fx_.set("page", 0);
	password_for_.clear();
	wifi_message_.clear();
	if (page_ == Page::Wifi) {
		st.scan_wifi();
	} else if (page_ == Page::Bluetooth) {
		st.scan_bluetooth();
	}
	redraw();
}

// ---- Pages made from menus ------------------------------------------------------------------

namespace {
std::string page_title(std::string label) {
	const std::string dots = "…";
	if (label.size() >= dots.size() && label.compare(label.size() - dots.size(), dots.size(), dots) == 0) {
		label.erase(label.size() - dots.size());
	}
	while (!label.empty() && (label.back() == '.' || label.back() == ' ')) label.pop_back();
	return label;
}

} // namespace

bool ControlCentre::take_menu(Output *output, std::vector<MenuItem> &items) {
	if (!open_ || output != output_) return false;
	if (capturing_) {
		capture_buf_ = std::move(items);
		captured_ = true;
		return true;
	}
	// A menu that comes a moment after a pick on a page (it looked something
	// up first): another page.
	if (page_ == Page::Options && now_ms() < capture_until_) {
		capture_until_ = 0;
		OptLevel level;
		level.title = "Options";
		if (!items.empty() && items.front().kind == MenuItem::Kind::Header) {
			level.title = items.front().label;
			items.erase(items.begin());
		}
		level.items = std::move(items);
		opt_stack_.push_back(std::move(level));
		list_scroll_ = 0;
		fx_.snap("list", 0);
		fx_.snap("page", 1);
		fx_.set("page", 0);
		redraw();
		return true;
	}
	return false;
}

void ControlCentre::open_options(const std::string &title, std::function<void()> build) {
	opt_return_ = page_ == Page::Options ? opt_return_ : page_;
	opt_stack_.clear();
	OptLevel level;
	level.title = title;
	level.build = std::move(build);
	opt_stack_.push_back(std::move(level));
	options_rebuild();
	if (opt_stack_.back().items.empty()) {
		opt_stack_.clear();
		return;
	}
	open_page(Page::Options);
}

// Runs the page's menu again (after a change: what's ticked moves).
void ControlCentre::options_rebuild() {
	if (opt_stack_.empty()) return;
	OptLevel &level = opt_stack_.back();
	if (!level.build) return;
	const std::function<void()> build = level.build;
	capturing_ = true;
	captured_ = false;
	build();
	capturing_ = false;
	if (opt_stack_.empty()) return;
	if (!captured_) {
		// What it was about is gone (a dismissed notification, a forgotten device).
		if (page_ == Page::Options) {
			if (opt_stack_.size() > 1) {
				opt_stack_.pop_back();
			} else {
				page_ = opt_return_;
				opt_return_ = Page::Tiles;
			}
		}
		return;
	}
	std::vector<MenuItem> items = std::move(capture_buf_);
	capture_buf_.clear();
	// The menu's own heading is the page's title already.
	if (!items.empty() && items.front().kind == MenuItem::Kind::Header &&
			(opt_stack_.size() > 1 || items.front().label == opt_stack_.back().title)) {
		opt_stack_.back().title = items.front().label;
		items.erase(items.begin());
	}
	opt_stack_.back().items = std::move(items);
}

void ControlCentre::options_pick(size_t index) {
	if (opt_stack_.empty() || index >= opt_stack_.back().items.size()) return;
	const MenuItem item = opt_stack_.back().items[index];
	if (!item.enabled || !item.run || item.kind == MenuItem::Kind::Header || item.kind == MenuItem::Kind::Separator) return;
	capturing_ = true;
	captured_ = false;
	item.run();
	capturing_ = false;
	if (!open_) return;   // it closed the control centre (a screenshot…)
	if (page_ != Page::Options) {   // it went somewhere else (Edit tiles)
		fx_.snap("page", 1);
		fx_.set("page", 0);
		redraw();
		return;
	}
	if (captured_) {
		// It opened a menu of its own: the next page.
		OptLevel level;
		level.title = page_title(item.label);
		level.build = item.run;
		level.items = std::move(capture_buf_);
		capture_buf_.clear();
		if (!level.items.empty() && level.items.front().kind == MenuItem::Kind::Header) {
			level.title = level.items.front().label;
			level.items.erase(level.items.begin());
		}
		opt_stack_.push_back(std::move(level));
		list_scroll_ = 0;
		fx_.snap("list", 0);
		fx_.snap("page", 1);
		fx_.set("page", 0);
	} else {
		capture_until_ = now_ms() + 1500;
		options_rebuild();
	}
	redraw();
}

// Back, the title, and (Sound) a link on the right.
void ControlCentre::draw_page_header(cairo_t *cr, int &y, const std::string &title, float scale) {
	if (const double h = hv("back"); h > 0.01) {
		cairo_new_path(cr);
		cairo_arc(cr, kPad + 18, y + 18, 18, 0, 2 * M_PI);
		set_color(cr, with_alpha(theme::text, 0.12 * h));
		cairo_fill(cr);
	}
	draw_named_icon(cr, server_->icons, "chevron-left", kPad + 9, y + 9, 18, theme::text, scale);
	add_hot("back", kPad, y, 36, 36, 18);
	draw_text(cr, title, kPad + 44, y, width_ - 2 * kPad - 160, 36, theme::font_large, theme::text);
}

void ControlCentre::draw_options(cairo_t *cr, int &y, int bottom, float scale) {
	if (opt_stack_.empty()) return;
	const OptLevel &level = opt_stack_.back();
	draw_page_header(cr, y, level.title, scale);
	y += 48;
	list_area_ = wlr_box{kPad, y, width_ - 2 * kPad, bottom - y};
	cairo_save(cr);
	cairo_rectangle(cr, list_area_.x, list_area_.y, list_area_.width, list_area_.height);
	cairo_clip(cr);
	fx_.set("list", list_scroll_, 0);
	int ry = y - static_cast<int>(std::lround(fx_.get("list")));
	const int start = ry;
	const int w = width_ - 2 * kPad;
	const int row_h = 46;
	for (size_t i = 0; i < level.items.size(); i++) {
		const MenuItem &m = level.items[i];
		if (m.kind == MenuItem::Kind::Separator) {
			ry += 10;
			continue;
		}
		if (m.kind == MenuItem::Kind::Header) {
			std::string up = m.label;
			std::transform(up.begin(), up.end(), up.begin(), ::toupper);
			draw_text(cr, up, kPad + 4, ry + 6, w - 8, 20, theme::font_small, theme::text_dim);
			ry += 30;
			continue;
		}
		const std::string id = "opt:" + std::to_string(i);
		const bool radio_on = m.kind == MenuItem::Kind::Radio && m.on;
		if (ry + row_h >= list_area_.y && ry <= list_area_.y + list_area_.height) {
			fill_rounded(cr, kPad, ry, w, row_h, card_radius(),
				radio_on ? with_alpha(theme::accent, 0.22) : theme::card_bg);
			if (const double h = hv(id); h > 0.01) {
				fill_rounded(cr, kPad, ry, w, row_h, card_radius(), with_alpha(theme::text, 0.06 * h));
			}
			const Color fg = !m.enabled ? theme::text_dim : m.danger ? theme::danger : theme::text;
			int tx = kPad + 16;
			if (!m.icon.empty()) {
				draw_named_icon(cr, server_->icons, m.icon, kPad + 14, ry + row_h / 2.0 - 9, 18,
					m.danger ? theme::danger : radio_on ? theme::accent : theme::text, scale);
				tx = kPad + 44;
			}
			draw_text(cr, m.label, tx, ry, w - (tx - kPad) - 60, row_h, theme::font, fg);
			const int rx = kPad + w - 14;
			if (m.kind == MenuItem::Kind::Check) {
				fx_.set("optsw:" + m.label, m.on ? 1.0 : 0.0, m.on ? 1.0 : 0.0);
				draw_switch(cr, rx - 44, ry + row_h / 2.0 - 12, fx_.get("optsw:" + m.label));
			} else if (radio_on) {
				draw_named_icon(cr, server_->icons, "check", rx - 18, ry + row_h / 2.0 - 9, 18, theme::accent, scale);
			} else if (m.kind == MenuItem::Kind::Action && m.label.find("…") != std::string::npos) {
				draw_named_icon(cr, server_->icons, "chevron-right", rx - 16, ry + row_h / 2.0 - 8, 16,
					theme::text_dim, scale);
			}
			const int top = std::max(ry, list_area_.y);
			const int bot = std::min(ry + row_h, list_area_.y + list_area_.height);
			if (bot > top) add_hot(id, kPad, top, w, bot - top);
		}
		ry += row_h + 6;
	}
	cairo_restore(cr);
	list_max_scroll_ = std::max(0, ry - start - 6 - list_area_.height);
	list_scroll_ = std::clamp(list_scroll_, 0, list_max_scroll_);
}

// ---- The Sound page ----------------------------------------------------------------------------

void ControlCentre::open_sound() {
	sound_loaded_ = false;
	open_page(Page::Sound);
	load_sound();
}

void ControlCentre::load_sound() {
	if (sound_busy_) return;
	const std::string helper = server_->helper_path("arqen-audio-outputs");
	if (helper.empty()) {
		sound_loaded_ = true;
		redraw();
		return;
	}
	sound_busy_ = true;
	server_->run_capture(shell_quote(helper) + " --all 2>/dev/null", [this](const std::string &text) {
		sound_busy_ = false;
		sound_outs_.clear();
		sound_ins_.clear();
		sound_apps_.clear();
		sink_ids_.clear();
		std::istringstream in(text);
		std::string line;
		while (std::getline(in, line)) {
			std::vector<std::string> f;
			size_t at = 0, tab;
			while ((tab = line.find('\t', at)) != std::string::npos) {
				f.push_back(line.substr(at, tab - at));
				at = tab + 1;
			}
			f.push_back(line.substr(at));
			if (f.empty()) continue;
			if (f[0] == "SINK" && f.size() >= 4) {
				sound_outs_.push_back({"SINK", f[1], "", f[3], f[2] == "1", -1});
			} else if (f[0] == "PORT" && f.size() >= 4) {
				sound_outs_.push_back({"PORT", f[1], f[2], f[3], false, -1});
			} else if (f[0] == "SOURCE" && f.size() >= 5) {
				sound_ins_.push_back({"SOURCE", f[1], "", f[3], f[2] == "1", std::atoi(f[4].c_str())});
			} else if (f[0] == "SINKID" && f.size() >= 3) {
				sink_ids_[f[1]] = f[2];
			} else if (f[0] == "APP" && f.size() >= 7) {
				SoundApp a;
				a.index = f[1];
				a.volume = std::atoi(f[2].c_str());
				a.sink = f[3];
				a.name = f[4];
				a.muted = f[5] == "1";
				a.icon = f[6];
				sound_apps_.push_back(a);
			}
		}
		sound_loaded_ = true;
		if (open_ && page_ == Page::Sound) redraw();
	});
}

void ControlCentre::sound_action(const std::string &args) {
	const std::string helper = server_->helper_path("arqen-audio-outputs");
	if (helper.empty()) return;
	server_->run_capture(shell_quote(helper) + " " + args + " >/dev/null 2>&1", [this](const std::string &) {
		server_->status->refresh();
		if (open_ && page_ == Page::Sound) load_sound();
	});
}

void ControlCentre::draw_sound(cairo_t *cr, int &y, int bottom, float scale) {
	const SystemStatus &st = *server_->status;
	draw_page_header(cr, y, "Sound", scale);
	{
		const std::string label = "Sound settings";
		const int lw = text_width(label, theme::font_small) + 34;
		const int lx = width_ - kPad - lw;
		if (const double h = hv("snd:mixer"); h > 0.01) {
			fill_rounded(cr, lx, y + 4, lw, 28, 14, with_alpha(theme::text, 0.10 * h));
		}
		draw_named_icon(cr, server_->icons, "settings", lx + 8, y + 11, 14, theme::text_dim, scale);
		draw_text(cr, label, lx + 26, y + 4, lw - 30, 28, theme::font_small, theme::text_dim);
		add_hot("snd:mixer", lx, y + 4, lw, 28, 14);
	}
	y += 46;
	list_area_ = wlr_box{kPad, y, width_ - 2 * kPad, bottom - y};
	if (!sound_loaded_) {
		draw_text(cr, "Looking…", kPad, y + 20, width_ - 2 * kPad, 24, theme::font_small, theme::text_dim, Align::Center);
		return;
	}
	cairo_save(cr);
	cairo_rectangle(cr, list_area_.x, list_area_.y, list_area_.width, list_area_.height);
	cairo_clip(cr);
	fx_.set("list", list_scroll_, 0);
	int ry = y - static_cast<int>(std::lround(fx_.get("list")));
	const int start = ry;
	const int w = width_ - 2 * kPad;
	auto visible = [&](int top, int h) { return top + h >= list_area_.y && top <= list_area_.y + list_area_.height; };
	auto hit = [&](const std::string &id, int x, int top, int hw, int h, double radius) {
		const int t = std::max(top, list_area_.y);
		const int b = std::min(top + h, list_area_.y + list_area_.height);
		if (b > t) add_hot(id, x, t, hw, b - t, radius);
	};
	auto heading = [&](const char *text) {
		if (visible(ry, 24)) draw_text(cr, text, kPad + 4, ry + 4, w, 18, theme::font_small, theme::text_dim);
		ry += 26;
	};
	auto device_row = [&](const SoundDev &d, const std::string &id, bool input) {
		const int row_h = 54;
		if (visible(ry, row_h)) {
			const auto [title, sub] = friendly_device(d.label, d.name, input);
			fill_rounded(cr, kPad, ry, w, row_h, card_radius(),
				d.current ? with_alpha(theme::accent, 0.20) : theme::card_bg);
			if (const double h = hv(id); h > 0.01) {
				fill_rounded(cr, kPad, ry, w, row_h, card_radius(), with_alpha(theme::text, 0.06 * h));
			}
			draw_named_icon(cr, server_->icons, device_icon(title, d.name, input), kPad + 14, ry + row_h / 2.0 - 9, 18,
				d.current ? theme::accent : theme::text, scale);
			draw_text(cr, title, kPad + 46, ry + 8, w - 150, 20, theme::font_bold, theme::text);
			draw_text(cr, d.kind == "PORT" ? (sub.empty() ? "Click to switch to it" : sub + " · off") : sub,
				kPad + 46, ry + 28, w - 150, 18, theme::font_small, theme::text_dim);
			int rx = kPad + w - 14;
			if (d.current) {
				draw_named_icon(cr, server_->icons, "check", rx - 16, ry + row_h / 2.0 - 8, 16, theme::accent, scale);
				rx -= 26;
				if (!input) {
					// Its volume, in a little pill (like a phone's).
					const std::string v = st.muted ? "Muted" : std::to_string(st.volume);
					const int pw = text_width(v, theme::font_small) + 18;
					rounded_rect(cr, rx - pw, ry + row_h / 2.0 - 11, pw, 22, 11);
					set_color(cr, theme::accent);
					cairo_set_line_width(cr, 1.5);
					cairo_stroke(cr);
					draw_text(cr, v, rx - pw, ry + row_h / 2.0 - 11, pw, 22, theme::font_small, theme::accent, Align::Center);
				}
			}
			if (input) {
				// How loud it's set: a few segments.
				const int segs = 6, sw = 4, gap = 2;
				const int lit = d.volume < 0 ? 0 : std::clamp((d.volume * segs + 50) / 100, 0, segs);
				const int sx = rx - segs * (sw + gap);
				for (int k = 0; k < segs; k++) {
					fill_rounded(cr, sx + k * (sw + gap), ry + row_h / 2.0 - 7, sw, 14, 1.5,
						k < lit ? (d.current ? theme::accent : theme::text_dim) : with_alpha(theme::text, 0.15));
				}
			}
			hit(id, kPad, ry, w, row_h, card_radius());
		}
		ry += row_h + 6;
	};
	heading("OUTPUT");
	for (size_t i = 0; i < sound_outs_.size(); i++) device_row(sound_outs_[i], "snd:out:" + std::to_string(i), false);
	if (sound_outs_.empty()) {
		draw_text(cr, "No sound outputs found", kPad + 4, ry, w, 22, theme::font_small, theme::text_dim);
		ry += 28;
	}
	if (!sound_ins_.empty()) {
		ry += 6;
		heading("INPUT");
		for (size_t i = 0; i < sound_ins_.size(); i++) device_row(sound_ins_[i], "snd:in:" + std::to_string(i), true);
	}
	if (!sound_apps_.empty()) {
		ry += 6;
		heading("APPS");
		for (size_t i = 0; i < sound_apps_.size(); i++) {
			const SoundApp &a = sound_apps_[i];
			const int row_h = 40;
			if (visible(ry, row_h)) {
				const std::string si = std::to_string(i);
				const double cy = ry + row_h / 2.0;
				const std::string icon = server_->apps.icon_for(a.icon.empty() ? a.name : a.icon);
				if (!icon.empty()) draw_icon(cr, server_->icons, icon, a.name, kPad + 4, cy - 10, 20, scale);
				else draw_named_icon(cr, server_->icons, "app-window", kPad + 6, cy - 8, 16, theme::text_dim, scale);
				hit("snd:mute:" + si, kPad, ry, 28, row_h, 14);
				draw_text(cr, a.name, kPad + 32, ry, 76, row_h, theme::font_small, a.muted ? theme::text_dim : theme::text);
				// Where it plays: a chip; click for the list.
				std::string out = "Default";
				auto sid = sink_ids_.find(a.sink);
				if (sid != sink_ids_.end()) {
					for (const SoundDev &d : sound_outs_) {
						if (d.name == sid->second) out = friendly_device(d.label, d.name, false).first;
					}
				}
				const int cw = std::min(120, text_width(out, theme::font_small) + 34);
				const int cx = kPad + w - cw;
				fill_rounded(cr, cx, cy - 13, cw, 26, 13, theme::card_bg);
				if (const double h = hv("snd:appout:" + si); h > 0.01) {
					fill_rounded(cr, cx, cy - 13, cw, 26, 13, with_alpha(theme::text, 0.08 * h));
				}
				draw_text(cr, out, cx + 10, cy - 13, cw - 30, 26, theme::font_small, theme::text_dim);
				draw_named_icon(cr, server_->icons, "chevron-down", cx + cw - 20, cy - 6, 12, theme::text_dim, scale);
				hit("snd:appout:" + si, cx, ry, cw, row_h, 13);
				// Its volume: a slider (drag or scroll).
				const int tx = kPad + 112, tw = cx - 12 - tx;
				const int v = dragging_ == "snd:app:" + si && drag_value_ >= 0 ? drag_value_ : a.volume;
				const double f = std::clamp(v / 100.0, 0.0, 1.0);
				fill_rounded(cr, tx, cy - 4, tw, 8, 4, with_alpha(theme::text, 0.14));
				fill_rounded(cr, tx, cy - 4, std::max(8.0, tw * f), 8, 4,
					a.muted ? with_alpha(theme::text, 0.3) : theme::accent);
				cairo_new_path(cr);
				cairo_arc(cr, tx + tw * f, cy, 9, 0, 2 * M_PI);
				set_color(cr, rgb(0xffffff));
				cairo_fill_preserve(cr);
				set_color(cr, rgb(0x000000, 0.2));
				cairo_set_line_width(cr, 1);
				cairo_stroke(cr);
				hit("snd:app:" + si, tx - 6, ry, tw + 12, row_h, -2);
			}
			ry += row_h + 4;
		}
	}
	cairo_restore(cr);
	list_max_scroll_ = std::max(0, ry - start - 6 - list_area_.height);
	list_scroll_ = std::clamp(list_scroll_, 0, list_max_scroll_);
}

// A tile's main click: switch it, or do it.
void ControlCentre::tile_action(const std::string &t) {
	SystemStatus &st = *server_->status;
	const Config &c = server_->config;
	fx_.snap("press:" + t, 1);
	fx_.set("press:" + t, 0);
	if (t == "wifi") st.toggle_wifi();
	else if (t == "bluetooth") st.toggle_bluetooth();
	else if (t == "sound") st.toggle_mute();
	else if (t == "airplane") st.toggle_airplane();
	else if (t == "caffeine") st.toggle_caffeine();
	else if (t == "power") st.cycle_power_profile();
	else if (t == "battery") st.cycle_power_profile();
	else if (t == "devices" || t == "kdeconnect" || t == "sysmon") {
		tile_more(t, 0, 0);
		return;
	}
	else if (t == "dark") server_->write_setting("theme", c.dark ? "light" : "dark");
	else if (t == "nightlight") server_->write_setting("night_light", c.night_light ? "false" : "true");
	else if (t == "dnd") server_->write_setting("dnd", c.dnd ? "false" : "true");
	else if (t == "screenshot") {
		// After the control centre has slid away, so it isn't in the picture.
		close();
		Server *srv = server_;
		// The screenshot tool, once the control centre has gone.
		srv->run_then("sleep 0.3", [srv](bool) { srv->screenshot("tool"); });
		return;
	}
	redraw();
}

// The rest of a tile (or a right-click): Wi-Fi and Bluetooth open their
// lists; the others their options.
void ControlCentre::tile_more(const std::string &t, double lx, double ly) {
	if (t == "wifi" && server_->status->wifi_available) {
		open_page(Page::Wifi);
	} else if (t == "bluetooth" && server_->status->bt_available) {
		open_page(Page::Bluetooth);
	} else if (t == "volume" || t == "sound" || t == "mic") {
		open_sound();   // where sound goes, the microphones, each app
	} else if (t == "devices" && server_->status->bt_available) {
		open_page(Page::Bluetooth);
	} else if (t == "kdeconnect") {
		// KDE Connect's own window: pairing, sending files, finding the phone.
		for (const char *app : {"kdeconnect-app", "kdeconnect-settings"}) {
			if (access((std::string("/usr/bin/") + app).c_str(), X_OK) == 0) {
				close();
				server_->spawn(app);
				return;
			}
		}
	} else {
		const TileDef *d = tile_def(t);
		open_options(d ? d->name : "Options", [this, t] { show_tile_menu(t, 0, 0); });
	}
	(void)lx;
	(void)ly;
}

void ControlCentre::show_tile_menu(const std::string &tile, double lx, double ly) {
	Server *srv = server_;
	const Config &c = srv->config;
	SystemStatus &st = *srv->status;
	std::vector<MenuItem> items;
	auto set = [srv](std::string key, std::string value) {
		return [srv, key, value] { srv->write_setting(key, value); };
	};
	if (tile == "sysmon") {
		// What it shows: any of them, in this order.
		const SysSample s = sysmon_.sample();
		items.push_back(MenuItem::header("Show"));
		std::vector<std::pair<std::string, std::string>> all = {{"cpu", "Processor (CPU)"}};
		if (s.has_igpu) all.push_back({"igpu", "Built-in graphics (iGPU)"});
		if (s.has_gpu) all.push_back({"gpu", "Graphics card (GPU)"});
		all.push_back({"ram", "Memory (RAM)"});
		all.push_back({"swap", "Swap"});
		auto list = split_list(c.cc_sysmon);
		for (const auto &[key, label] : all) {
			const bool on = std::find(list.begin(), list.end(), key) != list.end();
			items.push_back(MenuItem::check(label, on, [srv, key = key, on] {
				std::vector<std::string> now = split_list(srv->config.cc_sysmon), next;
				for (const char *k : {"cpu", "igpu", "gpu", "ram", "swap"}) {
					const bool had = std::find(now.begin(), now.end(), k) != now.end();
					if (k == key ? !on : had) next.push_back(k);
				}
				std::string v;
				for (const std::string &k : next) v += (v.empty() ? "" : ",") + k;
				srv->write_setting("cc_sysmon", v.empty() ? "cpu" : v);
			}));
		}
		for (const char *app : {"gnome-system-monitor", "plasma-systemmonitor", "missioncenter", "resources"}) {
			if (access((std::string("/usr/bin/") + app).c_str(), X_OK) == 0) {
				items.push_back(MenuItem::separator());
				items.push_back(MenuItem::action("Open the system monitor", [this, srv, app = std::string(app)] {
					close();
					srv->spawn(app);
				}, "external-link"));
				break;
			}
		}
	} else if (tile == "dark") {
		items.push_back(MenuItem::radio("Dark", c.dark, set("theme", "dark")));
		items.push_back(MenuItem::radio("Light", !c.dark, set("theme", "light")));
	} else if (tile == "nightlight") {
		items.push_back(MenuItem::check("Night light", c.night_light,
			set("night_light", c.night_light ? "false" : "true")));
		items.push_back(MenuItem::header("Warmth"));
		for (const auto &[label, k] : std::vector<std::pair<std::string, int>>{
				{"A little", 5500}, {"Medium", 4300}, {"Warm", 3400}, {"Very warm", 2700}}) {
			items.push_back(MenuItem::radio(label, std::abs(c.night_light_temp - k) < 300, [srv, k = k] {
				Config::write_key("night_light", "true");
				srv->write_setting("night_light_temp", std::to_string(k));
			}));
		}
	} else if (tile == "dnd") {
		items.push_back(MenuItem::check("Do not disturb", c.dnd, set("dnd", c.dnd ? "false" : "true")));
		items.push_back(MenuItem::action("Clear notifications", [srv] {
			if (srv->notifications) srv->notifications->clear_all();
		}));
		items.push_back(MenuItem::action("Notification settings…", [srv] { srv->open_settings("notifications"); }));
	} else if (tile == "power" || tile == "battery") {
		if (tile == "battery" && st.has_battery) {
			items.push_back(MenuItem::header(std::to_string(st.battery) + "%, " + battery_words(st)));
		}
		for (const auto &[label, p] : std::vector<std::pair<std::string, std::string>>{
				{"Power saver", "power-saver"}, {"Balanced", "balanced"}, {"Performance", "performance"}}) {
			if (!st.power_profile.empty()) {
				items.push_back(MenuItem::radio(label, st.power_profile == p,
					[srv, p = p] { srv->status->set_power_profile(p); }));
			}
		}
		if (!st.power_profile.empty() && st.has_battery) {
			// Switching by itself: plugged in, on battery, low.
			static const std::pair<const char *, const char *> kModes[] = {
				{"Don't change", ""}, {"Power saver", "power-saver"}, {"Balanced", "balanced"}, {"Performance", "performance"}};
			const std::pair<const char *, const char *> kRules[] = {
				{"When plugged in", "power_on_ac"}, {"On battery", "power_on_battery"}, {"When the battery is low", "power_on_low"}};
			for (const auto &[title, key] : kRules) {
				const std::string &cur = std::string(key) == "power_on_ac" ? c.power_on_ac
					: std::string(key) == "power_on_battery" ? c.power_on_battery : c.power_on_low;
				items.push_back(MenuItem::header(title));
				for (const auto &[label, mode] : kModes) {
					items.push_back(MenuItem::radio(label, cur == mode, set(key, mode)));
				}
			}
		}
		items.push_back(MenuItem::action("Power settings…", [srv] { srv->open_settings("power"); }));
	} else if (tile == "caffeine") {
		items.push_back(MenuItem::check("Keep the screen awake", st.caffeine, [srv] { srv->status->toggle_caffeine(); }));
	} else if (tile == "airplane") {
		items.push_back(MenuItem::check("Airplane mode", st.airplane, [srv] { srv->status->toggle_airplane(); }));
	} else if (tile == "sound" || tile == "volume") {
		items.push_back(MenuItem::check("Mute", st.muted, [srv] { srv->status->toggle_mute(); }));
	} else if (tile == "mic") {
		items.push_back(MenuItem::check("Mute microphone", st.mic_muted, [srv] { srv->status->toggle_mic(); }));
	} else if (tile == "screenshot") {
		items.push_back(MenuItem::action("Screenshot tool…", [this] { tile_action("screenshot"); }, "area"));
		items.push_back(MenuItem::action("This screen", [srv] {
			srv->control_centre->close();
			srv->run_then("sleep 0.35", [srv](bool) { srv->screenshot("screen"); });
		}, "display"));
		items.push_back(MenuItem::action("All screens", [srv] {
			srv->control_centre->close();
			srv->run_then("sleep 0.35", [srv](bool) { srv->screenshot("all"); });
		}));
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::action("Screenshot settings…", [srv] { srv->open_settings("screenshots"); }, "gear"));
	} else if (tile == "media") {
		items.push_back(MenuItem::action("Play / pause", [srv] { srv->status->media("play-pause"); }));
		items.push_back(MenuItem::action("Next", [srv] { srv->status->media("next"); }));
		items.push_back(MenuItem::action("Previous", [srv] { srv->status->media("previous"); }));
	}
	if ((tile == "sound" || tile == "volume" || tile == "mic")) {
		for (const char *mixer : {"pwvucontrol", "pavucontrol"}) {
			if (access((std::string("/usr/bin/") + mixer).c_str(), X_OK) == 0) {
				items.push_back(MenuItem::action("Sound settings…", [srv, m = std::string(mixer)] { srv->spawn(m); }));
				break;
			}
		}
	}
	if (!items.empty()) items.push_back(MenuItem::separator());
	items.push_back(MenuItem::action("Edit tiles", [this] {
		editing_ = true;
		page_ = Page::Tiles;
		redraw();
	}, "edit"));
	MenuItem hide = MenuItem::action("Hide this tile", [this, tile] {
		layout_.erase(std::remove_if(layout_.begin(), layout_.end(),
			[&tile](const CcTile &t) { return t.id == tile; }), layout_.end());
		page_ = Page::Tiles;
		save_layout();
	});
	hide.danger = true;
	items.push_back(hide);
	srv->menu->show(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point",
		std::move(items));
}

void ControlCentre::show_menu(double lx, double ly) {
	Server *srv = server_;
	std::vector<MenuItem> items;
	items.push_back(MenuItem::action("Edit tiles", [this] {
		editing_ = true;
		redraw();
	}, "edit"));
	items.push_back(MenuItem::action("Control centre settings…", [srv] { srv->open_settings("controlcentre"); }, "gear"));
	srv->menu->show(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point",
		std::move(items));
}

// Power: the same menu as the app menu's power button (power_actions).
void ControlCentre::show_power_menu(double lx, double ly) {
	server_->show_power_menu(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point");
}

void ControlCentre::activate(const std::string &id) {
	SystemStatus &st = *server_->status;
	auto starts = [&](const char *p) { return id.rfind(p, 0) == 0; };
	if (id.empty()) {
		return;
	}
	if (id == "settings") {
		close();
		server_->open_settings();
		return;
	}
	if (id == "settings-cc") {
		close();
		server_->open_settings("controlcentre");
		return;
	}
	if (id == "lock-now") {
		close();
		server_->power_action("lock");
		return;
	}
	if (id == "me") {
		close();
		server_->open_settings("about");
		return;
	}
	if (id == "power") {
		const wlr_box b = [&] {
			for (const Hot &h : hots_) if (h.id == "power") return h.box;
			return wlr_box{};
		}();
		show_power_menu(box_.x + b.x, box_.y + b.y + b.height);
		return;
	}
	if (id == "edit" || id == "edit-done") {
		editing_ = id == "edit" ? !editing_ : false;
	} else if (id == "edit-reset") {
		layout_ = default_layout(server_);
		server_->write_setting(layout_key(), "");
	} else if (starts("rm:")) {
		const std::string t = id.substr(3);
		layout_.erase(std::remove_if(layout_.begin(), layout_.end(),
			[&t](const CcTile &x) { return x.id == t; }), layout_.end());
		save_layout();
	} else if (starts("add:")) {
		// Into the first free place, row by row.
		const TileDef *d = tile_def(id.substr(4));
		if (d) {
			CcTile t{d->id, 0, 0, d->w, d->h};
			bool placed = false;
			for (int r = 0; r < kMaxRows && !placed; r++) {
				for (int c = 0; c + t.w <= kCols && !placed; c++) {
					t.c = c;
					t.r = r;
					placed = fits(layout_, t, "");
				}
			}
			if (!placed) {
				t.w = t.h = 1;
				for (int r = 0; r < kMaxRows && !placed; r++) {
					for (int c = 0; c < kCols && !placed; c++) {
						t.c = c;
						t.r = r;
						placed = fits(layout_, t, "");
					}
				}
			}
			if (placed) {
				layout_.push_back(t);
				save_layout();
			}
		}
	} else if (starts("ti:")) {
		tile_action(id.substr(3));
		return;
	} else if (starts("tm:")) {
		const Hot *h = nullptr;
		for (const Hot &x : hots_) if (x.id == id) h = &x;
		tile_more(id.substr(3), box_.x + (h ? h->box.x + h->box.width / 2 : 0),
			box_.y + (h ? h->box.y + h->box.height : 0));
		return;
	} else if (starts("pp:")) {
		// A power mode button on the battery tile.
		st.set_power_profile(id.substr(3));
	} else if (id == "mp:output") {
		const Hot *h = nullptr;
		for (const Hot &x : hots_) if (x.id == id) h = &x;
		output_menu(box_.x + (h ? h->box.x : 0), box_.y + (h ? h->box.y + h->box.height : 0));
		return;
	} else if (id == "mp:lyrics") {
		const bool was = server_->config.lyrics_show;
		server_->write_setting("lyrics_show", was ? "false" : "true");
		if (!was) lyrics_note(server_);
	} else if (id == "mp:source") {
		const Hot *h = nullptr;
		for (const Hot &x : hots_) if (x.id == id) h = &x;
		media_source_menu(server_, output_, box_.x + (h ? h->box.x : 0), box_.y + (h ? h->box.y + h->box.height : 0));
		return;
	} else if (id == "mp:card" || id == "mp:seek") {
		return;
	} else if (starts("mp:")) {
		st.media(id.substr(3).c_str());
	} else if (id == "back" && page_ == Page::Options && opt_stack_.size() > 1) {
		opt_stack_.pop_back();
		list_scroll_ = 0;
		fx_.snap("list", 0);
		fx_.snap("page", 1);
		fx_.set("page", 0);
		options_rebuild();
	} else if (starts("opt:")) {
		options_pick(static_cast<size_t>(std::atoi(id.c_str() + 4)));
		return;
	} else if (id == "snd:mixer") {
		for (const char *mixer : {"pwvucontrol", "pavucontrol"}) {
			if (access((std::string("/usr/bin/") + mixer).c_str(), X_OK) == 0) {
				close();
				server_->spawn(mixer);
				return;
			}
		}
		close();
		server_->open_settings("media");   // its Sound card
		return;
	} else if (starts("snd:out:")) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 8));
		if (i < sound_outs_.size()) {
			const SoundDev &d = sound_outs_[i];
			if (d.kind == "PORT") sound_action("--port " + shell_quote(d.name) + " " + shell_quote(d.profile));
			else if (!d.current) sound_action("--sink " + shell_quote(d.name));
			for (SoundDev &o : sound_outs_) o.current = &o == &d;
		}
	} else if (starts("snd:in:")) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 7));
		if (i < sound_ins_.size() && !sound_ins_[i].current) {
			sound_action("--source " + shell_quote(sound_ins_[i].name));
			for (SoundDev &o : sound_ins_) o.current = &o == &sound_ins_[i];
		}
	} else if (starts("snd:mute:")) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 9));
		if (i < sound_apps_.size()) {
			sound_apps_[i].muted = !sound_apps_[i].muted;
			sound_action("--app-mute " + shell_quote(sound_apps_[i].index));
		}
	} else if (starts("snd:appout:")) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 11));
		if (i < sound_apps_.size()) {
			// Where this app plays: a page of the outputs.
			const SoundApp app = sound_apps_[i];
			std::vector<SoundDev> outs;
			for (const SoundDev &d : sound_outs_) if (d.kind == "SINK") outs.push_back(d);
			const std::map<std::string, std::string> ids = sink_ids_;
			Server *srv = server_;
			open_options(app.name, [this, srv, app, outs, ids] {
				std::vector<MenuItem> items;
				items.push_back(MenuItem::header("Play " + app.name + " on"));
				auto now = ids.find(app.sink);
				for (const SoundDev &d : outs) {
					const bool on = now != ids.end() && now->second == d.name;
					items.push_back(MenuItem::radio(friendly_device(d.label, d.name, false).first, on,
						[this, app, name = d.name] {
							sound_action("--app-sink " + shell_quote(app.index) + " " + shell_quote(name));
							page_ = Page::Sound;
							list_scroll_ = 0;
							fx_.snap("list", 0);
						}));
				}
				srv->menu->show(output_, wlr_box{0, 0, 1, 1}, "point", std::move(items));
			});
			return;
		}
	} else if (id == "back" && page_ == Page::Options && opt_return_ != Page::Tiles) {
		const Page to = opt_return_;
		opt_return_ = Page::Tiles;
		page_ = to;
		list_scroll_ = 0;
		fx_.snap("list", 0);
		fx_.snap("page", 1);
		fx_.set("page", 0);
		if (to == Page::Sound) load_sound();
	} else if (id == "back") {
		page_ = Page::Tiles;
		fx_.snap("page", 1);
		fx_.set("page", 0);
		typing_ = false;
		password_for_.clear();
	} else if (id == "detail-switch") {
		if (page_ == Page::Wifi) {
			if (st.airplane) st.toggle_airplane();
			else st.toggle_wifi();
		} else {
			st.toggle_bluetooth();
		}
	} else if (id == "rescan") {
		if (page_ == Page::Wifi) st.scan_wifi();
		else st.scan_bluetooth();
	} else if (id == "password") {
		typing_ = true;
	} else if (id == "connect") {
		handle_key(XKB_KEY_Return, "");
		return;
	} else if (starts("net:")) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 4));
		if (i < st.networks.size() && !connecting_) {
			const WifiNetwork n = st.networks[i];
			if (n.active) {
				return;
			}
			if (n.secure && !n.saved) {
				password_for_ = n.ssid;
				password_.clear();
				typing_ = true;
				wifi_message_.clear();
			} else {
				connecting_ = true;
				wifi_message_ = "Connecting to " + n.ssid + "…";
				st.connect_wifi(n, "", [this, n](bool ok, std::string reason) {
					connecting_ = false;
					if (ok) {
						wifi_message_.clear();
					} else if (reason == "password") {
						password_for_ = n.ssid;
						password_.clear();
						typing_ = true;
						wifi_message_ = "Wrong or missing password";
					} else {
						wifi_message_ = "Couldn't connect to " + n.ssid;
					}
					server_->status->scan_wifi();
					redraw();
				});
			}
		}
	} else if (starts("bt:")) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 3));
		if (i < st.bt_devices.size()) {
			st.connect_bluetooth(st.bt_devices[i]);
		}
	} else if (id == "tab:notes" || id == "tab:clips") {
		clip_tab_ = id == "tab:clips";
		notes_scroll_ = 0;
		fx_.snap("notes", 0);
	} else if (starts("clipx:")) {
		if (server_->clipboard) server_->clipboard->remove(std::strtoull(id.c_str() + 6, nullptr, 10));
	} else if (starts("clip:")) {
		if (server_->clipboard) server_->clipboard->use(std::strtoull(id.c_str() + 5, nullptr, 10));
		close();   // picked: paste it where you were
		return;
	} else if (id == "clipon") {
		server_->write_setting("clipboard_history", "true");
	} else if (id == "clear" && notes_only_ && clip_tab_) {
		if (server_->clipboard) server_->clipboard->clear();
		notes_scroll_ = 0;
	} else if (id == "clear") {
		if (server_->notifications) server_->notifications->clear_all();
		notes_scroll_ = 0;
		open_groups_.clear();
	} else if (id == "cal:prev" || id == "cal:next") {
		cal_offset_ += id == "cal:next" ? 1 : -1;
	} else if (id == "note-settings") {
		close();
		server_->open_settings("notifications");
		return;
	} else if (starts("grpclose:")) {
		const std::string app = id.substr(9);
		if (Notifications *n = server_->notifications.get()) {
			std::vector<uint32_t> ids;
			for (const Notification &x : n->list()) {
				if ((x.app.empty() ? "Notification" : x.app) == app) ids.push_back(x.id);
			}
			for (uint32_t nid : ids) n->dismiss(nid);
		}
		open_groups_.erase(app);
	} else if (starts("grp:")) {
		const std::string app = id.substr(4);
		if (!open_groups_.erase(app)) open_groups_.insert(app);
	} else if (starts("si:")) {
		const std::string t = id.substr(3);
		if (t == "volume") st.toggle_mute();
		else if (t == "mic") st.toggle_mic();
	} else if (starts("noteclose:")) {
		if (server_->notifications) {
			server_->notifications->dismiss(static_cast<uint32_t>(std::strtoul(id.c_str() + 10, nullptr, 10)));
		}
	} else if (starts("note:")) {
		if (server_->notifications) {
			server_->notifications->activate(static_cast<uint32_t>(std::strtoul(id.c_str() + 5, nullptr, 10)));
		}
	}
	redraw();
}

// ---- Media menus ------------------------------------------------------------------------

namespace {
// Lyrics turned on, or searched again: say what's happening, so it's not
// just "nothing shows" (none found, still looking, SongRec missing…).
void lyrics_note(Server *srv) {
	if (!srv->notifications || !srv->lyrics) return;
	static uint32_t note = 0;
	const Lyrics &ly = *srv->lyrics;
	if (ly.available()) {
		// Found: they're on the screen, nothing to say, unless they're
		// behind the windows (where a maximised one hides them).
		// (Said once per session, not every time.)
		static bool told = false;
		if (srv->config.lyrics_on_top || told) {
			if (note) srv->notifications->dismiss(note);
			note = 0;
			return;
		}
		told = true;
		note = srv->notifications->post("Lyrics are on the desktop",
			"Behind your windows. To have them over the windows, turn on \"Lyrics over the windows\" "
			"in this menu.", "audio-x-generic-symbolic", 0, note);
		return;
	}
	const std::string why = ly.status().empty() ? std::string("Nothing playing to look up") : ly.status();
	note = srv->notifications->post(ly.searching() ? "Looking for lyrics" : "No lyrics for this song", why +
		(ly.searching() ? "\nThey show as soon as they're found." : ""), "audio-x-generic-symbolic", 0, note);
}
} // namespace

// The media card's own menu items (lyrics, their style, the visualizer,
// settings): in the control centre's media card and the panel's media
// widget alike. The style menus open at `at` (next to a panel at `edge`,
// or "point").
void media_menu_items(Server *srv, Output *out, wlr_box at, const std::string &edge, std::vector<MenuItem> &items) {
	const Config &c = srv->config;
	const SystemStatus &st = *srv->status;
	items.push_back(MenuItem::check("Lyrics on the screen", c.lyrics_show, [srv, on = c.lyrics_show] {
		if (!srv->config.lyrics) Config::write_key("lyrics", "true");
		srv->write_setting("lyrics_show", on ? "false" : "true");
		if (!on) lyrics_note(srv);
	}));
	if (c.lyrics_show) {
		items.push_back(MenuItem::check("Lyrics over the windows", c.lyrics_on_top, [srv, on = c.lyrics_on_top] {
			srv->write_setting("lyrics_on_top", on ? "false" : "true");
		}));
	}
	if (st.media_available && srv->lyrics) {
		// Also when lyrics were found: they may be another song's, or badly timed.
		items.push_back(MenuItem::action(srv->lyrics->searching() ? "Looking for lyrics…" : "Search for lyrics again",
			[srv] { srv->lyrics->retry(false); lyrics_note(srv); }, "refresh"));
		if (c.lyrics_recognize) {
			items.push_back(MenuItem::action("Listen for the song (SongRec)",
				[srv] { srv->lyrics->retry(true); lyrics_note(srv); }, "mic-vocal"));
		}
	}
	// The styles in menus of their own (all in one was taller than a laptop's screen).
	items.push_back(MenuItem::action("Lyrics style…", [srv, out, at, edge] {
		static const std::pair<const char *, const char *> kStyles[] = {
			{"Classic", "classic"}, {"Karaoke", "karaoke"}, {"Subtitles", "subtitle"}, {"Glow", "glow"},
			{"Scrolling", "scroll"}, {"Bounce", "bounce"}, {"Typewriter", "typewriter"}, {"Comic", "comic"},
		};
		std::vector<MenuItem> sub;
		sub.push_back(MenuItem::header("Lyrics style"));
		for (const auto &[label, key] : kStyles) {
			sub.push_back(MenuItem::radio(label, srv->config.lyrics_style == key, [srv, k = std::string(key)] {
				Config::write_key("lyrics_show", "true");
				srv->write_setting("lyrics_style", k);
				lyrics_note(srv);
			}));
		}
		srv->menu->show(out, at, edge, std::move(sub));
	}, "mic-vocal"));
	items.push_back(MenuItem::separator());
	items.push_back(MenuItem::action("Beat visualizer…", [srv, out, at, edge] {
		static const std::pair<const char *, const char *> kViz[] = {
			{"Bars", "bars"}, {"Mirror", "mirror"}, {"Dots", "dots"}, {"Wave", "wave"}, {"Hills", "hills"}, {"Off", "off"},
		};
		static const std::pair<const char *, const char *> kColor[] = {
			{"From the album art", "art"}, {"Accent", "accent"}, {"White", "text"}, {"Rainbow", "rainbow"},
		};
		std::vector<MenuItem> sub;
		sub.push_back(MenuItem::header("Beat visualizer"));
		for (const auto &[label, key] : kViz) {
			sub.push_back(MenuItem::radio(label, srv->config.media_viz == key,
				[srv, k = std::string(key)] { srv->write_setting("media_viz", k); }));
		}
		sub.push_back(MenuItem::header("Colour"));
		for (const auto &[label, key] : kColor) {
			sub.push_back(MenuItem::radio(label, srv->config.media_viz_color == key,
				[srv, k = std::string(key)] { srv->write_setting("media_viz_color", k); }));
		}
		sub.push_back(MenuItem::separator());
		sub.push_back(MenuItem::check("Follow the music's beat", srv->config.media_wave_beat,
			[srv, on = srv->config.media_wave_beat] { srv->write_setting("media_wave_beat", on ? "false" : "true"); }));
		srv->menu->show(out, at, edge, std::move(sub));
	}, "audio-lines"));
	items.push_back(MenuItem::action("Media & lyrics settings…", [srv] { srv->open_settings("media"); }, "gear"));
}

void ControlCentre::media_menu(double lx, double ly) {
	Server *srv = server_;
	const SystemStatus &st = *srv->status;
	std::vector<MenuItem> items;
	if (st.media_available) {
		items.push_back(MenuItem::action(st.media_playing ? "Pause" : "Play", [srv] { srv->status->media("play-pause"); },
			st.media_playing ? "pause" : "play"));
		items.push_back(MenuItem::action("Next", [srv] { srv->status->media("next"); }, "next"));
		items.push_back(MenuItem::action("Previous", [srv] { srv->status->media("previous"); }, "previous"));
		items.push_back(MenuItem::separator());
	}
	media_menu_items(srv, output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point", items);
	srv->menu->show(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point", std::move(items));
}

void ControlCentre::output_menu(double, double) {
	open_sound();
}

bool ControlCentre::handle_key(xkb_keysym_t sym, const std::string &text) {
	if (sym == XKB_KEY_Escape) {
		if (typing_) {
			typing_ = false;
			password_for_.clear();
			redraw();
		} else {
			close();
		}
		return true;
	}
	if (!typing_) {
		return false;
	}
	if (sym == XKB_KEY_Return || sym == XKB_KEY_KP_Enter) {
		if (password_.empty() || connecting_) {
			return true;
		}
		WifiNetwork n;
		for (const WifiNetwork &w : server_->status->networks) {
			if (w.ssid == password_for_) {
				n = w;
			}
		}
		n.ssid = password_for_;
		connecting_ = true;
		wifi_message_.clear();
		const std::string password = password_;
		server_->status->connect_wifi(n, password, [this](bool ok, std::string) {
			connecting_ = false;
			if (ok) {
				password_for_.clear();
				password_.clear();
				typing_ = false;
				wifi_message_.clear();
			} else {
				wifi_message_ = "Couldn't connect";
			}
			server_->status->scan_wifi();
			redraw();
		});
		redraw();
		return true;
	}
	if (sym == XKB_KEY_BackSpace) {
		if (!password_.empty()) {
			size_t cut = password_.size() - 1;
			while (cut > 0 && (static_cast<unsigned char>(password_[cut]) & 0xc0) == 0x80) {
				cut--;
			}
			password_.erase(cut);
		}
	} else if (!text.empty() && static_cast<unsigned char>(text[0]) >= 0x20 && text[0] != 0x7f) {
		password_ += text;
	}
	redraw();
	return true;
}

} // namespace arqen
